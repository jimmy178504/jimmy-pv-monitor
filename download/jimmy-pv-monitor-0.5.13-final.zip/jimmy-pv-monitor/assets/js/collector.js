( function () {
	'use strict';

	const config = window.jimmyPvConfig;
	if (
		! config ||
		typeof config.endpoint !== 'string' ||
		typeof config.clickEndpoint !== 'string' ||
		typeof config.pageKey !== 'string' ||
		typeof config.url !== 'string' ||
		typeof config.signature !== 'string'
	) {
		return;
	}

	let sentForCurrentView = false;
	let currentViewId = null;

	function randomId() {
		if ( window.crypto && typeof window.crypto.randomUUID === 'function' ) {
			return window.crypto.randomUUID();
		}

		if ( window.crypto && typeof window.crypto.getRandomValues === 'function' ) {
			const bytes = new Uint8Array( 16 );
			window.crypto.getRandomValues( bytes );
			bytes[ 6 ] = ( bytes[ 6 ] & 0x0f ) | 0x40;
			bytes[ 8 ] = ( bytes[ 8 ] & 0x3f ) | 0x80;

			return Array.from( bytes, function ( byte ) {
				return byte.toString( 16 ).padStart( 2, '0' );
			} ).join( '' );
		}

		return (
			Date.now().toString( 16 ) +
			Math.random().toString( 16 ).slice( 2 ) +
			Math.random().toString( 16 ).slice( 2 )
		).slice( 0, 32 );
	}

	function fetchWithRetry( endpoint, json, retries ) {
		if ( typeof window.fetch !== 'function' ) {
			return;
		}

		window.fetch( endpoint, {
			method: 'POST',
			credentials: 'same-origin',
			cache: 'no-store',
			keepalive: true,
			headers: {
				'Content-Type': 'application/json'
			},
			body: json
		} ).then( function ( response ) {
			if ( retries > 0 && response.status >= 500 ) {
				window.setTimeout( function () {
					fetchWithRetry( endpoint, json, retries - 1 );
				}, 1000 );
			}
		} ).catch( function () {
			if ( retries > 0 ) {
				window.setTimeout( function () {
					fetchWithRetry( endpoint, json, retries - 1 );
				}, 1000 );
			}
		} );
	}

	function sendPayload( endpoint, json, retries ) {
		if ( navigator.sendBeacon ) {
			try {
				const blob = new Blob( [ json ], { type: 'application/json' } );
				if ( navigator.sendBeacon( endpoint, blob ) ) {
					return;
				}
			} catch ( error ) {
				// Fetch below is the compatibility fallback.
			}
		}

		fetchWithRetry( endpoint, json, retries );
	}

	function visibleLinkIds() {
		const nodes = document.querySelectorAll( '[data-jimmy-pv-link-id]' );
		const seen = Object.create( null );
		const ids = [];
		for ( let index = 0; index < nodes.length && ids.length < 200; index += 1 ) {
			const value = Number( nodes[ index ].getAttribute( 'data-jimmy-pv-link-id' ) );
			if ( Number.isSafeInteger( value ) && value > 0 && ! seen[ value ] ) {
				seen[ value ] = true;
				ids.push( value );
			}
		}

		return ids;
	}

	function sendPageview() {
		if ( sentForCurrentView ) {
			return;
		}
		sentForCurrentView = true;
		currentViewId = randomId();

		let currentUrl = config.url;
		try {
			const parsedUrl = new URL( window.location.href );
			parsedUrl.hash = '';
			currentUrl = parsedUrl.toString();
		} catch ( error ) {
			// The server-provided canonical URL is the safe fallback.
		}

		const referrer = typeof document.referrer === 'string' && document.referrer.length <= 2048
			? document.referrer
			: '';
		const payload = {
			event_id: randomId(),
			view_id: currentViewId,
			page_key: config.pageKey,
			url: currentUrl,
			referrer: referrer,
			signature: config.signature,
			link_ids: visibleLinkIds()
		};
		const json = JSON.stringify( payload );
		sendPayload( config.endpoint, json, 1 );
	}

	function clickedAnchor( target ) {
		let node = target && target.nodeType === 1 ? target : target ? target.parentElement : null;
		while ( node && node !== document ) {
			if ( node.tagName === 'A' && typeof node.getAttribute === 'function' ) {
				return node;
			}
			node = node.parentElement;
		}
		return null;
	}

	function externalTarget( anchor ) {
		if ( typeof config.homeUrl !== 'string' ) {
			return null;
		}
		const href = typeof anchor.href === 'string' && anchor.href !== '' ? anchor.href : anchor.getAttribute( 'href' );
		if ( typeof href !== 'string' || href.length === 0 || href.length > 2048 ) {
			return null;
		}
		try {
			const target = new URL( href, window.location.href );
			const home = new URL( config.homeUrl, window.location.href );
			if ( ! [ 'http:', 'https:' ].includes( target.protocol ) || target.hostname.toLowerCase() === home.hostname.toLowerCase() ) {
				return null;
			}
			target.hash = '';
			return target.toString();
		} catch ( error ) {
			return null;
		}
	}

	function anchorText( anchor ) {
		let value = typeof anchor.textContent === 'string' ? anchor.textContent : '';
		if ( value.trim() === '' && typeof anchor.querySelector === 'function' ) {
			const image = anchor.querySelector( 'img[alt]' );
			value = image ? image.getAttribute( 'alt' ) || '' : '';
		}
		if ( value.trim() === '' ) {
			value = anchor.getAttribute( 'aria-label' ) || anchor.getAttribute( 'title' ) || '';
		}
		return value.replace( /\s+/g, ' ' ).trim().slice( 0, 255 );
	}

	function sendLinkClick( event ) {
		if ( ! currentViewId ) {
			return;
		}
		if ( event.type === 'click' && typeof event.button === 'number' && event.button !== 0 ) {
			return;
		}
		const anchor = clickedAnchor( event.target );
		if ( ! anchor ) {
			return;
		}
		const linkId = Number( anchor.getAttribute( 'data-jimmy-pv-link-id' ) );
		const targetUrl = Number.isSafeInteger( linkId ) && linkId > 0 ? null : externalTarget( anchor );
		if ( ! targetUrl && ( ! Number.isSafeInteger( linkId ) || linkId <= 0 ) ) {
			return;
		}
		const payload = {
			event_id: randomId(),
			view_id: currentViewId,
			page_key: config.pageKey,
			signature: config.signature
		};
		if ( targetUrl ) {
			payload.target_url = targetUrl;
			payload.anchor_text = anchorText( anchor );
		} else {
			payload.link_id = linkId;
		}
		sendPayload( config.clickEndpoint, JSON.stringify( payload ), 0 );
	}

	window.addEventListener( 'pagehide', function () {
		sentForCurrentView = false;
		currentViewId = null;
	} );

	window.addEventListener( 'pageshow', function () {
		sendPageview();
	} );

	document.addEventListener( 'click', sendLinkClick, true );
	document.addEventListener( 'auxclick', function ( event ) {
		if ( event.button === 1 ) {
			sendLinkClick( event );
		}
	}, true );

	if ( document.readyState === 'complete' ) {
		window.setTimeout( sendPageview, 0 );
	}
}() );
