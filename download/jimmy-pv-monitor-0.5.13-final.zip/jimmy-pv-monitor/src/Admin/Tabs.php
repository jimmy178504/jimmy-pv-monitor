<?php

namespace Jimmy\PVMonitor\Admin;

defined( 'ABSPATH' ) || exit;

final class Tabs {
	public static function render( string $current ): void {
		$tabs = array(
			array( 'slug' => 'jimmy-pv', 'label' => __( 'ダッシュボード', 'jimmy-pv-monitor' ), 'capability' => 'jimmy_pv_view_reports', 'order' => 10 ),
			array( 'slug' => 'jimmy-pv-pages', 'label' => __( 'ページ別PV', 'jimmy-pv-monitor' ), 'capability' => 'jimmy_pv_view_reports', 'order' => 20 ),
			array( 'slug' => 'jimmy-pv-referrers', 'label' => __( '流入元', 'jimmy-pv-monitor' ), 'capability' => 'jimmy_pv_view_reports', 'order' => 30 ),
			array( 'slug' => 'jimmy-pv-links', 'label' => __( '外部リンククリック', 'jimmy-pv-monitor' ), 'capability' => 'jimmy_pv_view_reports', 'order' => 40 ),
			array( 'slug' => 'jimmy-pv-export', 'label' => __( 'CSV出力', 'jimmy-pv-monitor' ), 'capability' => 'jimmy_pv_export_data', 'order' => 80 ),
			array( 'slug' => 'jimmy-pv-settings', 'label' => __( '設定', 'jimmy-pv-monitor' ), 'capability' => 'jimmy_pv_manage_settings', 'order' => 100 ),
		);
		$filtered = apply_filters( 'jimmy_pv_admin_tabs', $tabs );
		if ( is_array( $filtered ) ) {
			$tabs = $filtered;
		}
		usort(
			$tabs,
			static fn ( array $left, array $right ): int => (int) ( $left['order'] ?? 100 ) <=> (int) ( $right['order'] ?? 100 )
		);

		echo '<nav class="nav-tab-wrapper jimmy-pv-admin-tabs" aria-label="' . esc_attr__( 'Jimmy PV 画面切り替え', 'jimmy-pv-monitor' ) . '">';
		foreach ( $tabs as $tab ) {
			$slug = isset( $tab['slug'] ) ? sanitize_key( (string) $tab['slug'] ) : '';
			$label = isset( $tab['label'] ) ? (string) $tab['label'] : '';
			$capability = isset( $tab['capability'] ) ? (string) $tab['capability'] : '';
			if ( '' === $slug || '' === $label || '' === $capability || ! current_user_can( $capability ) ) {
				continue;
			}

			$class = 'nav-tab' . ( $slug === $current ? ' nav-tab-active' : '' );
			$url = add_query_arg( 'page', $slug, admin_url( 'admin.php' ) );
			if ( $slug === $current ) {
				echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '" aria-current="page">' . esc_html( $label ) . '</a>';
			} else {
				echo '<a class="' . esc_attr( $class ) . '" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
			}
		}
		echo '</nav>';
	}
}
