<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Reporting\AnalyticsRepository;
use Jimmy\PVMonitor\Reporting\DateRangeFactory;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET values only filter this read-only report.

final class DashboardPage {
	public function __construct(
		private readonly AnalyticsRepository $analytics,
		private readonly DateRangeFactory $dates,
		private readonly PeriodSelector $periods
	) {}

	public function render(): void {
		if ( ! current_user_can( 'jimmy_pv_view_reports' ) ) {
			wp_die( esc_html__( 'このレポートを表示する権限がありません。', 'jimmy-pv-monitor' ) );
		}

		$range          = $this->dates->fromRequest( $_GET );
		$total          = $this->analytics->total( $range );
		$todayTotal     = $this->analytics->total( $this->dates->preset( 'today' ) );
		$yesterdayTotal = $this->analytics->total( $this->dates->preset( 'yesterday' ) );
		$dailyAverage   = 0 < $range->days() ? $total / $range->days() : 0.0;
		$series        = $this->analytics->series( $range );
		$topPages      = $this->analytics->topPages( $range, 10 );
		$sources       = $this->analytics->sourceSummary( $range );
		$searchEngines = $this->analytics->searchEngines( $range, 10 );
		$domains       = $this->analytics->referrerDomains( $range, 10 );
		$campaignTotal = $this->analytics->campaignTotal( $range );
		$chartJson     = wp_json_encode( $series );
		?>
		<div class="wrap jimmy-pv-admin">
			<h1><?php esc_html_e( 'ダッシュボード', 'jimmy-pv-monitor' ); ?></h1>
			<?php Tabs::render( 'jimmy-pv' ); ?>
			<p class="description"><?php esc_html_e( 'サイト全体のPV（ページが表示された回数）と、よく見られているページや流入元の概要を確認できます。', 'jimmy-pv-monitor' ); ?></p>
			<?php $this->periods->render( 'jimmy-pv', $range ); ?>

			<div class="jimmy-pv-cards">
				<section class="jimmy-pv-card">
					<h2><?php esc_html_e( '選択期間のPV', 'jimmy-pv-monitor' ); ?></h2>
					<p class="jimmy-pv-metric"><?php echo esc_html( number_format_i18n( $total ) ); ?></p>
					<p><?php echo esc_html( $range->label() ); ?></p>
				</section>
				<?php $this->renderComparisonCard( __( '昨日との比較', 'jimmy-pv-monitor' ), $todayTotal, $yesterdayTotal, __( '昨日', 'jimmy-pv-monitor' ), 0 ); ?>
				<?php if ( 'today' !== $range->preset ) : ?>
					<?php $this->renderComparisonCard( __( '指定期間の平均との比較', 'jimmy-pv-monitor' ), $todayTotal, $dailyAverage, __( '指定期間の1日平均', 'jimmy-pv-monitor' ), 1 ); ?>
				<?php endif; ?>
			</div>

			<section class="jimmy-pv-panel">
				<h2><?php esc_html_e( '日別PV推移', 'jimmy-pv-monitor' ); ?></h2>
				<div class="jimmy-pv-chart" data-jimmy-pv-chart="<?php echo esc_attr( false !== $chartJson ? $chartJson : '[]' ); ?>">
					<p><?php esc_html_e( 'グラフを読み込んでいます。', 'jimmy-pv-monitor' ); ?></p>
				</div>
				<noscript><p><?php esc_html_e( 'グラフ表示にはJavaScriptが必要です。', 'jimmy-pv-monitor' ); ?></p></noscript>
			</section>

			<section class="jimmy-pv-panel">
				<div class="jimmy-pv-panel-heading">
					<h2><?php esc_html_e( '人気記事', 'jimmy-pv-monitor' ); ?></h2>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=jimmy-pv-pages' ) ); ?>"><?php esc_html_e( '記事別レポートを見る', 'jimmy-pv-monitor' ); ?></a>
				</div>
				<?php $this->renderTopPages( $topPages ); ?>
			</section>

			<section class="jimmy-pv-panel">
				<div class="jimmy-pv-panel-heading">
					<h2><?php esc_html_e( '流入元', 'jimmy-pv-monitor' ); ?></h2>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=jimmy-pv-referrers' ) ); ?>"><?php esc_html_e( '流入元レポートを見る', 'jimmy-pv-monitor' ); ?></a>
				</div>
				<div class="jimmy-pv-cards">
					<?php $this->renderSources( $sources, $campaignTotal ); ?>
					<?php $this->renderCountTable( __( '検索エンジン', 'jimmy-pv-monitor' ), $searchEngines, 'name' ); ?>
					<?php $this->renderCountTable( __( '参照元ドメイン', 'jimmy-pv-monitor' ), $domains, 'domain' ); ?>
				</div>
				<p class="description"><?php esc_html_e( 'UTMは、広告やSNS投稿などのリンクに付けて流入経路を見分けるための識別情報です。同じブログ内からのページ移動は流入元に含めません。UTM・広告PVは参照元分類と重複します。', 'jimmy-pv-monitor' ); ?></p>
			</section>

			<div class="notice notice-info inline"><p><?php esc_html_e( '記事本文に置いた外部リンクのクリック率は「外部リンククリック」で確認できます。同じ訪問中の「ページA → ページB → ページC」というサイト内の移動順序は、Pro版の「内部導線」で確認できます。', 'jimmy-pv-monitor' ); ?></p></div>
		</div>
		<?php
	}

	private function renderComparisonCard( string $title, int $todayTotal, float|int $baseline, string $baselineLabel, int $precision ): void {
		$difference = $todayTotal - $baseline;
		$percent    = 0 < $baseline ? ( $difference / $baseline ) * 100 : null;
		$prefix     = 0 < $difference ? '+' : '';
		?>
		<section class="jimmy-pv-card">
			<h2><?php echo esc_html( $title ); ?></h2>
			<p class="jimmy-pv-metric jimmy-pv-metric-small">
				<?php echo esc_html( $prefix . number_format_i18n( $difference, $precision ) . ' PV' ); ?>
			</p>
			<p>
				<?php echo null === $percent ? esc_html__( '増減率は算出できません', 'jimmy-pv-monitor' ) : esc_html( sprintf( '%+.1f%%', $percent ) ); ?>
			</p>
			<p class="description">
				<?php
				printf(
					/* translators: 1: today's PV, 2: comparison label, 3: comparison PV */
					esc_html__( '今日（現時点）%1$s PV ／ %2$s %3$s PV', 'jimmy-pv-monitor' ),
					esc_html( number_format_i18n( $todayTotal ) ),
					esc_html( $baselineLabel ),
					esc_html( number_format_i18n( $baseline, $precision ) )
				);
				?>
			</p>
		</section>
		<?php
	}

	/** @param array<int, array<string, mixed>> $rows */
	private function renderTopPages( array $rows ): void {
		if ( array() === $rows ) {
			echo '<p>' . esc_html__( '選択期間のPVデータはまだありません。', 'jimmy-pv-monitor' ) . '</p>';

			return;
		}
		?>
		<table class="widefat striped">
			<thead><tr>
				<th><?php esc_html_e( '記事', 'jimmy-pv-monitor' ); ?></th>
				<th class="jimmy-pv-number"><?php esc_html_e( '期間PV', 'jimmy-pv-monitor' ); ?></th>
				<th class="jimmy-pv-number"><?php esc_html_e( '累計PV', 'jimmy-pv-monitor' ); ?></th>
			</tr></thead>
			<tbody>
			<?php foreach ( $rows as $row ) : ?>
				<tr>
					<td><a href="<?php echo esc_url( (string) $row['canonical_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( (string) $row['title'] ); ?></a></td>
					<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['period_pv'] ) ); ?></td>
					<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['total_pv'] ) ); ?></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
		<?php
	}

	/** @param array<string, int> $sources */
	private function renderSources( array $sources, int $campaignTotal ): void {
		?>
		<section class="jimmy-pv-card"><h3><?php esc_html_e( '流入分類', 'jimmy-pv-monitor' ); ?></h3><table class="widefat striped"><tbody>
		<?php foreach ( array( 'direct', 'search', 'social', 'referral' ) as $type ) : ?>
			<tr><th><?php echo esc_html( SourceLabels::get( $type ) ); ?></th><td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) ( $sources[ $type ] ?? 0 ) ) ); ?></td></tr>
		<?php endforeach; ?>
			<tr><th><?php esc_html_e( 'UTM・広告（重複あり）', 'jimmy-pv-monitor' ); ?></th><td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( $campaignTotal ) ); ?></td></tr>
		</tbody></table></section>
		<?php
	}

	/** @param array<int, array<string, mixed>> $rows */
	private function renderCountTable( string $title, array $rows, string $labelKey ): void {
		?>
		<section class="jimmy-pv-card"><h3><?php echo esc_html( $title ); ?></h3>
		<?php if ( array() === $rows ) : ?><p><?php esc_html_e( 'データはまだありません。', 'jimmy-pv-monitor' ); ?></p><?php else : ?>
		<table class="widefat striped"><tbody><?php foreach ( $rows as $row ) : ?><tr><th><?php echo esc_html( (string) $row[ $labelKey ] ); ?></th><td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['pv'] ) ); ?></td></tr><?php endforeach; ?></tbody></table>
		<?php endif; ?></section>
		<?php
	}
}
