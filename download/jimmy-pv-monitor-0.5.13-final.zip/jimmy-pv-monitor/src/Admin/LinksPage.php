<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Links\LinkIndexBatch;
use Jimmy\PVMonitor\Reporting\AnalyticsRepository;
use Jimmy\PVMonitor\Reporting\DateRange;
use Jimmy\PVMonitor\Reporting\DateRangeFactory;
use WP_Error;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET values only filter and paginate this read-only report.

final class LinksPage {
	private const PER_PAGE_OPTIONS = array( 20, 50, 100, 200 );

	public function __construct(
		private readonly AnalyticsRepository $analytics,
		private readonly DateRangeFactory $dates,
		private readonly LinkIndexBatch $batch
	) {}

	public function register(): void {
		add_action( 'admin_post_jimmy_pv_rebuild_links', array( $this, 'rebuild' ) );
	}

	public function render(): void {
		if ( ! current_user_can( 'jimmy_pv_view_reports' ) ) {
			wp_die( esc_html__( 'このレポートを表示する権限がありません。', 'jimmy-pv-monitor' ) );
		}

		$range        = $this->dates->fromRequest( $_GET );
		$postTypes    = get_post_types( array( 'public' => true, 'publicly_queryable' => true ), 'objects' );
		unset( $postTypes['attachment'] );
		$postType     = $this->allowedGet( 'post_type', array_keys( $postTypes ), '' );
		$sourceSearch = $this->search( 'source' );
		$targetSearch = $this->search( 'target' );
		$orderBy      = $this->allowedGet( 'orderby', array( 'raw_clicks', 'source_pv', 'latest' ), 'raw_clicks' );
		$order        = $this->allowedGet( 'order', array( 'asc', 'desc' ), 'desc' );
		$page         = max( 1, $this->integerGet( 'paged', 1 ) );
		$perPage      = $this->integerGet( 'per_page', 50 );
		$perPage      = in_array( $perPage, self::PER_PAGE_OPTIONS, true ) ? $perPage : 50;
		$report       = $this->analytics->externalLinks( $range, $sourceSearch, $targetSearch, $postType, $orderBy, $order, $page, $perPage );
		$page         = (int) $report['page'];
		$status       = isset( $_GET['jimmy_pv_status'] ) && is_scalar( $_GET['jimmy_pv_status'] ) ? sanitize_key( wp_unslash( (string) $_GET['jimmy_pv_status'] ) ) : '';
		$proRoutePage = defined( 'JIMMY_PV_PRO_VERSION' ) && version_compare( (string) JIMMY_PV_PRO_VERSION, '0.1.7', '>=' ) ? 'jimmy-pv-pro-article-routes' : 'jimmy-pv-pro-journeys';
		$proRouteLabel = 'jimmy-pv-pro-article-routes' === $proRoutePage ? __( '記事別導線（Pro）を見る', 'jimmy-pv-monitor' ) : __( '内部導線（Pro）を見る', 'jimmy-pv-monitor' );
		?>
		<div class="wrap jimmy-pv-admin">
			<h1><?php esc_html_e( '外部リンククリック', 'jimmy-pv-monitor' ); ?></h1>
			<?php Tabs::render( 'jimmy-pv-links' ); ?>
			<div class="jimmy-pv-panel jimmy-pv-explainer">
				<h2><?php esc_html_e( 'この画面でわかること', 'jimmy-pv-monitor' ); ?></h2>
				<p><?php esc_html_e( '記事本文に置いた外部サイトへのリンクについて、「どの記事にある、どのリンクが、どのくらい押されたか」を確認できます。アフィリエイトリンクも外部リンクとして集計します。', 'jimmy-pv-monitor' ); ?></p>
				<p><?php esc_html_e( '選んだ期間に1回以上クリックされた外部リンクだけを表示します。サイト内リンクはこの画面には表示しません。', 'jimmy-pv-monitor' ); ?></p>
				<p><strong><?php esc_html_e( 'サイト内での読者の移動はPro版の機能です。', 'jimmy-pv-monitor' ); ?></strong> <?php esc_html_e( '「ページA → ページB → ページC」のような同じ訪問中の動きは、Pro版の「内部導線」で確認します。', 'jimmy-pv-monitor' ); ?></p>
				<p><?php esc_html_e( 'Pro版の「外部サイトへ離脱した記録」は、Pro計測中の訪問が外部リンクによって終了した回数です。この画面とは計測条件と数え方が異なるため、件数は一致しません。', 'jimmy-pv-monitor' ); ?></p>
				<?php if ( defined( 'JIMMY_PV_PRO_VERSION' ) && current_user_can( 'jimmy_pv_view_reports' ) ) : ?><p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=' . $proRoutePage ) ); ?>"><?php echo esc_html( $proRouteLabel ); ?></a></p><?php endif; ?>
				<details><summary><?php esc_html_e( '数字の見方', 'jimmy-pv-monitor' ); ?></summary><ul>
					<li><strong><?php esc_html_e( 'クリックがあった表示', 'jimmy-pv-monitor' ); ?></strong>: <?php esc_html_e( '1回のページ表示中にリンクが1回以上押された回数です。', 'jimmy-pv-monitor' ); ?></li>
					<li><strong><?php esc_html_e( 'クリック総数', 'jimmy-pv-monitor' ); ?></strong>: <?php esc_html_e( '同じページ表示中の繰り返しを含む、実際に押された合計回数です。', 'jimmy-pv-monitor' ); ?></li>
					<li><strong><?php esc_html_e( 'PVに対するクリック率', 'jimmy-pv-monitor' ); ?></strong>: <?php esc_html_e( 'リンクが1回以上クリックされたページ表示数を、そのリンクがあるページのPVで割った割合です。', 'jimmy-pv-monitor' ); ?></li>
				</ul></details>
			</div>
			<?php $this->statusNotice( $status ); ?>
			<?php $this->indexStatus(); ?>
			<div class="notice notice-info inline"><p><?php esc_html_e( '外部リンクの計測は、この更新版で記事内リンクの読み取りが完了したあとから始まります。更新前の外部リンククリックはさかのぼって集計できません。', 'jimmy-pv-monitor' ); ?></p></div>

			<?php $this->renderFilters( $range, $postTypes, $postType, $sourceSearch, $targetSearch, $orderBy, $order, $perPage ); ?>
			<p class="description"><?php echo esc_html( sprintf( '%s・外部リンクがクリックされたページ %s件', $range->label(), number_format_i18n( (int) $report['total'] ) ) ); ?></p>
			<p class="description"><?php esc_html_e( 'ページごとに1行で表示します。「クリック先の内訳を表示」を押すと、どの外部リンクがクリックされたかを確認できます。', 'jimmy-pv-monitor' ); ?></p>

			<div class="jimmy-pv-table-scroll"><table class="widefat striped jimmy-pv-report-table">
				<thead><tr>
					<th><?php esc_html_e( 'リンクがあるページ', 'jimmy-pv-monitor' ); ?></th>
					<th class="jimmy-pv-number"><?php esc_html_e( 'クリック先の数', 'jimmy-pv-monitor' ); ?></th>
					<th class="jimmy-pv-number"><?php echo wp_kses_post( $this->sortLink( __( 'クリック総数', 'jimmy-pv-monitor' ), 'raw_clicks', $orderBy, $order ) ); ?></th>
					<th class="jimmy-pv-number"><?php echo wp_kses_post( $this->sortLink( __( '掲載ページのPV', 'jimmy-pv-monitor' ), 'source_pv', $orderBy, $order ) ); ?></th>
					<th><?php echo wp_kses_post( $this->sortLink( __( '最終クリック日時', 'jimmy-pv-monitor' ), 'latest', $orderBy, $order ) ); ?></th>
				</tr></thead>
				<tbody><?php if ( array() === $report['rows'] ) : ?>
					<tr><td colspan="5"><?php esc_html_e( '選んだ期間にクリックされた外部リンクはありません。', 'jimmy-pv-monitor' ); ?></td></tr>
				<?php else : foreach ( $report['rows'] as $row ) : ?>
					<tr class="jimmy-pv-group-summary">
						<td><a href="<?php echo esc_url( (string) $row['source_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( (string) $row['source_title'] ); ?></a></td>
						<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['destination_count'] ) ); ?></td>
						<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['raw_clicks'] ) ); ?></td>
						<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['source_pv'] ) ); ?></td>
						<td><?php echo esc_html( $this->eventTime( (string) $row['last_clicked_at'] ) ); ?></td>
					</tr>
					<tr class="jimmy-pv-group-details"><td colspan="5"><details><summary><?php esc_html_e( 'クリック先の内訳を表示', 'jimmy-pv-monitor' ); ?></summary>
						<div class="jimmy-pv-breakdown-scroll"><table class="widefat striped jimmy-pv-breakdown-table"><thead><tr>
							<th><?php esc_html_e( 'リンクの文字', 'jimmy-pv-monitor' ); ?></th><th><?php esc_html_e( '外部リンク先', 'jimmy-pv-monitor' ); ?></th><th class="jimmy-pv-number"><?php esc_html_e( 'クリックがあった表示', 'jimmy-pv-monitor' ); ?></th><th class="jimmy-pv-number"><?php esc_html_e( 'クリック総数', 'jimmy-pv-monitor' ); ?></th><th class="jimmy-pv-number"><?php esc_html_e( 'PVに対するクリック率', 'jimmy-pv-monitor' ); ?></th><th><?php esc_html_e( '最終クリック日時', 'jimmy-pv-monitor' ); ?></th>
						</tr></thead><tbody><?php foreach ( (array) $row['destinations'] as $destination ) : ?><tr>
							<td><?php echo esc_html( '' !== (string) $destination['anchor_text'] ? (string) $destination['anchor_text'] : __( '（画像・文字なし）', 'jimmy-pv-monitor' ) ); ?></td>
							<td class="jimmy-pv-url-cell"><strong><?php echo esc_html( (string) $destination['target_domain'] ); ?></strong><br><a href="<?php echo esc_url( (string) $destination['target_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( (string) $destination['target_url'] ); ?></a></td>
							<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $destination['clicked_views'] ) ); ?></td><td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $destination['raw_clicks'] ) ); ?></td><td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (float) $destination['click_rate'] * 100, 1 ) . '%' ); ?></td><td><?php echo esc_html( $this->eventTime( (string) $destination['last_clicked_at'] ) ); ?></td>
						</tr><?php endforeach; ?></tbody></table></div>
					</details></td></tr>
				<?php endforeach; endif; ?></tbody>
			</table></div>
			<?php $this->pagination( (int) $report['total'], $page, $perPage ); ?>
		</div>
		<?php
	}

	public function rebuild(): void {
		if ( ! current_user_can( 'jimmy_pv_manage_settings' ) ) {
			wp_die( esc_html__( '外部リンク索引を再構築する権限がありません。', 'jimmy-pv-monitor' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'jimmy_pv_rebuild_links', 'jimmy_pv_nonce' );
		$result = $this->batch->restart();
		$url = add_query_arg( array( 'page' => 'jimmy-pv-links', 'jimmy_pv_status' => $result instanceof WP_Error || false === $result ? 'rebuild-error' : 'rebuilding' ), admin_url( 'admin.php' ) );
		wp_safe_redirect( $url );
		exit;
	}

	/** @param array<string, object> $postTypes */
	private function renderFilters( DateRange $range, array $postTypes, string $postType, string $sourceSearch, string $targetSearch, string $orderBy, string $order, int $perPage ): void {
		?>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="jimmy-pv-filter-form">
			<input type="hidden" name="page" value="jimmy-pv-links">
			<label><?php esc_html_e( '期間', 'jimmy-pv-monitor' ); ?><select name="range" data-jimmy-pv-range><?php foreach ( array( 'today' => __( '今日', 'jimmy-pv-monitor' ), '3d' => __( '過去3日（今日を含む）', 'jimmy-pv-monitor' ), '7d' => __( '過去7日', 'jimmy-pv-monitor' ), '30d' => __( '過去30日', 'jimmy-pv-monitor' ), 'custom' => __( '任意期間', 'jimmy-pv-monitor' ) ) as $value => $label ) : ?><option value="<?php echo esc_attr( $value ); ?>" <?php selected( $range->preset, $value ); ?>><?php echo esc_html( $label ); ?></option><?php endforeach; ?></select></label>
			<span class="jimmy-pv-custom-dates" data-jimmy-pv-custom-dates><label><?php esc_html_e( '開始日', 'jimmy-pv-monitor' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $range->fromSql() ); ?>"></label><label><?php esc_html_e( '終了日', 'jimmy-pv-monitor' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $range->toSql() ); ?>"></label></span>
			<label><?php esc_html_e( '投稿タイプ', 'jimmy-pv-monitor' ); ?><select name="post_type"><option value=""><?php esc_html_e( 'すべて', 'jimmy-pv-monitor' ); ?></option><?php foreach ( $postTypes as $slug => $object ) : ?><option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $postType, $slug ); ?>><?php echo esc_html( $object->labels->singular_name ); ?></option><?php endforeach; ?></select></label>
			<label><?php esc_html_e( 'リンクがあるページ', 'jimmy-pv-monitor' ); ?> <input type="search" name="source" value="<?php echo esc_attr( $sourceSearch ); ?>" maxlength="100"></label>
			<label><?php esc_html_e( '外部リンク先', 'jimmy-pv-monitor' ); ?> <input type="search" name="target" value="<?php echo esc_attr( $targetSearch ); ?>" maxlength="100"></label>
			<label><?php esc_html_e( '表示件数', 'jimmy-pv-monitor' ); ?><select name="per_page"><?php foreach ( self::PER_PAGE_OPTIONS as $option ) : ?><option value="<?php echo esc_attr( (string) $option ); ?>" <?php selected( $perPage, $option ); ?>><?php echo esc_html( (string) $option ); ?></option><?php endforeach; ?></select></label>
			<input type="hidden" name="orderby" value="<?php echo esc_attr( $orderBy ); ?>"><input type="hidden" name="order" value="<?php echo esc_attr( $order ); ?>">
			<button type="submit" class="button button-primary"><?php esc_html_e( '絞り込む', 'jimmy-pv-monitor' ); ?></button>
		</form>
		<?php
	}

	private function indexStatus(): void {
		$state = $this->batch->state();
		$status = (string) ( $state['status'] ?? 'running' );
		$processed = max( 0, (int) ( $state['processed'] ?? 0 ) );
		$total = max( 0, (int) ( $state['total'] ?? 0 ) );
		$errors = max( 0, (int) ( $state['errors'] ?? 0 ) );
		?>
		<div class="notice notice-info inline"><p>
			<?php
			if ( 'complete' === $status ) {
				echo esc_html( sprintf( '記事内の外部リンクの読み取りが完了しました（%1$s/%2$s件、確認できなかった記事%3$s件）。', number_format_i18n( $processed ), number_format_i18n( $total ), number_format_i18n( $errors ) ) );
			} elseif ( 'error' === $status ) {
				echo esc_html( sprintf( '記事内の外部リンクの読み取りが途中で止まりました（%1$s/%2$s件、確認できなかった記事%3$s件）。「外部リンクを読み直す」を押してください。', number_format_i18n( $processed ), number_format_i18n( $total ), number_format_i18n( $errors ) ) );
			} else {
				echo esc_html( sprintf( '記事内の外部リンクを読み取っています（%1$s/%2$s件、確認できなかった記事%3$s件）。', number_format_i18n( $processed ), number_format_i18n( $total ), number_format_i18n( $errors ) ) );
			}
			?>
			<?php if ( current_user_can( 'jimmy_pv_manage_settings' ) ) : ?>
				</p><form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="jimmy-pv-inline-form"><input type="hidden" name="action" value="jimmy_pv_rebuild_links"><?php wp_nonce_field( 'jimmy_pv_rebuild_links', 'jimmy_pv_nonce' ); ?><button type="submit" class="button"><?php esc_html_e( '外部リンクを読み直す', 'jimmy-pv-monitor' ); ?></button></form><p>
			<?php endif; ?>
		</p></div>
		<?php
	}

	private function statusNotice( string $status ): void {
		if ( ! in_array( $status, array( 'rebuilding', 'rebuild-error' ), true ) ) {
			return;
		}
		$class = 'rebuilding' === $status ? 'success' : 'error';
		$message = 'rebuilding' === $status ? __( '記事内の外部リンクの読み直しを開始しました。', 'jimmy-pv-monitor' ) : __( '記事内の外部リンクの読み直しを開始できませんでした。', 'jimmy-pv-monitor' );
		echo '<div class="notice notice-' . esc_attr( $class ) . ' is-dismissible"><p>' . esc_html( $message ) . '</p></div>';
	}

	private function search( string $key ): string {
		$value = isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? sanitize_text_field( wp_unslash( (string) $_GET[ $key ] ) ) : '';
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, 100 ) : substr( $value, 0, 100 );
	}

	/** @param string[] $allowed */
	private function allowedGet( string $key, array $allowed, string $fallback ): string {
		$value = isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? sanitize_key( wp_unslash( (string) $_GET[ $key ] ) ) : '';
		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	private function integerGet( string $key, int $fallback ): int {
		return isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? absint( wp_unslash( (string) $_GET[ $key ] ) ) : $fallback;
	}

	private function sortLink( string $label, string $column, string $currentColumn, string $currentOrder ): string {
		$order = $column === $currentColumn && 'desc' === $currentOrder ? 'asc' : 'desc';
		return sprintf( '<a href="%1$s">%2$s</a>', esc_url( add_query_arg( array( 'orderby' => $column, 'order' => $order, 'paged' => false ) ) ), esc_html( $label ) );
	}

	private function eventTime( string $utc ): string {
		return '' !== $utc
			? get_date_from_gmt( $utc, 'Y年n月j日 H:i:s' )
			: __( '更新前のため記録なし', 'jimmy-pv-monitor' );
	}

	private function pagination( int $total, int $page, int $perPage ): void {
		$totalPages = (int) ceil( $total / $perPage );
		if ( 1 >= $totalPages ) {
			return;
		}
		$base = str_replace( '999999999', '%#%', add_query_arg( 'paged', 999999999 ) );
		echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => $base, 'format' => '', 'current' => $page, 'total' => $totalPages, 'prev_text' => __( '前へ', 'jimmy-pv-monitor' ), 'next_text' => __( '次へ', 'jimmy-pv-monitor' ) ) ) ) . '</div></div>';
	}
}
