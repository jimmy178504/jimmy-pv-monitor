<?php

namespace Jimmy\PVMonitor\Reporting;

use Generator;
use Jimmy\PVMonitor\Database\TableNames;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Report values are prepared; table identifiers come from the internal TableNames registry.

final class AnalyticsRepository {
	private const EXPORT_BATCH_SIZE = 500;

	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function total( DateRange $range ): int {
		return (int) $this->remember(
			'total|' . $range->fromSql() . '|' . $range->toSql(),
			$range,
			fn (): int => max(
				0,
				(int) $this->wpdb->get_var(
					$this->wpdb->prepare(
						"SELECT COALESCE(SUM(pv),0) FROM {$this->tables->daily()} WHERE stat_date BETWEEN %s AND %s",
						$range->fromSql(),
						$range->toSql()
					)
				)
			)
		);
	}

	/** @return array<int, array{date:string,pv:int}> */
	public function series( DateRange $range ): array {
		/** @var array<int, array{date:string,pv:int}> $series */
		$series = $this->remember(
			'series|' . $range->fromSql() . '|' . $range->toSql(),
			$range,
			function () use ( $range ): array {
				$query = $this->wpdb->prepare(
					"SELECT stat_date, SUM(pv) AS pv FROM {$this->tables->daily()}
WHERE stat_date BETWEEN %s AND %s GROUP BY stat_date ORDER BY stat_date ASC",
					$range->fromSql(),
					$range->toSql()
				);
				$rows = (array) $this->wpdb->get_results( $query, ARRAY_A );
				$map  = array();
				foreach ( $rows as $row ) {
					$map[ (string) $row['stat_date'] ] = max( 0, (int) $row['pv'] );
				}

				$result = array();
				foreach ( $range->dates() as $date ) {
					$result[] = array( 'date' => $date, 'pv' => $map[ $date ] ?? 0 );
				}

				return $result;
			}
		);

		return $series;
	}

	/** @return array<int, array<string, mixed>> */
	public function topPages( DateRange $range, int $limit = 10 ): array {
		$limit = max( 1, min( 50, $limit ) );

		/** @var array<int, array<string, mixed>> $rows */
		$rows = $this->remember(
			'top|' . $range->fromSql() . '|' . $range->toSql() . '|' . $limit,
			$range,
			function () use ( $range, $limit ): array {
				$query = $this->wpdb->prepare(
					"SELECT p.object_id,p.title,p.canonical_url,p.total_pv,w.post_type,SUM(d.pv) AS period_pv
FROM {$this->tables->daily()} d
INNER JOIN {$this->tables->pages()} p ON p.id = d.page_id
INNER JOIN {$this->wpdb->posts} w ON w.ID = p.object_id
WHERE d.stat_date BETWEEN %s AND %s
AND p.object_type = 'post' AND p.deleted_at IS NULL
AND w.post_status = 'publish' AND w.post_password = ''
GROUP BY p.id,p.object_id,p.title,p.canonical_url,p.total_pv,w.post_type
ORDER BY period_pv DESC,p.id ASC LIMIT %d",
					$range->fromSql(),
					$range->toSql(),
					$limit
				);

				return (array) $this->wpdb->get_results( $query, ARRAY_A );
			}
		);

		return $this->normalizePageRows( $rows );
	}

	/** @return array<string, int> */
	public function sourceSummary( DateRange $range ): array {
		/** @var array<string, int> $summary */
		$summary = $this->remember(
			'sources|' . $range->fromSql() . '|' . $range->toSql(),
			$range,
			function () use ( $range ): array {
				$query = $this->wpdb->prepare(
					"SELECT CASE WHEN d.referrer_id = 0 THEN 'direct' ELSE r.source_type END AS source_type,SUM(d.pv) AS pv
FROM {$this->tables->referrerDaily()} d
LEFT JOIN {$this->tables->referrers()} r ON r.id = d.referrer_id
WHERE d.stat_date BETWEEN %s AND %s AND (d.referrer_id = 0 OR r.source_type <> 'internal') GROUP BY source_type",
					$range->fromSql(),
					$range->toSql()
				);
				$result = array_fill_keys( array( 'direct', 'search', 'social', 'referral' ), 0 );
				foreach ( (array) $this->wpdb->get_results( $query, ARRAY_A ) as $row ) {
					$type = (string) ( $row['source_type'] ?? '' );
					if ( array_key_exists( $type, $result ) ) {
						$result[ $type ] = max( 0, (int) $row['pv'] );
					}
				}

				return $result;
			}
		);

		return $summary;
	}

	/** @return array<int, array{name:string,pv:int}> */
	public function searchEngines( DateRange $range, int $limit = 10 ): array {
		return $this->sourceNames( $range, 'search', $limit );
	}

	/** @return array<int, array{domain:string,pv:int}> */
	public function referrerDomains( DateRange $range, int $limit = 10 ): array {
		$limit = max( 1, min( 50, $limit ) );
		/** @var array<int, array{domain:string,pv:int}> $rows */
		$rows = $this->remember(
			'domains|' . $range->fromSql() . '|' . $range->toSql() . '|' . $limit,
			$range,
			function () use ( $range, $limit ): array {
				$query = $this->wpdb->prepare(
					"SELECT r.domain,SUM(d.pv) AS pv FROM {$this->tables->referrerDaily()} d
INNER JOIN {$this->tables->referrers()} r ON r.id = d.referrer_id
WHERE d.stat_date BETWEEN %s AND %s AND r.source_type <> 'internal'
GROUP BY r.domain ORDER BY pv DESC,r.domain ASC LIMIT %d",
					$range->fromSql(),
					$range->toSql(),
					$limit
				);
				return $this->normalizeCountRows( (array) $this->wpdb->get_results( $query, ARRAY_A ) );
			}
		);

		return $rows;
	}

	public function campaignTotal( DateRange $range ): int {
		return (int) $this->remember(
			'campaign-total|' . $range->fromSql() . '|' . $range->toSql(),
			$range,
			fn (): int => max( 0, (int) $this->wpdb->get_var(
				$this->wpdb->prepare(
					"SELECT COALESCE(SUM(pv),0) FROM {$this->tables->campaignDaily()} WHERE stat_date BETWEEN %s AND %s",
					$range->fromSql(),
					$range->toSql()
				)
			) )
		);
	}

	/** @return array{rows:array<int,array<string,mixed>>,total:int,page:int} */
	public function referrers(
		DateRange $range,
		string $search,
		string $sourceType,
		string $orderBy,
		string $order,
		int $page,
		int $perPage
	): array {
		$orderColumns = array(
			'period_pv'  => 'period_pv',
			'domain'     => 'domain',
			'source_type' => 'source_type',
		);
		$orderBy = isset( $orderColumns[ $orderBy ] ) ? $orderBy : 'period_pv';
		$order   = 'asc' === strtolower( $order ) ? 'ASC' : 'DESC';
		$page    = max( 1, $page );
		$perPage = max( 1, min( 200, $perPage ) );
		$where   = "d.stat_date BETWEEN %s AND %s AND (d.referrer_id = 0 OR r.source_type <> 'internal')";
		$params  = array( $range->fromSql(), $range->toSql() );

		if ( 'direct' === $sourceType ) {
			$where .= ' AND d.referrer_id = 0';
		} elseif ( in_array( $sourceType, array( 'search', 'social', 'referral' ), true ) ) {
			$where   .= ' AND r.source_type = %s';
			$params[] = $sourceType;
		}
		if ( '' !== $search ) {
			$like = '%' . $this->wpdb->esc_like( $search ) . '%';
			$where .= ' AND (r.referrer_url LIKE %s OR r.domain LIKE %s OR p.title LIKE %s OR p.canonical_url LIKE %s)';
			array_push( $params, $like, $like, $like, $like );
		}

		$from = " FROM {$this->tables->referrerDaily()} d
LEFT JOIN {$this->tables->referrers()} r ON r.id = d.referrer_id
INNER JOIN {$this->tables->pages()} p ON p.id = d.page_id WHERE {$where}";
		$countSql = 'SELECT COUNT(DISTINCT d.referrer_id)' . $from;
		$total = max( 0, (int) $this->wpdb->get_var( $this->prepare( $countSql, $params ) ) );
		$page = min( $page, max( 1, (int) ceil( $total / $perPage ) ) );
		$offset = ( $page - 1 ) * $perPage;

		$sql = "SELECT d.referrer_id,COALESCE(r.referrer_url,'') AS referrer_url,COALESCE(r.domain,'') AS domain,
CASE WHEN d.referrer_id = 0 THEN 'direct' ELSE r.source_type END AS source_type,COALESCE(r.source_name,'') AS source_name,
		COUNT(DISTINCT d.page_id) AS landing_count,SUM(d.pv) AS period_pv{$from}
GROUP BY d.referrer_id,r.referrer_url,r.domain,r.source_type,r.source_name
ORDER BY {$orderColumns[ $orderBy ]} {$order},d.referrer_id ASC LIMIT %d OFFSET %d";
		$rows = $this->normalizeCountRows( (array) $this->wpdb->get_results(
			$this->wpdb->prepare( $sql, ...array_merge( $params, array( $perPage, $offset ) ) ),
			ARRAY_A
		) );

		$referrerIds = array_map( static fn ( array $row ): int => (int) $row['referrer_id'], $rows );
		if ( array() !== $referrerIds ) {
			$placeholders = implode( ',', array_fill( 0, count( $referrerIds ), '%d' ) );
			$detailSql = "SELECT d.referrer_id,p.id AS landing_page_id,p.object_type,p.title AS landing_title,p.canonical_url AS landing_url,SUM(d.pv) AS period_pv{$from}
AND d.referrer_id IN ({$placeholders})
GROUP BY d.referrer_id,d.page_id,p.id,p.object_type,p.title,p.canonical_url
ORDER BY d.referrer_id ASC,period_pv DESC,d.page_id ASC";
			$details = $this->normalizeCountRows( (array) $this->wpdb->get_results( $this->wpdb->prepare( $detailSql, ...array_merge( $params, $referrerIds ) ), ARRAY_A ) );
			$byReferrer = array();
			foreach ( $details as $detail ) {
				$byReferrer[ (int) $detail['referrer_id'] ][] = $detail;
			}
			foreach ( $rows as &$row ) {
				$row['landings'] = $byReferrer[ (int) $row['referrer_id'] ] ?? array();
			}
			unset( $row );
		}

		return array( 'rows' => $rows, 'total' => $total, 'page' => $page );
	}

	/** @return array<int, array<string, mixed>> */
	public function campaigns( DateRange $range, int $limit = 50 ): array {
		$limit = max( 1, min( 200, $limit ) );
		$query = $this->wpdb->prepare(
			"SELECT c.utm_source,c.utm_medium,c.utm_campaign,c.utm_term,c.utm_content,c.ad_platform,
p.title AS landing_title,p.canonical_url AS landing_url,SUM(c.pv) AS period_pv
FROM {$this->tables->campaignDaily()} c INNER JOIN {$this->tables->pages()} p ON p.id = c.page_id
WHERE c.stat_date BETWEEN %s AND %s
GROUP BY c.campaign_key,c.page_id,c.utm_source,c.utm_medium,c.utm_campaign,c.utm_term,c.utm_content,c.ad_platform,p.title,p.canonical_url
ORDER BY period_pv DESC,c.campaign_key ASC LIMIT %d",
			$range->fromSql(),
			$range->toSql(),
			$limit
		);

		return $this->normalizeCountRows( (array) $this->wpdb->get_results( $query, ARRAY_A ) );
	}

	/** @return array{rows:array<int,array<string,mixed>>,total:int,page:int} */
	public function externalLinks(
		DateRange $range,
		string $sourceSearch,
		string $targetSearch,
		string $postType,
		string $orderBy,
		string $order,
		int $page,
		int $perPage
	): array {
		$orderColumns = array(
			'clicks'     => 'clicked_views',
			'raw_clicks' => 'raw_clicks',
			'rate'       => 'click_rate',
			'source_pv'  => 'source_pv',
			'latest'     => 'last_clicked_at',
		);
		$orderBy = isset( $orderColumns[ $orderBy ] ) ? $orderBy : 'clicks';
		$order   = 'asc' === strtolower( $order ) ? 'ASC' : 'DESC';
		$page    = max( 1, $page );
		$perPage = max( 1, min( 200, $perPage ) );
		$where   = "l.link_type = 'external'";
		$whereParams = array();

		if ( '' !== $postType ) {
			$where .= ' AND sw.post_type = %s';
			$whereParams[] = $postType;
		}
		if ( '' !== $sourceSearch ) {
			$like = '%' . $this->wpdb->esc_like( $sourceSearch ) . '%';
			$where .= ' AND (sp.title LIKE %s OR sp.canonical_url LIKE %s)';
			array_push( $whereParams, $like, $like );
		}
		if ( '' !== $targetSearch ) {
			$like = '%' . $this->wpdb->esc_like( $targetSearch ) . '%';
			$where .= ' AND (l.target_url LIKE %s OR l.anchor_text LIKE %s)';
			array_push( $whereParams, $like, $like );
		}

		$metrics = "SELECT link_id,SUM(impression_views) AS impression_views,SUM(clicked_views) AS clicked_views,SUM(raw_clicks) AS raw_clicks,MAX(last_clicked_at) AS last_clicked_at
FROM {$this->tables->internalLinkDaily()} WHERE stat_date BETWEEN %s AND %s
GROUP BY link_id HAVING SUM(raw_clicks) > 0";
		$countFrom = " FROM {$this->tables->internalLinks()} l
INNER JOIN {$this->tables->pages()} sp ON sp.id = l.source_page_id
LEFT JOIN {$this->wpdb->posts} sw ON sw.ID = sp.object_id
INNER JOIN ({$metrics}) m ON m.link_id = l.id
WHERE {$where}";
		$countParams = array_merge( array( $range->fromSql(), $range->toSql() ), $whereParams );
		$total = max( 0, (int) $this->wpdb->get_var( $this->prepare( 'SELECT COUNT(DISTINCT l.source_page_id)' . $countFrom, $countParams ) ) );
		$page = min( $page, max( 1, (int) ceil( $total / $perPage ) ) );
		$offset = ( $page - 1 ) * $perPage;

		$pageviews = "SELECT page_id,SUM(pv) AS source_pv FROM {$this->tables->daily()}
WHERE stat_date BETWEEN %s AND %s GROUP BY page_id";
		$sql = "SELECT l.source_page_id,sp.object_id AS source_object_id,sp.object_type AS source_object_type,sp.title AS source_title,sp.canonical_url AS source_url,
COUNT(l.id) AS destination_count,SUM(m.clicked_views) AS clicked_views,SUM(m.raw_clicks) AS raw_clicks,MAX(m.last_clicked_at) AS last_clicked_at,
COALESCE(pv.source_pv,0) AS source_pv,
CASE WHEN COALESCE(pv.source_pv,0) > 0
THEN LEAST(SUM(m.clicked_views),COALESCE(pv.source_pv,0)) / COALESCE(pv.source_pv,0) ELSE 0 END AS click_rate
FROM {$this->tables->internalLinks()} l
INNER JOIN {$this->tables->pages()} sp ON sp.id = l.source_page_id
LEFT JOIN {$this->wpdb->posts} sw ON sw.ID = sp.object_id
INNER JOIN ({$metrics}) m ON m.link_id = l.id
LEFT JOIN ({$pageviews}) pv ON pv.page_id = l.source_page_id
WHERE {$where}
GROUP BY l.source_page_id,sp.object_id,sp.object_type,sp.title,sp.canonical_url,pv.source_pv
ORDER BY {$orderColumns[ $orderBy ]} {$order},l.source_page_id ASC LIMIT %d OFFSET %d";
		$params = array_merge(
			array( $range->fromSql(), $range->toSql(), $range->fromSql(), $range->toSql() ),
			$whereParams,
			array( $perPage, $offset )
		);
		$rows = $this->normalizeLinkRows( (array) $this->wpdb->get_results( $this->wpdb->prepare( $sql, ...$params ), ARRAY_A ) );

		$sourceIds = array_map( static fn ( array $row ): int => (int) $row['source_page_id'], $rows );
		if ( array() !== $sourceIds ) {
			$placeholders = implode( ',', array_fill( 0, count( $sourceIds ), '%d' ) );
			$detailSql = "SELECT l.id,l.source_page_id,l.target_page_id,l.target_url,l.anchor_text,l.is_active,l.link_type,
sp.object_id AS source_object_id,sp.title AS source_title,sp.canonical_url AS source_url,
COALESCE(m.impression_views,0) AS impression_views,COALESCE(m.clicked_views,0) AS clicked_views,
COALESCE(m.raw_clicks,0) AS raw_clicks,m.last_clicked_at,COALESCE(pv.source_pv,0) AS source_pv,
CASE WHEN COALESCE(pv.source_pv,0) > 0
THEN LEAST(COALESCE(m.clicked_views,0),COALESCE(pv.source_pv,0)) / COALESCE(pv.source_pv,0) ELSE 0 END AS click_rate
FROM {$this->tables->internalLinks()} l
INNER JOIN {$this->tables->pages()} sp ON sp.id = l.source_page_id
LEFT JOIN {$this->wpdb->posts} sw ON sw.ID = sp.object_id
INNER JOIN ({$metrics}) m ON m.link_id = l.id
LEFT JOIN ({$pageviews}) pv ON pv.page_id = l.source_page_id
WHERE {$where} AND l.source_page_id IN ({$placeholders})
ORDER BY l.source_page_id ASC,m.raw_clicks DESC,l.id ASC";
			$detailParams = array_merge(
				array( $range->fromSql(), $range->toSql(), $range->fromSql(), $range->toSql() ),
				$whereParams,
				$sourceIds
			);
			$details = $this->normalizeLinkRows( (array) $this->wpdb->get_results( $this->wpdb->prepare( $detailSql, ...$detailParams ), ARRAY_A ) );
			$bySource = array();
			foreach ( $details as $detail ) {
				$bySource[ (int) $detail['source_page_id'] ][] = $detail;
			}
			foreach ( $rows as &$row ) {
				$row['destinations'] = $bySource[ (int) $row['source_page_id'] ] ?? array();
			}
			unset( $row );
		}

		return array( 'rows' => $rows, 'total' => $total, 'page' => $page );
	}

	/** @return array{rows:array<int,array<string,mixed>>,total:int,page:int} */
	public function internalLinks(
		DateRange $range,
		string $sourceSearch,
		string $targetSearch,
		string $postType,
		string $orderBy,
		string $order,
		int $page,
		int $perPage
	): array {
		return $this->externalLinks( $range, $sourceSearch, $targetSearch, $postType, $orderBy, $order, $page, $perPage );
	}

	public function hasLinkDataQualityIssue( DateRange $range ): bool {
		$query = $this->wpdb->prepare(
			"SELECT 1 FROM {$this->tables->internalLinkDaily()} d
INNER JOIN {$this->tables->internalLinks()} l ON l.id = d.link_id
WHERE l.link_type = 'external' AND d.stat_date BETWEEN %s AND %s AND d.clicked_views > d.impression_views LIMIT 1",
			$range->fromSql(),
			$range->toSql()
		);

		return 1 === (int) $this->wpdb->get_var( $query );
	}

	/**
	 * @return array{rows:array<int,array<string,mixed>>,total:int,page:int}
	 */
	public function pages(
		DateRange $range,
		string $search,
		string $postType,
		string $orderBy,
		string $order,
		int $page,
		int $perPage,
		bool $includeHome
	): array {
		$orderColumns = array(
			'period_pv' => 'period_pv',
			'total_pv'  => 'p.total_pv',
			'title'     => 'p.title',
		);
		$orderBy      = isset( $orderColumns[ $orderBy ] ) ? $orderBy : 'period_pv';
		$order        = 'asc' === strtolower( $order ) ? 'ASC' : 'DESC';
		$page         = max( 1, $page );
		$perPage      = max( 1, min( 200, $perPage ) );
		$where        = "p.deleted_at IS NULL AND ((p.object_type = 'post' AND w.post_status = 'publish' AND w.post_password = '')";
		$where       .= $includeHome ? " OR p.object_type = 'home')" : ')';
		$params       = array();

		if ( '' !== $postType ) {
			$where   .= " AND p.object_type = 'post' AND w.post_type = %s";
			$params[] = $postType;
		}

		if ( '' !== $search ) {
			$like     = '%' . $this->wpdb->esc_like( $search ) . '%';
			$where   .= ' AND (p.title LIKE %s OR p.canonical_url LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}

		$from = " FROM {$this->tables->pages()} p
LEFT JOIN {$this->wpdb->posts} w ON w.ID = p.object_id
INNER JOIN {$this->tables->daily()} d ON d.page_id = p.id AND d.stat_date BETWEEN %s AND %s AND d.pv > 0
WHERE {$where}";
		$countSql = 'SELECT COUNT(DISTINCT p.id)' . $from;
		$queryParams = array_merge( array( $range->fromSql(), $range->toSql() ), $params );
		$total    = max( 0, (int) $this->wpdb->get_var( $this->prepare( $countSql, $queryParams ) ) );
		$page     = min( $page, max( 1, (int) ceil( $total / $perPage ) ) );
		$offset   = ( $page - 1 ) * $perPage;

		$sql = "SELECT p.object_type,p.object_id,p.title,p.canonical_url,p.total_pv,
CASE WHEN p.object_type = 'home' THEN 'home' ELSE COALESCE(w.post_type,'') END AS post_type,
COALESCE(w.post_status,'') AS post_status,
COALESCE(SUM(d.pv),0) AS period_pv
{$from}
GROUP BY p.id,p.object_type,p.object_id,p.title,p.canonical_url,p.total_pv,w.post_type,w.post_status
ORDER BY {$orderColumns[ $orderBy ]} {$order},p.id ASC LIMIT %d OFFSET %d";
		$rowParams = array_merge( $queryParams, array( $perPage, $offset ) );
		$rows      = (array) $this->wpdb->get_results( $this->wpdb->prepare( $sql, ...$rowParams ), ARRAY_A );

		return array(
			'rows'  => $this->normalizePageRows( $rows ),
			'total' => $total,
			'page'  => $page,
		);
	}

	/** @return Generator<int, array{date:string,pv:int}> */
	public function dailyExport( DateRange $range ): Generator {
		$cursor   = '';
		$nextDate = $range->from;
		do {
			$query = $this->wpdb->prepare(
				"SELECT stat_date,SUM(pv) AS pv FROM {$this->tables->daily()}
WHERE stat_date BETWEEN %s AND %s AND stat_date > %s
GROUP BY stat_date ORDER BY stat_date ASC LIMIT %d",
				$range->fromSql(),
				$range->toSql(),
				$cursor,
				self::EXPORT_BATCH_SIZE
			);
			$rows = (array) $this->wpdb->get_results( $query, ARRAY_A );
			foreach ( $rows as $row ) {
				$rowDate = (string) $row['stat_date'];
				while ( $nextDate->format( 'Y-m-d' ) < $rowDate ) {
					yield array( 'date' => $nextDate->format( 'Y-m-d' ), 'pv' => 0 );
					$nextDate = $nextDate->modify( '+1 day' );
				}

				$cursor = $rowDate;
				yield array( 'date' => $rowDate, 'pv' => max( 0, (int) $row['pv'] ) );
				$nextDate = $nextDate->modify( '+1 day' );
			}
			$row_count = count( $rows );
		} while ( self::EXPORT_BATCH_SIZE === $row_count );

		while ( $nextDate <= $range->to ) {
			yield array( 'date' => $nextDate->format( 'Y-m-d' ), 'pv' => 0 );
			$nextDate = $nextDate->modify( '+1 day' );
		}
	}

	/** @return Generator<int, array<string, mixed>> */
	public function pageExport( DateRange $range, bool $includeHome ): Generator {
		$cursor = 0;
		$homeWhere = $includeHome ? " OR p.object_type = 'home')" : ')';
		do {
			$query = $this->wpdb->prepare(
				"SELECT p.id,p.object_type,p.object_id,p.title,p.canonical_url,p.total_pv,
CASE WHEN p.object_type = 'home' THEN 'home' ELSE COALESCE(w.post_type,'') END AS post_type,SUM(d.pv) AS period_pv
FROM {$this->tables->pages()} p
LEFT JOIN {$this->wpdb->posts} w ON w.ID = p.object_id
INNER JOIN {$this->tables->daily()} d ON d.page_id = p.id AND d.stat_date BETWEEN %s AND %s AND d.pv > 0
WHERE p.id > %d AND p.deleted_at IS NULL
AND ((p.object_type = 'post' AND w.post_status = 'publish' AND w.post_password = ''){$homeWhere}
GROUP BY p.id,p.object_type,p.object_id,p.title,p.canonical_url,p.total_pv,w.post_type
ORDER BY p.id ASC LIMIT %d",
				$range->fromSql(),
				$range->toSql(),
				$cursor,
				self::EXPORT_BATCH_SIZE
			);
			$rows = (array) $this->wpdb->get_results( $query, ARRAY_A );
			foreach ( $this->normalizePageRows( $rows ) as $row ) {
				$cursor = (int) $row['id'];
				yield $row;
			}
			$row_count = count( $rows );
		} while ( self::EXPORT_BATCH_SIZE === $row_count );
	}

	/** @return Generator<int, array<string, mixed>> */
	public function referrerExport( DateRange $range ): Generator {
		$cursor = 0;
		do {
			$query = $this->wpdb->prepare(
				"SELECT d.id,d.stat_date,CASE WHEN d.referrer_id = 0 THEN 'direct' ELSE r.source_type END AS source_type,
COALESCE(r.source_name,'') AS source_name,COALESCE(r.domain,'') AS domain,COALESCE(r.referrer_url,'') AS referrer_url,
p.title AS landing_title,p.canonical_url AS landing_url,d.pv
FROM {$this->tables->referrerDaily()} d LEFT JOIN {$this->tables->referrers()} r ON r.id = d.referrer_id
INNER JOIN {$this->tables->pages()} p ON p.id = d.page_id
WHERE d.id > %d AND d.stat_date BETWEEN %s AND %s AND (d.referrer_id = 0 OR r.source_type <> 'internal') ORDER BY d.id ASC LIMIT %d",
				$cursor,
				$range->fromSql(),
				$range->toSql(),
				self::EXPORT_BATCH_SIZE
			);
			$rows = (array) $this->wpdb->get_results( $query, ARRAY_A );
			foreach ( $this->normalizeCountRows( $rows ) as $row ) {
				$cursor = (int) $row['id'];
				yield $row;
			}
			$row_count = count( $rows );
		} while ( self::EXPORT_BATCH_SIZE === $row_count );
	}

	/** @return Generator<int, array<string, mixed>> */
	public function campaignExport( DateRange $range ): Generator {
		$cursor = 0;
		do {
			$query = $this->wpdb->prepare(
				"SELECT c.id,c.stat_date,c.utm_source,c.utm_medium,c.utm_campaign,c.utm_term,c.utm_content,c.ad_platform,
p.title AS landing_title,p.canonical_url AS landing_url,c.pv
FROM {$this->tables->campaignDaily()} c INNER JOIN {$this->tables->pages()} p ON p.id = c.page_id
WHERE c.id > %d AND c.stat_date BETWEEN %s AND %s ORDER BY c.id ASC LIMIT %d",
				$cursor,
				$range->fromSql(),
				$range->toSql(),
				self::EXPORT_BATCH_SIZE
			);
			$rows = (array) $this->wpdb->get_results( $query, ARRAY_A );
			foreach ( $this->normalizeCountRows( $rows ) as $row ) {
				$cursor = (int) $row['id'];
				yield $row;
			}
			$row_count = count( $rows );
		} while ( self::EXPORT_BATCH_SIZE === $row_count );
	}

	/** @return Generator<int, array<string, mixed>> */
	public function externalLinkExport( DateRange $range ): Generator {
		$cursor = 0;
		do {
			$metrics = "SELECT link_id,SUM(impression_views) AS impression_views,SUM(clicked_views) AS clicked_views,SUM(raw_clicks) AS raw_clicks,MAX(last_clicked_at) AS last_clicked_at
FROM {$this->tables->internalLinkDaily()} WHERE stat_date BETWEEN %s AND %s
GROUP BY link_id HAVING SUM(raw_clicks) > 0";
			$pageviews = "SELECT page_id,SUM(pv) AS source_pv FROM {$this->tables->daily()}
WHERE stat_date BETWEEN %s AND %s GROUP BY page_id";
			$sql = "SELECT l.id,l.target_page_id,l.target_url,l.anchor_text,l.is_active,l.link_type,
sp.object_id AS source_object_id,sp.title AS source_title,sp.canonical_url AS source_url,sw.post_type AS source_post_type,sw.post_status AS source_post_status,
COALESCE(m.impression_views,0) AS impression_views,COALESCE(m.clicked_views,0) AS clicked_views,
COALESCE(m.raw_clicks,0) AS raw_clicks,m.last_clicked_at,COALESCE(pv.source_pv,0) AS source_pv,
CASE WHEN COALESCE(pv.source_pv,0) > 0
THEN LEAST(COALESCE(m.clicked_views,0),COALESCE(pv.source_pv,0)) / COALESCE(pv.source_pv,0) ELSE 0 END AS click_rate
FROM {$this->tables->internalLinks()} l
INNER JOIN {$this->tables->pages()} sp ON sp.id = l.source_page_id
LEFT JOIN {$this->wpdb->posts} sw ON sw.ID = sp.object_id
INNER JOIN ({$metrics}) m ON m.link_id = l.id
LEFT JOIN ({$pageviews}) pv ON pv.page_id = l.source_page_id
WHERE l.link_type = 'external' AND l.id > %d ORDER BY l.id ASC LIMIT %d";
			$params = array( $range->fromSql(), $range->toSql(), $range->fromSql(), $range->toSql(), $cursor, self::EXPORT_BATCH_SIZE );
			$rows = (array) $this->wpdb->get_results( $this->wpdb->prepare( $sql, ...$params ), ARRAY_A );
			foreach ( $this->normalizeLinkRows( $rows ) as $row ) {
				$cursor = (int) $row['id'];
				yield $row;
			}
			$row_count = count( $rows );
		} while ( self::EXPORT_BATCH_SIZE === $row_count );
	}

	/** @return Generator<int, array<string, mixed>> */
	public function internalLinkExport( DateRange $range ): Generator {
		yield from $this->externalLinkExport( $range );
	}

	/** @return array<int, array{name:string,pv:int}> */
	private function sourceNames( DateRange $range, string $type, int $limit ): array {
		$limit = max( 1, min( 50, $limit ) );
		/** @var array<int, array{name:string,pv:int}> $rows */
		$rows = $this->remember(
			'names|' . $type . '|' . $range->fromSql() . '|' . $range->toSql() . '|' . $limit,
			$range,
			function () use ( $range, $type, $limit ): array {
				$query = $this->wpdb->prepare(
					"SELECT r.source_name AS name,SUM(d.pv) AS pv FROM {$this->tables->referrerDaily()} d
INNER JOIN {$this->tables->referrers()} r ON r.id = d.referrer_id
WHERE d.stat_date BETWEEN %s AND %s AND r.source_type = %s
GROUP BY r.source_name ORDER BY pv DESC,r.source_name ASC LIMIT %d",
					$range->fromSql(),
					$range->toSql(),
					$type,
					$limit
				);
				return $this->normalizeCountRows( (array) $this->wpdb->get_results( $query, ARRAY_A ) );
			}
		);

		return $rows;
	}

	/** @param array<int, array<string, mixed>> $rows
	 *  @return array<int, array<string, mixed>>
	 */
	private function normalizeCountRows( array $rows ): array {
		foreach ( $rows as &$row ) {
			foreach ( array( 'id', 'referrer_id', 'landing_page_id', 'landing_count', 'pv', 'period_pv' ) as $key ) {
				if ( array_key_exists( $key, $row ) ) {
					$row[ $key ] = max( 0, (int) $row[ $key ] );
				}
			}
		}
		unset( $row );

		return $rows;
	}

	/** @param array<int, array<string, mixed>> $rows
	 *  @return array<int, array<string, mixed>>
	 */
	private function normalizeLinkRows( array $rows ): array {
		foreach ( $rows as &$row ) {
			foreach ( array( 'id', 'source_page_id', 'destination_count', 'target_page_id', 'source_object_id', 'is_active', 'impression_views', 'clicked_views', 'raw_clicks', 'source_pv' ) as $key ) {
				if ( array_key_exists( $key, $row ) ) {
					$row[ $key ] = max( 0, (int) $row[ $key ] );
				}
			}
			$row['click_rate'] = max( 0.0, min( 1.0, (float) ( $row['click_rate'] ?? $row['transition_rate'] ?? 0 ) ) );
			$row['transition_rate'] = $row['click_rate'];
			$row['target_domain'] = strtolower( (string) wp_parse_url( (string) ( $row['target_url'] ?? '' ), PHP_URL_HOST ) );
			if ( 0 >= (int) ( $row['target_page_id'] ?? 0 ) ) {
				$row['target_status'] = 'unresolved';
			} elseif ( '' !== (string) ( $row['target_deleted_at'] ?? '' ) || 'publish' !== (string) ( $row['target_post_status'] ?? '' ) ) {
				$row['target_status'] = 'unavailable';
			} else {
				$row['target_status'] = 'available';
			}
		}
		unset( $row );

		return $rows;
	}

	/** @param array<int, array<string, mixed>> $rows
	 *  @return array<int, array<string, mixed>>
	 */
	private function normalizePageRows( array $rows ): array {
		foreach ( $rows as &$row ) {
			foreach ( array( 'id', 'object_id', 'total_pv', 'period_pv' ) as $key ) {
				if ( array_key_exists( $key, $row ) ) {
					$row[ $key ] = max( 0, (int) $row[ $key ] );
				}
			}
		}
		unset( $row );

		return $rows;
	}

	/** @param array<int, string|int> $params */
	private function prepare( string $sql, array $params ): string {
		return array() === $params ? $sql : $this->wpdb->prepare( $sql, ...$params );
	}

	private function remember( string $key, DateRange $range, callable $callback ): mixed {
		$generation = (int) get_option( 'jimmy_pv_report_cache_generation', 1 );
		$cacheKey   = 'jimmy_pv_r_' . md5( JIMMY_PV_VERSION . '|' . $generation . '|' . $key );
		$cached     = get_transient( $cacheKey );
		if ( false !== $cached ) {
			return $cached;
		}

		$value = $callback();
		$today = wp_date( 'Y-m-d', null, wp_timezone() );
		set_transient( $cacheKey, $value, $range->toSql() >= $today ? MINUTE_IN_SECONDS : 5 * MINUTE_IN_SECONDS );

		return $value;
	}
}
