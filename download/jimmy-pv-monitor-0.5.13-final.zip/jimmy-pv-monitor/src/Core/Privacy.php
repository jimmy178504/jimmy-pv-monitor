<?php

namespace Jimmy\PVMonitor\Core;

defined( 'ABSPATH' ) || exit;

final class Privacy {
	public static function registerPolicyText(): void {
		if ( ! function_exists( 'wp_add_privacy_policy_content' ) ) {
			return;
		}

		$content  = '<p class="privacy-policy-tutorial">';
		$content .= esc_html__( '以下はJimmy PV Monitorを有効にしたサイト向けの説明文です。サイトの設定と運用に合わせて確認してください。', 'jimmy-pv-monitor' );
		$content .= '</p>';
		$content .= '<p>';
		$content .= esc_html__( 'このサイトでは、ページビュー、閲覧ページ、取得可能な参照元URL、UTMキャンペーン情報、記事本文内の外部リンクURL・表示・クリックをWordPressデータベースへ保存する場合があります。無料版の外部リンク計測はページ表示中だけの一時IDを使用し、URLから設定済みの機密な項目を除いて保存します。広告クリックIDの値、訪問者識別Cookie、IPアドレスは保存せず、無料版は解析データをJimmyの外部サーバーへ送信しません。標準の分析データ保存期間は365日です。', 'jimmy-pv-monitor' );
		$content .= '</p>';

		wp_add_privacy_policy_content( 'Jimmy PV Monitor', wp_kses_post( $content ) );
	}
}
