<?php

namespace Jimmy\PVMonitor\Links;

use Jimmy\PVMonitor\Pages\PageResolver;
use Jimmy\PVMonitor\Pages\UrlNormalizer;
use WP_Error;
use WP_HTML_Tag_Processor;
use WP_Post;

defined( 'ABSPATH' ) || exit;

final class LinkIndexer {
	private const MAX_LINKS_PER_POST = 200;

	public function __construct(
		private readonly PageResolver $pages,
		private readonly UrlNormalizer $urls,
		private readonly LinkUrlResolver $targets,
		private readonly LinkRepository $links
	) {}

	public function register(): void {
		add_action( 'save_post', array( $this, 'onSavePost' ), 20, 3 );
	}

	public function onSavePost( int $postId, WP_Post $post, bool $update ): void {
		unset( $update );
		if ( wp_is_post_revision( $postId ) || wp_is_post_autosave( $postId ) ) {
			return;
		}
		$this->indexPost( $postId, $post );
	}

	public function indexPost( int $postId, ?WP_Post $post = null ): bool|WP_Error {
		$post = $post ?? get_post( $postId );
		if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status || '' !== (string) $post->post_password ) {
			$this->links->deactivateByPostId( $postId );
			return true;
		}

		$page = $this->pages->resolvePostById( $postId );
		if ( ! $page->isTrackable ) {
			$this->links->deactivateByPostId( $postId );
			return true;
		}

		$sourcePageId = $this->links->ensurePage( $page );
		if ( $sourcePageId instanceof WP_Error ) {
			return $sourcePageId;
		}

		$indexed = array();
		foreach ( $this->anchorFragments( (string) $post->post_content ) as $fragment ) {
			$processor = new WP_HTML_Tag_Processor( $fragment );
			if ( ! $processor->next_tag( 'A' ) ) {
				continue;
			}
			$href = $processor->get_attribute( 'href' );
			if ( ! is_string( $href ) ) {
				continue;
			}

			$targetUrl = $this->targets->resolve( $href, $page->canonicalUrl );
			if ( null === $targetUrl ) {
				continue;
			}
			$targetHash = $this->urls->hash( $targetUrl );
			if ( isset( $indexed[ $targetHash ] ) ) {
				continue;
			}

			$anchorText = sanitize_text_field( wp_strip_all_tags( $fragment, true ) );
			$anchorText = function_exists( 'mb_substr' ) ? mb_substr( $anchorText, 0, 255 ) : substr( $anchorText, 0, 255 );
			$indexed[ $targetHash ] = new IndexedLink( $targetHash, $targetUrl, $anchorText, null );
			if ( self::MAX_LINKS_PER_POST <= count( $indexed ) ) {
				break;
			}
		}

		return $this->links->replaceForSource( $sourcePageId, array_values( $indexed ) );
	}

	/** @return string[] */
	private function anchorFragments( string $content ): array {
		if ( '' === $content || ! class_exists( WP_HTML_Tag_Processor::class ) ) {
			return array();
		}
		preg_match_all( '/<a\b[^>]*>.*?<\/a\s*>/is', $content, $matches );

		return array_slice( (array) ( $matches[0] ?? array() ), 0, self::MAX_LINKS_PER_POST * 2 );
	}
}
