<?php

namespace Jimmy\PVMonitor\Links;

use Jimmy\PVMonitor\Pages\UrlNormalizer;
use Jimmy\PVMonitor\Settings\SettingsRepository;

defined( 'ABSPATH' ) || exit;

final class LinkUrlResolver {
	public function __construct(
		private readonly UrlNormalizer $urls,
		private readonly SettingsRepository $settings
	) {}

	public function resolve( string $href, string $baseUrl = '' ): ?string {
		$href = trim( html_entity_decode( $href, ENT_QUOTES | ENT_HTML5, 'UTF-8' ) );
		if ( '' === $href || str_starts_with( $href, '#' ) || preg_match( '#^(?:mailto|tel|javascript|data):#i', $href ) ) {
			return null;
		}
		$href = $this->makeAbsolute( $href, $baseUrl );

		$sensitive = (array) $this->settings->get( 'sensitive_query_keys', array() );
		$withQuery = $this->urls->normalize( $href, true, $sensitive );
		if ( null === $withQuery || ! $this->isExternalDomain( $withQuery ) ) {
			return null;
		}

		return $withQuery;
	}

	private function makeAbsolute( string $href, string $baseUrl ): string {
		if ( '' === $baseUrl || preg_match( '#^[a-z][a-z0-9+.-]*:#i', $href ) || str_starts_with( $href, '//' ) || str_starts_with( $href, '/' ) ) {
			return $href;
		}

		$base = wp_parse_url( $baseUrl );
		if ( ! is_array( $base ) || empty( $base['scheme'] ) || empty( $base['host'] ) ) {
			return $href;
		}

		$href = explode( '#', $href, 2 )[0];
		$parts = explode( '?', $href, 2 );
		$relativePath = $parts[0];
		$query = $parts[1] ?? '';
		$basePath = (string) ( $base['path'] ?? '/' );
		if ( '' === $relativePath ) {
			$path = $basePath;
		} else {
			$directory = str_ends_with( $basePath, '/' ) ? $basePath : substr( $basePath, 0, (int) strrpos( $basePath, '/' ) + 1 );
			$path = $this->removeDotSegments( $directory . $relativePath );
		}

		$host = str_contains( (string) $base['host'], ':' ) ? '[' . trim( (string) $base['host'], '[]' ) . ']' : (string) $base['host'];
		$port = isset( $base['port'] ) ? ':' . (int) $base['port'] : '';

		return (string) $base['scheme'] . '://' . $host . $port . $path . ( '' !== $query ? '?' . $query : '' );
	}

	private function removeDotSegments( string $path ): string {
		$trailingSlash = str_ends_with( $path, '/' );
		$segments = array();
		foreach ( explode( '/', $path ) as $segment ) {
			if ( '' === $segment || '.' === $segment ) {
				continue;
			}
			if ( '..' === $segment ) {
				array_pop( $segments );
				continue;
			}
			$segments[] = $segment;
		}

		return '/' . implode( '/', $segments ) . ( $trailingSlash && array() !== $segments ? '/' : '' );
	}

	private function isExternalDomain( string $url ): bool {
		$parts = wp_parse_url( $url );
		$home  = wp_parse_url( home_url( '/' ) );
		if ( ! is_array( $parts ) || ! is_array( $home ) ) {
			return false;
		}

		$host = strtolower( rtrim( (string) ( $parts['host'] ?? '' ), '.' ) );
		$homeHost = strtolower( rtrim( (string) ( $home['host'] ?? '' ), '.' ) );

		return '' !== $host && '' !== $homeHost && $host !== $homeHost;
	}
}
