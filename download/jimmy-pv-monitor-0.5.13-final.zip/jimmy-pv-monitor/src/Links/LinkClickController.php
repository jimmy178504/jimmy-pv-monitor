<?php

namespace Jimmy\PVMonitor\Links;

use Jimmy\PVMonitor\Collection\EventDeduplicator;
use Jimmy\PVMonitor\Collection\RateLimiter;
use Jimmy\PVMonitor\Pages\PageResolver;
use Jimmy\PVMonitor\Pages\PageTokenService;
use Jimmy\PVMonitor\Pages\TrackingPolicy;
use Jimmy\PVMonitor\Pages\UrlNormalizer;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

final class LinkClickController {
	private const MAX_BODY_BYTES = 4096;

	public function __construct(
		private readonly PageResolver $pages,
		private readonly TrackingPolicy $tracking,
		private readonly PageTokenService $tokens,
		private readonly UrlNormalizer $urls,
		private readonly RateLimiter $rateLimiter,
		private readonly EventDeduplicator $deduplicator,
		private readonly LinkMetricsRepository $metrics,
		private readonly LinkRepository $links,
		private readonly LinkUrlResolver $targets
	) {}

	public function register(): void {
		register_rest_route(
			'jimmy-pv/v1',
			'/collect/link-click',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => '__return_true',
				'args'                => $this->routeArguments(),
			)
		);
	}

	public function handle( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$contentType = strtolower( $request->get_header( 'content-type' ) );
		$mediaType   = trim( explode( ';', $contentType, 2 )[0] );
		if ( 'application/json' !== $mediaType || self::MAX_BODY_BYTES < strlen( $request->get_body() ) ) {
			return $this->error( 'jimmy_pv_invalid_link_content', 415 );
		}

		$origin = trim( $request->get_header( 'origin' ) );
		if ( '' !== $origin && ! $this->urls->isSameOrigin( $origin ) ) {
			return $this->error( 'jimmy_pv_invalid_link_origin', 403 );
		}

		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) ) {
			return $this->error( 'jimmy_pv_invalid_link_content', 400 );
		}

		$eventId   = $this->payloadString( $payload, 'event_id' );
		$viewId    = $this->payloadString( $payload, 'view_id' );
		$pageKey   = $this->payloadString( $payload, 'page_key' );
		$signature = $this->payloadString( $payload, 'signature' );
		$linkId    = isset( $payload['link_id'] ) && is_scalar( $payload['link_id'] ) ? absint( $payload['link_id'] ) : 0;
		$targetUrl = $this->payloadString( $payload, 'target_url' );
		$anchorText = $this->payloadString( $payload, 'anchor_text' );
		if ( ! $this->isIdentifier( $eventId ) || ! $this->isIdentifier( $viewId ) || ! $this->isPageKey( $pageKey ) || ! $this->isSignature( $signature ) || ( 0 >= $linkId && '' === $targetUrl ) ) {
			return $this->error( 'jimmy_pv_invalid_link_content', 400 );
		}

		$page = $this->pages->resolvePostById( (int) substr( $pageKey, 5 ) );
		if ( ! $page->isTrackable || $page->pageKey !== $pageKey || ! $this->tokens->verify( $page, $signature ) ) {
			return $this->error( 'jimmy_pv_invalid_link_signature', 403 );
		}
		$decision = $this->tracking->evaluate( $page, null, $request->get_header( 'user-agent' ) );
		if ( ! $decision->allowed ) {
			return $this->noContent();
		}

		$rateLimit = $this->rateLimiter->check( $request );
		if ( $rateLimit instanceof WP_Error ) {
			return $rateLimit;
		}
		if ( 0 >= $linkId ) {
			$targetUrl = $this->targets->resolve( $targetUrl, $page->canonicalUrl );
			if ( null === $targetUrl ) {
				return $this->error( 'jimmy_pv_invalid_link_target', 400 );
			}
			$anchorText = sanitize_text_field( $anchorText );
			$anchorText = function_exists( 'mb_substr' ) ? mb_substr( $anchorText, 0, 255 ) : substr( $anchorText, 0, 255 );
			$linkId = $this->links->ensureExternalForPage( $page, $this->urls->hash( $targetUrl ), $targetUrl, $anchorText );
			if ( $linkId instanceof WP_Error ) {
				return $linkId;
			}
		}
		if ( ! $this->metrics->isActiveForPage( $linkId, $pageKey ) ) {
			return $this->error( 'jimmy_pv_invalid_link', 400 );
		}

		$eventClaim = $this->deduplicator->claim( $eventId, 'link_click' );
		if ( $eventClaim instanceof WP_Error ) {
			return $eventClaim;
		}
		if ( false === $eventClaim ) {
			return $this->noContent();
		}

		$viewClaim = $this->deduplicator->claimLinkView( $viewId, $linkId );
		if ( $viewClaim instanceof WP_Error ) {
			$this->deduplicator->forget( $eventId, 'link_click' );
			return $viewClaim;
		}

		$result = $this->metrics->recordClick( $linkId, $viewClaim );
		if ( $result instanceof WP_Error || false === $result ) {
			$this->deduplicator->forget( $eventId, 'link_click' );
			if ( $viewClaim ) {
				$this->deduplicator->forgetLinkView( $viewId, $linkId );
			}
			return $result instanceof WP_Error ? $result : $this->error( 'jimmy_pv_link_collection_failed', 503 );
		}

		return $this->noContent();
	}

	/** @return array<string, array<string, mixed>> */
	private function routeArguments(): array {
		return array(
			'event_id' => array( 'required' => true, 'type' => 'string', 'validate_callback' => fn ( mixed $value ): bool => $this->isIdentifier( $value ) ),
			'view_id' => array( 'required' => true, 'type' => 'string', 'validate_callback' => fn ( mixed $value ): bool => $this->isIdentifier( $value ) ),
			'page_key' => array( 'required' => true, 'type' => 'string', 'validate_callback' => fn ( mixed $value ): bool => $this->isPageKey( $value ) ),
			'signature' => array( 'required' => true, 'type' => 'string', 'validate_callback' => fn ( mixed $value ): bool => $this->isSignature( $value ) ),
			'link_id' => array( 'required' => false, 'type' => 'integer', 'minimum' => 1 ),
			'target_url' => array( 'required' => false, 'type' => 'string', 'maxLength' => 2048 ),
			'anchor_text' => array( 'required' => false, 'type' => 'string', 'maxLength' => 255 ),
		);
	}

	/** @param array<string, mixed> $payload */
	private function payloadString( array $payload, string $key ): string {
		return isset( $payload[ $key ] ) && is_string( $payload[ $key ] ) ? trim( $payload[ $key ] ) : '';
	}

	private function isIdentifier( mixed $value ): bool {
		return is_string( $value ) && 16 <= strlen( $value ) && 64 >= strlen( $value ) && 1 === preg_match( '/^[A-Fa-f0-9-]+$/D', $value );
	}

	private function isPageKey( mixed $value ): bool {
		return is_string( $value ) && 1 === preg_match( '/^post:[1-9]\d*$/D', $value );
	}

	private function isSignature( mixed $value ): bool {
		return is_string( $value ) && 32 <= strlen( $value ) && 128 >= strlen( $value ) && 1 === preg_match( '/^[A-Za-z0-9_-]+$/D', $value );
	}

	private function noContent(): WP_REST_Response {
		$response = new WP_REST_Response( null, 204 );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );

		return $response;
	}

	private function error( string $code, int $status ): WP_Error {
		return new WP_Error( $code, __( '外部リンク計測リクエストを処理できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => $status ) );
	}
}
