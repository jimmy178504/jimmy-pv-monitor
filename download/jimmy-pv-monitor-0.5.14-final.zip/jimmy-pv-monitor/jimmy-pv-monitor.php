<?php
/**
 * Plugin Name: Jimmy PV Monitor
 * Description: WordPress内でPVを計測・集計するプライバシー重視のアクセス解析プラグインです。
 * Version: 0.5.14
 * Requires at least: 6.7
 * Requires PHP: 8.1
 * Author: Jimmy
 * License: GPLv2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: jimmy-pv-monitor
 */

defined( 'ABSPATH' ) || exit;

if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
	add_action(
		'admin_notices',
		static function (): void {
			if ( ! current_user_can( 'activate_plugins' ) ) {
				return;
			}

			echo '<div class="notice notice-error"><p>';
			echo esc_html__( 'Jimmy PV MonitorにはPHP 8.1以上が必要です。', 'jimmy-pv-monitor' );
			echo '</p></div>';
		}
	);

	return;
}

defined( 'JIMMY_PV_VERSION' ) || define( 'JIMMY_PV_VERSION', '0.5.14' );
defined( 'JIMMY_PV_DB_VERSION' ) || define( 'JIMMY_PV_DB_VERSION', 4 );
defined( 'JIMMY_PV_API_VERSION' ) || define( 'JIMMY_PV_API_VERSION', 1 );
defined( 'JIMMY_PV_FILE' ) || define( 'JIMMY_PV_FILE', __FILE__ );
defined( 'JIMMY_PV_DIR' ) || define( 'JIMMY_PV_DIR', plugin_dir_path( __FILE__ ) );
defined( 'JIMMY_PV_URL' ) || define( 'JIMMY_PV_URL', plugin_dir_url( __FILE__ ) );
defined( 'JIMMY_PV_BASENAME' ) || define( 'JIMMY_PV_BASENAME', plugin_basename( __FILE__ ) );

require_once JIMMY_PV_DIR . 'src/Autoloader.php';

\Jimmy\PVMonitor\Autoloader::register();

register_activation_hook( JIMMY_PV_FILE, array( \Jimmy\PVMonitor\Core\Activator::class, 'activate' ) );
register_deactivation_hook( JIMMY_PV_FILE, array( \Jimmy\PVMonitor\Core\Deactivator::class, 'deactivate' ) );

add_action( 'plugins_loaded', array( \Jimmy\PVMonitor\Core\Plugin::class, 'boot' ) );
