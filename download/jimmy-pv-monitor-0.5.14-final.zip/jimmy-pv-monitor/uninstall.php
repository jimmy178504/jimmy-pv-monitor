<?php

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

if ( version_compare( PHP_VERSION, '8.1', '<' ) ) {
	return;
}

defined( 'JIMMY_PV_DIR' ) || define( 'JIMMY_PV_DIR', plugin_dir_path( __FILE__ ) );

require_once JIMMY_PV_DIR . 'src/Autoloader.php';

\Jimmy\PVMonitor\Autoloader::register();
\Jimmy\PVMonitor\Maintenance\Scheduler::unschedule();

$jimmy_pv_settings = get_option( \Jimmy\PVMonitor\Settings\SettingsRepository::OPTION_NAME, array() );
if ( ! is_array( $jimmy_pv_settings ) || empty( $jimmy_pv_settings['delete_data_on_uninstall'] ) ) {
	return;
}

global $wpdb;

$jimmy_pv_tables = new \Jimmy\PVMonitor\Database\TableNames( $wpdb );
foreach ( array_reverse( $jimmy_pv_tables->all() ) as $jimmy_pv_table ) {
	// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching,WordPress.DB.DirectDatabaseQuery.SchemaChange -- Uninstall must remove the plugin's own tables immediately.
	$wpdb->query( $wpdb->prepare( 'DROP TABLE IF EXISTS %i', $jimmy_pv_table ) );
}

\Jimmy\PVMonitor\Core\Capabilities::removeFromAllRoles();

$jimmy_pv_options = array(
	'jimmy_pv_settings',
	'jimmy_pv_db_version',
	'jimmy_pv_site_secret',
	'jimmy_pv_installed_at',
	'jimmy_pv_version',
	'jimmy_pv_last_maintenance',
	'jimmy_pv_migration_state',
	'jimmy_pv_link_index_state',
	'jimmy_pv_schema_error',
	'jimmy_pv_cron_error',
	'jimmy_pv_maintenance_error',
	'jimmy_pv_secret_regenerated_at',
	'jimmy_pv_schema_lock',
	'jimmy_pv_maintenance_lock',
	'jimmy_pv_link_index_lock',
	'jimmy_pv_report_cache_generation',
);

foreach ( $jimmy_pv_options as $jimmy_pv_option ) {
	delete_option( $jimmy_pv_option );
}

// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Remove only this plugin's per-user report period preference.
$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE meta_key = %s', $wpdb->usermeta, 'jimmy_pv_report_period' ) );

$jimmy_pv_cache_like = $wpdb->esc_like( '_transient_jimmy_pv_r_' ) . '%';
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Remove only this plugin's generated transients during uninstall.
$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE option_name LIKE %s', $wpdb->options, $jimmy_pv_cache_like ) );
$jimmy_pv_timeout_like = $wpdb->esc_like( '_transient_timeout_jimmy_pv_r_' ) . '%';
// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- Remove only this plugin's generated transient timeouts during uninstall.
$wpdb->query( $wpdb->prepare( 'DELETE FROM %i WHERE option_name LIKE %s', $wpdb->options, $jimmy_pv_timeout_like ) );
