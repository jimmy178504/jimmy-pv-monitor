( function () {
	'use strict';

	const svgNamespace = 'http://www.w3.org/2000/svg';
	const l10n = window.jimmyPvAdminL10n || {};

	function svgElement( name, attributes ) {
		const element = document.createElementNS( svgNamespace, name );
		Object.keys( attributes || {} ).forEach( function ( key ) {
			element.setAttribute( key, String( attributes[ key ] ) );
		} );

		return element;
	}

	function renderChart( container ) {
		let series;
		try {
			series = JSON.parse( container.getAttribute( 'data-jimmy-pv-chart' ) || '[]' );
		} catch ( error ) {
			series = [];
		}

		container.textContent = '';
		if ( ! Array.isArray( series ) || series.length === 0 ) {
			const empty = document.createElement( 'p' );
			empty.textContent = l10n.noData || '';
			container.appendChild( empty );
			return;
		}

		const width = 900;
		const height = 280;
		const padding = { top: 20, right: 24, bottom: 44, left: 64 };
		const chartWidth = width - padding.left - padding.right;
		const chartHeight = height - padding.top - padding.bottom;
		const maximum = Math.max.apply( null, series.map( function ( item ) {
			return Math.max( 0, Number( item.pv ) || 0 );
		} ) );
		const scaleMaximum = Math.max( 1, maximum );
		const svg = svgElement( 'svg', {
			viewBox: '0 0 ' + width + ' ' + height,
			role: 'img',
			'aria-label': l10n.chartLabel || ''
		} );
		const tooltip = document.createElement( 'div' );
		tooltip.className = 'jimmy-pv-chart-tooltip';
		tooltip.hidden = true;
		tooltip.setAttribute( 'role', 'status' );

		function tooltipText( item ) {
			return String( item.date || '' ) + '：' + Math.max( 0, Number( item.pv ) || 0 ).toLocaleString( 'ja-JP' ) + ' PV';
		}

		function showTooltip( item, x, y ) {
			const svgRect = svg.getBoundingClientRect();
			const containerRect = container.getBoundingClientRect();
			const rawLeft = svgRect.left - containerRect.left + ( x / width * svgRect.width );
			const rawTop = svgRect.top - containerRect.top + ( y / height * svgRect.height );
			tooltip.textContent = tooltipText( item );
			tooltip.style.left = Math.max( 58, Math.min( containerRect.width - 58, rawLeft ) ) + 'px';
			tooltip.style.top = Math.max( 8, rawTop - 8 ) + 'px';
			tooltip.hidden = false;
		}

		function hideTooltip() {
			tooltip.hidden = true;
		}

		for ( let index = 0; index <= 4; index += 1 ) {
			const y = padding.top + ( chartHeight * index / 4 );
			const value = Math.round( scaleMaximum * ( 1 - index / 4 ) );
			const line = svgElement( 'line', {
				x1: padding.left,
				y1: y,
				x2: width - padding.right,
				y2: y,
				class: 'jimmy-pv-chart-grid'
			} );
			const label = svgElement( 'text', {
				x: padding.left - 10,
				y: y + 4,
				class: 'jimmy-pv-chart-label',
				'text-anchor': 'end'
			} );
			label.textContent = value.toLocaleString( 'ja-JP' );
			svg.appendChild( line );
			svg.appendChild( label );
		}

		const pointPositions = series.map( function ( item, index ) {
			const x = series.length === 1
				? padding.left + chartWidth / 2
				: padding.left + chartWidth * index / ( series.length - 1 );
			const y = padding.top + chartHeight * ( 1 - Math.max( 0, Number( item.pv ) || 0 ) / scaleMaximum );

			return { x: x, y: y };
		} );
		const points = pointPositions.map( function ( point ) {
			return point.x + ',' + point.y;
		} ).join( ' ' );
		const polyline = svgElement( 'polyline', { points: points, class: 'jimmy-pv-chart-line' } );
		svg.appendChild( polyline );

		pointPositions.forEach( function ( point, index ) {
			const circle = svgElement( 'circle', {
				cx: point.x,
				cy: point.y,
				r: 4,
				class: 'jimmy-pv-chart-point',
				tabindex: 0,
				role: 'button',
				'aria-label': tooltipText( series[ index ] )
			} );
			const title = svgElement( 'title' );
			title.textContent = tooltipText( series[ index ] );
			circle.appendChild( title );
			circle.addEventListener( 'pointerenter', function () {
				showTooltip( series[ index ], point.x, point.y );
			} );
			circle.addEventListener( 'pointerleave', function ( event ) {
				if ( 'touch' !== event.pointerType ) {
					hideTooltip();
				}
			} );
			circle.addEventListener( 'focus', function () {
				showTooltip( series[ index ], point.x, point.y );
			} );
			circle.addEventListener( 'blur', hideTooltip );
			circle.addEventListener( 'click', function ( event ) {
				event.stopPropagation();
				showTooltip( series[ index ], point.x, point.y );
			} );
			svg.appendChild( circle );
		} );

		const labelIndexes = [ 0, Math.floor( ( series.length - 1 ) / 2 ), series.length - 1 ];
		Array.from( new Set( labelIndexes ) ).forEach( function ( index ) {
			const x = series.length === 1
				? padding.left + chartWidth / 2
				: padding.left + chartWidth * index / ( series.length - 1 );
			const label = svgElement( 'text', {
				x: x,
				y: height - 14,
				class: 'jimmy-pv-chart-label',
				'text-anchor': index === 0 ? 'start' : ( index === series.length - 1 ? 'end' : 'middle' )
			} );
			label.textContent = String( series[ index ].date || '' );
			svg.appendChild( label );
		} );

		svg.addEventListener( 'click', function ( event ) {
			if ( ! event.target.classList.contains( 'jimmy-pv-chart-point' ) ) {
				hideTooltip();
			}
		} );
		container.appendChild( svg );
		container.appendChild( tooltip );
	}

	function updateCustomDates( select ) {
		const form = select.closest( 'form' );
		const dates = form ? form.querySelector( '[data-jimmy-pv-custom-dates]' ) : null;
		if ( dates ) {
			dates.hidden = select.value !== 'custom';
		}
	}

	document.querySelectorAll( '[data-jimmy-pv-chart]' ).forEach( renderChart );
	document.querySelectorAll( '[data-jimmy-pv-range]' ).forEach( function ( select ) {
		updateCustomDates( select );
		select.addEventListener( 'change', function () {
			updateCustomDates( select );
		} );
	} );
}() );
