<?php

namespace Jimmy\PVMonitor\Settings;

defined( 'ABSPATH' ) || exit;

final class Defaults {
	/** @return array<string, mixed> */
	public static function get(): array {
		return array(
			'settings_version'          => 1,
			'tracking_enabled'          => true,
			'post_type_mode'            => 'all_public',
			'included_post_types'       => array( 'post', 'page' ),
			'excluded_post_types'       => array( 'attachment' ),
			'track_home'                => true,
			'track_archives'            => true,
			'track_search'              => true,
			'track_404'                 => false,
			'excluded_roles'            => array( 'administrator' ),
			'exclude_empty_user_agent'  => true,
			'custom_bot_patterns'       => array(),
			'excluded_post_ids'         => array(),
			'excluded_url_patterns'     => array(),
			'distinguish_query_strings' => false,
			'referrer_enabled'          => true,
			'sensitive_query_keys'      => array(
				'token',
				'access_token',
				'auth',
				'authorization',
				'password',
				'passwd',
				'email',
				'key',
				'secret',
				'signature',
				'gclid',
				'fbclid',
				'msclkid',
			),
			'retention_days'            => 365,
			'shortcode_format'          => 'この記事は{count}回閲覧されました',
			'shortcode_min'             => 0,
			'dashboard_widget_enabled'  => true,
			'delete_data_on_uninstall'  => false,
		);
	}
}
