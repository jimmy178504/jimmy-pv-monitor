<?php

namespace Jimmy\PVMonitor\Settings;

defined( 'ABSPATH' ) || exit;

final class SettingsSanitizer {
	/**
	 * @param array<string, mixed> $candidate
	 * @return array<string, mixed>
	 */
	public function sanitize( array $candidate ): array {
		$defaults = Defaults::get();
		$result   = $defaults;
		$booleans = array(
			'tracking_enabled',
			'track_home',
			'track_archives',
			'track_search',
			'track_404',
			'exclude_empty_user_agent',
			'distinguish_query_strings',
			'referrer_enabled',
			'dashboard_widget_enabled',
			'delete_data_on_uninstall',
		);

		foreach ( $booleans as $key ) {
			if ( array_key_exists( $key, $candidate ) ) {
				$result[ $key ] = $this->toBoolean( $candidate[ $key ] );
			}
		}

		$result['settings_version'] = (int) $defaults['settings_version'];
		$result['post_type_mode']   = isset( $candidate['post_type_mode'] ) && 'selected' === $candidate['post_type_mode']
			? 'selected'
			: 'all_public';

		$result['included_post_types'] = $this->sanitizeKeys( $candidate['included_post_types'] ?? $defaults['included_post_types'], 100 );
		$result['excluded_post_types'] = $this->sanitizeKeys( $candidate['excluded_post_types'] ?? $defaults['excluded_post_types'], 100 );
		$result['excluded_roles']      = $this->sanitizeKeys( $candidate['excluded_roles'] ?? $defaults['excluded_roles'], 100 );
		$result['custom_bot_patterns'] = $this->sanitizeStrings( $candidate['custom_bot_patterns'] ?? array(), 100, 191 );
		$result['excluded_url_patterns'] = $this->sanitizeStrings( $candidate['excluded_url_patterns'] ?? array(), 100, 255 );
		$result['sensitive_query_keys'] = $this->sanitizeKeys(
			array_merge(
				array( 'gclid', 'fbclid', 'msclkid' ),
				(array) ( $candidate['sensitive_query_keys'] ?? $defaults['sensitive_query_keys'] )
			),
			100
		);

		$postIds = is_array( $candidate['excluded_post_ids'] ?? null ) ? $candidate['excluded_post_ids'] : array();
		$postIds = array_filter( $postIds, 'is_scalar' );
		$postIds = array_map( 'absint', $postIds );
		$postIds = array_filter( $postIds, static fn ( int $id ): bool => 0 < $id );
		$result['excluded_post_ids'] = array_values( array_unique( array_slice( $postIds, 0, 1000 ) ) );

		$retentionDays = absint( $candidate['retention_days'] ?? $defaults['retention_days'] );
		$result['retention_days'] = max( 30, min( 3650, $retentionDays ) );
		$result['shortcode_min']   = max( 0, absint( $candidate['shortcode_min'] ?? 0 ) );

		$format = sanitize_text_field( (string) ( $candidate['shortcode_format'] ?? $defaults['shortcode_format'] ) );
		$format = function_exists( 'mb_substr' ) ? mb_substr( $format, 0, 191 ) : substr( $format, 0, 191 );
		$result['shortcode_format'] = '' !== $format ? $format : (string) $defaults['shortcode_format'];

		return $result;
	}

	private function toBoolean( mixed $value ): bool {
		if ( is_bool( $value ) ) {
			return $value;
		}

		return in_array( $value, array( 1, '1', 'true', 'yes', 'on' ), true );
	}

	/** @return string[] */
	private function sanitizeKeys( mixed $value, int $limit ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$value = array_filter( $value, 'is_scalar' );
		$items = array_map(
			static fn ( mixed $item ): string => sanitize_key( (string) $item ),
			array_slice( $value, 0, $limit )
		);

		return array_values( array_unique( array_filter( $items ) ) );
	}

	/** @return string[] */
	private function sanitizeStrings( mixed $value, int $limit, int $maxLength ): array {
		if ( ! is_array( $value ) ) {
			return array();
		}

		$items = array();
		foreach ( array_slice( $value, 0, $limit ) as $item ) {
			if ( ! is_scalar( $item ) ) {
				continue;
			}
			$sanitized = sanitize_text_field( (string) $item );
			$sanitized = function_exists( 'mb_substr' ) ? mb_substr( $sanitized, 0, $maxLength ) : substr( $sanitized, 0, $maxLength );
			if ( '' !== $sanitized ) {
				$items[] = $sanitized;
			}
		}

		return array_values( array_unique( $items ) );
	}
}
