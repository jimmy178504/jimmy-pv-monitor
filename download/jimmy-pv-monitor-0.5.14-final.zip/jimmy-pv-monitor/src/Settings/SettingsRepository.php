<?php

namespace Jimmy\PVMonitor\Settings;

defined( 'ABSPATH' ) || exit;

final class SettingsRepository {
	public const OPTION_NAME = 'jimmy_pv_settings';

	public function __construct( private readonly SettingsSanitizer $sanitizer ) {}

	public static function installDefaults(): void {
		add_option( self::OPTION_NAME, Defaults::get(), '', true );
	}

	/** @return array<string, mixed> */
	public function all(): array {
		$stored = get_option( self::OPTION_NAME, array() );
		$stored = is_array( $stored ) ? $stored : array();

		return $this->sanitizer->sanitize( array_replace( Defaults::get(), $stored ) );
	}

	public function get( string $key, mixed $fallback = null ): mixed {
		$settings = $this->all();

		return array_key_exists( $key, $settings ) ? $settings[ $key ] : $fallback;
	}

	/** @param array<string, mixed> $candidate */
	public function update( array $candidate ): bool {
		$current = $this->all();
		$next    = $this->sanitizer->sanitize( array_replace( $current, $candidate ) );
		if ( $current === $next ) {
			return true;
		}

		return update_option( self::OPTION_NAME, $next, true );
	}
}
