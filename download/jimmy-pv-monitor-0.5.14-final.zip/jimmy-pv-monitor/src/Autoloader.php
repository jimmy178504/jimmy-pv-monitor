<?php

namespace Jimmy\PVMonitor;

defined( 'ABSPATH' ) || exit;

final class Autoloader {
	private const PREFIX = 'Jimmy\\PVMonitor\\';

	private static bool $registered = false;

	public static function register(): void {
		if ( self::$registered ) {
			return;
		}

		spl_autoload_register( array( self::class, 'autoload' ) );
		self::$registered = true;
	}

	private static function autoload( string $className ): void {
		if ( ! str_starts_with( $className, self::PREFIX ) ) {
			return;
		}

		$relativeClass = substr( $className, strlen( self::PREFIX ) );
		if ( '' === $relativeClass || ! preg_match( '/^[A-Za-z0-9_\\\\]+$/D', $relativeClass ) ) {
			return;
		}

		$sourceDirectory = realpath( __DIR__ );
		$file            = __DIR__ . '/' . str_replace( '\\', '/', $relativeClass ) . '.php';
		$resolvedFile    = realpath( $file );

		if ( false === $sourceDirectory || false === $resolvedFile ) {
			return;
		}

		$sourcePrefix = rtrim( $sourceDirectory, DIRECTORY_SEPARATOR ) . DIRECTORY_SEPARATOR;
		if ( ! str_starts_with( $resolvedFile, $sourcePrefix ) ) {
			return;
		}

		require_once $resolvedFile;
	}
}
