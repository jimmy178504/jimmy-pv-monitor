<?php

namespace Jimmy\PVMonitor\Links;

use Jimmy\PVMonitor\Pages\UrlNormalizer;
use WP_HTML_Tag_Processor;

defined( 'ABSPATH' ) || exit;

final class ContentDecorator {
	public function __construct(
		private readonly LinkRepository $links,
		private readonly LinkUrlResolver $targets,
		private readonly UrlNormalizer $urls
	) {}

	public function register(): void {
		add_filter( 'the_content', array( $this, 'decorate' ), 20 );
	}

	public function decorate( string $content ): string {
		if ( is_admin() || is_feed() || ! is_singular() || ! in_the_loop() || ! is_main_query() || ! class_exists( WP_HTML_Tag_Processor::class ) ) {
			return $content;
		}

		$postId = (int) get_the_ID();
		$map    = $this->links->activeMapForPost( $postId );

		$baseUrl = get_permalink( $postId );
		$baseUrl = is_string( $baseUrl ) ? $baseUrl : '';
		$processor = new WP_HTML_Tag_Processor( $content );
		while ( $processor->next_tag( 'A' ) ) {
			$processor->remove_attribute( 'data-jimmy-pv-link-id' );
			$processor->remove_attribute( 'data-jimmy-pv-track-click' );
			$href = $processor->get_attribute( 'href' );
			if ( ! is_string( $href ) ) {
				continue;
			}
			$target = $this->targets->resolve( $href, $baseUrl );
			if ( null === $target ) {
				continue;
			}
			$processor->set_attribute( 'data-jimmy-pv-track-click', '1' );
			$linkId = $map[ $this->urls->hash( $target ) ] ?? 0;
			if ( 0 < $linkId ) {
				$processor->set_attribute( 'data-jimmy-pv-link-id', (string) $linkId );
			}
		}

		return $processor->get_updated_html();
	}
}
