<?php

namespace Jimmy\PVMonitor\Links;

defined( 'ABSPATH' ) || exit;

final class IndexedLink {
	public function __construct(
		public readonly string $targetHash,
		public readonly string $targetUrl,
		public readonly string $anchorText,
		public readonly string $linkType,
		public readonly ?int $targetPageId
	) {}
}
