<?php

namespace Jimmy\PVMonitor\Links;

use Jimmy\PVMonitor\Maintenance\OptionLock;
use Throwable;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- The dynamic placeholder list is prepared; the posts table is supplied by wpdb.

final class LinkIndexBatch {
	public const HOOK = 'jimmy_pv_link_index_batch';
	public const STATE_OPTION = 'jimmy_pv_link_index_state';
	private const INDEX_VERSION = 3;
	private const BATCH_SIZE = 50;

	public function __construct(
		private readonly wpdb $wpdb,
		private readonly LinkIndexer $indexer,
		private readonly OptionLock $lock
	) {}

	public function register(): void {
		add_action( self::HOOK, array( $this, 'run' ) );
	}

	public function ensureScheduled(): void {
		$state = $this->state();
		if ( array() === $state || self::INDEX_VERSION !== (int) ( $state['version'] ?? 0 ) ) {
			$this->restart();
			return;
		}
		if ( 'running' === (string) ( $state['status'] ?? '' ) ) {
			$this->schedule( 10 );
		}
	}

	public function restart(): bool|WP_Error {
		wp_clear_scheduled_hook( self::HOOK );
		$state = array(
			'version'    => self::INDEX_VERSION,
			'status'     => 'running',
			'cursor'     => 0,
			'processed'  => 0,
			'total'      => $this->countPosts(),
			'errors'     => 0,
			'last_error' => '',
			'updated_at' => gmdate( 'Y-m-d H:i:s' ),
		);
		update_option( self::STATE_OPTION, $state, false );

		return $this->schedule( 5 );
	}

	public function run(): void {
		if ( ! $this->lock->acquire() ) {
			return;
		}

		try {
			$state = $this->state();
			if ( 'running' !== (string) ( $state['status'] ?? '' ) ) {
				return;
			}

			$ids = $this->nextPostIds( (int) ( $state['cursor'] ?? 0 ) );
			foreach ( $ids as $postId ) {
				$result = $this->indexer->indexPost( $postId );
				$state['cursor'] = $postId;
				$state['processed'] = (int) ( $state['processed'] ?? 0 ) + 1;
				if ( $result instanceof WP_Error ) {
					$state['errors'] = (int) ( $state['errors'] ?? 0 ) + 1;
					$state['last_error'] = $result->get_error_code();
				}
			}

			$state['updated_at'] = gmdate( 'Y-m-d H:i:s' );
			if ( self::BATCH_SIZE === count( $ids ) ) {
				$state['status'] = 'running';
				update_option( self::STATE_OPTION, $state, false );
				$this->schedule( MINUTE_IN_SECONDS );
			} else {
				$state['status'] = 'complete';
				update_option( self::STATE_OPTION, $state, false );
			}
		} catch ( Throwable $throwable ) {
			$state = $this->state();
			$state['status'] = 'error';
			$state['errors'] = (int) ( $state['errors'] ?? 0 ) + 1;
			$state['last_error'] = 'batch.exception:' . get_class( $throwable );
			$state['updated_at'] = gmdate( 'Y-m-d H:i:s' );
			update_option( self::STATE_OPTION, $state, false );
		} finally {
			$this->lock->release();
		}
	}

	/** @return array<string, mixed> */
	public function state(): array {
		$state = get_option( self::STATE_OPTION, array() );

		return is_array( $state ) ? $state : array();
	}

	private function schedule( int $delay ): bool|WP_Error {
		if ( false !== wp_next_scheduled( self::HOOK ) ) {
			return true;
		}

		return wp_schedule_single_event( time() + max( 1, $delay ), self::HOOK, array(), true );
	}

	/** @return int[] */
	private function nextPostIds( int $cursor ): array {
		$postTypes = $this->postTypes();
		if ( array() === $postTypes ) {
			return array();
		}
		$placeholders = implode( ',', array_fill( 0, count( $postTypes ), '%s' ) );
		$sql = "SELECT ID FROM {$this->wpdb->posts}
WHERE ID > %d AND post_status = 'publish' AND post_password = '' AND post_type IN ({$placeholders})
ORDER BY ID ASC LIMIT %d";
		$params = array_merge( array( $cursor ), $postTypes, array( self::BATCH_SIZE ) );

		return array_map( 'absint', (array) $this->wpdb->get_col( $this->wpdb->prepare( $sql, ...$params ) ) );
	}

	private function countPosts(): int {
		$postTypes = $this->postTypes();
		if ( array() === $postTypes ) {
			return 0;
		}
		$placeholders = implode( ',', array_fill( 0, count( $postTypes ), '%s' ) );
		$sql = "SELECT COUNT(*) FROM {$this->wpdb->posts}
WHERE post_status = 'publish' AND post_password = '' AND post_type IN ({$placeholders})";

		return max( 0, (int) $this->wpdb->get_var( $this->wpdb->prepare( $sql, ...$postTypes ) ) );
	}

	/** @return string[] */
	private function postTypes(): array {
		$postTypes = get_post_types( array( 'public' => true, 'publicly_queryable' => true ), 'names' );
		$postTypes = array_values( array_filter( array_map( 'sanitize_key', (array) $postTypes ) ) );

		return array_values( array_diff( $postTypes, array( 'attachment' ) ) );
	}
}
