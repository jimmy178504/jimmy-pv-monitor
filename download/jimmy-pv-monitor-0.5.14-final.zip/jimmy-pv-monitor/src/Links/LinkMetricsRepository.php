<?php

namespace Jimmy\PVMonitor\Links;

use Jimmy\PVMonitor\Collection\PageviewResult;
use Jimmy\PVMonitor\Database\TableNames;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Scalar values are prepared; table identifiers come from the internal TableNames registry.

final class LinkMetricsRepository {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	/** @param int[] $linkIds */
	public function recordImpressions( PageviewResult $pageview, array $linkIds ): bool|WP_Error {
		$linkIds = array_values( array_unique( array_filter( array_map( 'absint', array_slice( $linkIds, 0, 200 ) ) ) ) );
		if ( array() === $linkIds ) {
			return true;
		}

		$placeholders = implode( ',', array_fill( 0, count( $linkIds ), '%d' ) );
		$query = $this->wpdb->prepare(
			"SELECT id FROM {$this->tables->internalLinks()} WHERE source_page_id = %d AND link_type IN ('internal','external') AND is_active = 1 AND id IN ({$placeholders})",
			...array_merge( array( $pageview->pageId ), $linkIds )
		);
		$validIds = array_map( 'absint', (array) $this->wpdb->get_col( $query ) );
		if ( array() === $validIds ) {
			return true;
		}

		$values = array();
		$params = array();
		foreach ( $validIds as $linkId ) {
			$values[] = '(%s,%d,1,0,0,%s)';
			array_push( $params, $pageview->statDate, $linkId, $pageview->recordedAtUtc );
		}
		$sql = "INSERT INTO {$this->tables->internalLinkDaily()}
(stat_date,link_id,impression_views,clicked_views,raw_clicks,updated_at) VALUES " . implode( ',', $values ) .
			' ON DUPLICATE KEY UPDATE impression_views = impression_views + 1,updated_at = VALUES(updated_at)';
		if ( false === $this->wpdb->query( $this->wpdb->prepare( $sql, ...$params ) ) ) {
			return new WP_Error( 'jimmy_pv_link_impression_failed', __( 'リンク表示を記録できませんでした。', 'jimmy-pv-monitor' ) );
		}

		return true;
	}

	public function isActiveForPage( int $linkId, string $pageKey ): bool {
		$query = $this->wpdb->prepare(
			"SELECT 1 FROM {$this->tables->internalLinks()} l
INNER JOIN {$this->tables->pages()} p ON p.id = l.source_page_id
WHERE l.id = %d AND l.link_type IN ('internal','external') AND l.is_active = 1 AND p.page_key = %s LIMIT 1",
			$linkId,
			$pageKey
		);

		return 1 === (int) $this->wpdb->get_var( $query );
	}

	public function recordClick( int $linkId, bool $uniqueView ): bool|WP_Error {
		$statDate = wp_date( 'Y-m-d', null, wp_timezone() );
		$nowUtc   = gmdate( 'Y-m-d H:i:s' );
		$clicked  = $uniqueView ? 1 : 0;
		$query    = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->internalLinkDaily()}
(stat_date,link_id,impression_views,clicked_views,raw_clicks,last_clicked_at,updated_at)
VALUES (%s,%d,0,%d,1,%s,%s)
ON DUPLICATE KEY UPDATE clicked_views = clicked_views + %d,raw_clicks = raw_clicks + 1,last_clicked_at = VALUES(last_clicked_at),updated_at = VALUES(updated_at)",
			$statDate,
			$linkId,
			$clicked,
			$nowUtc,
			$nowUtc,
			$clicked
		);
		if ( false === $this->wpdb->query( $query ) ) {
			return new WP_Error( 'jimmy_pv_link_click_failed', __( 'リンククリックを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
		}

		return true;
	}
}
