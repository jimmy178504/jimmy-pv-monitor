<?php

namespace Jimmy\PVMonitor\Links;

use Jimmy\PVMonitor\Database\TableNames;
use Jimmy\PVMonitor\Pages\ResolvedPage;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Scalar values are prepared; table identifiers come from the internal TableNames registry.

final class LinkRepository {
	private const MAX_LINKS_PER_PAGE = 200;

	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function ensurePage( ResolvedPage $page ): int|WP_Error {
		if ( ! $page->isTrackable || null === $page->objectId ) {
			return new WP_Error( 'jimmy_pv_link_invalid_page', __( 'リンクがあるページを登録できませんでした。', 'jimmy-pv-monitor' ) );
		}

		$nowUtc = gmdate( 'Y-m-d H:i:s' );
		$query  = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->pages()}
(page_key,object_type,object_id,canonical_hash,canonical_url,title,total_pv,first_viewed_at,last_viewed_at,deleted_at,created_at,updated_at)
VALUES (%s,%s,%d,%s,%s,%s,0,NULL,NULL,NULL,%s,%s)
ON DUPLICATE KEY UPDATE object_type = VALUES(object_type),object_id = VALUES(object_id),
canonical_hash = VALUES(canonical_hash),canonical_url = VALUES(canonical_url),title = VALUES(title),deleted_at = NULL,updated_at = VALUES(updated_at)",
			$page->pageKey,
			$page->objectType,
			$page->objectId,
			$page->canonicalHash,
			$page->canonicalUrl,
			$page->title,
			$nowUtc,
			$nowUtc
		);
		if ( false === $this->wpdb->query( $query ) ) {
			return new WP_Error( 'jimmy_pv_link_page_write_failed', __( 'リンクがあるページを登録できませんでした。', 'jimmy-pv-monitor' ) );
		}

		$pageId = (int) $this->wpdb->get_var(
			$this->wpdb->prepare( "SELECT id FROM {$this->tables->pages()} WHERE page_key = %s LIMIT 1", $page->pageKey )
		);

		return 0 < $pageId
			? $pageId
			: new WP_Error( 'jimmy_pv_link_page_id_missing', __( 'リンクがあるページを登録できませんでした。', 'jimmy-pv-monitor' ) );
	}

	/** @param IndexedLink[] $links */
	public function replaceForSource( int $sourcePageId, array $links ): bool|WP_Error {
		if ( false === $this->wpdb->query( 'START TRANSACTION' ) ) {
			return $this->error( 'jimmy_pv_link_index_transaction_failed' );
		}

		if ( false === $this->wpdb->query( $this->wpdb->prepare( "UPDATE {$this->tables->internalLinks()} SET is_active = 0 WHERE source_page_id = %d", $sourcePageId ) ) ) {
			$this->wpdb->query( 'ROLLBACK' );
			return $this->error( 'jimmy_pv_link_deactivate_failed' );
		}

		$nowUtc = gmdate( 'Y-m-d H:i:s' );
		foreach ( $links as $link ) {
			if ( ! $link instanceof IndexedLink ) {
				continue;
			}
			$targetId = null === $link->targetPageId ? 'NULL' : '%d';
			$linkType = 'internal' === $link->linkType ? 'internal' : 'external';
			$sql = "INSERT INTO {$this->tables->internalLinks()}
(source_page_id,target_page_id,link_type,target_hash,target_url,anchor_text,is_active,first_seen_at,last_seen_at)
VALUES (%d,{$targetId},%s,%s,%s,%s,1,%s,%s)
ON DUPLICATE KEY UPDATE target_page_id = VALUES(target_page_id),link_type = VALUES(link_type),target_url = VALUES(target_url),anchor_text = VALUES(anchor_text),
is_active = 1,last_seen_at = VALUES(last_seen_at)";
			$params = array( $sourcePageId );
			if ( null !== $link->targetPageId ) {
				$params[] = $link->targetPageId;
			}
			array_push( $params, $linkType, $link->targetHash, $link->targetUrl, $link->anchorText, $nowUtc, $nowUtc );
			if ( false === $this->wpdb->query( $this->wpdb->prepare( $sql, ...$params ) ) ) {
				$this->wpdb->query( 'ROLLBACK' );
				return $this->error( 'jimmy_pv_link_upsert_failed' );
			}
		}

		if ( false === $this->wpdb->query( 'COMMIT' ) ) {
			$this->wpdb->query( 'ROLLBACK' );
			return $this->error( 'jimmy_pv_link_index_commit_failed' );
		}

		return true;
	}

	public function ensureForPage( ResolvedPage $page, string $targetHash, string $targetUrl, string $anchorText, string $linkType ): int|WP_Error {
		$sourcePageId = $this->ensurePage( $page );
		if ( $sourcePageId instanceof WP_Error ) {
			return $sourcePageId;
		}

		$existingId = (int) $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT id FROM {$this->tables->internalLinks()} WHERE source_page_id = %d AND target_hash = %s LIMIT 1",
				$sourcePageId,
				$targetHash
			)
		);
		$linkType = 'internal' === $linkType ? 'internal' : 'external';
		$nowUtc = gmdate( 'Y-m-d H:i:s' );
		if ( 0 < $existingId ) {
			$updated = $this->wpdb->query(
				$this->wpdb->prepare(
					"UPDATE {$this->tables->internalLinks()} SET target_page_id = NULL,link_type = %s,target_url = %s,anchor_text = %s,is_active = 1,last_seen_at = %s WHERE id = %d",
					$linkType,
					$targetUrl,
					$anchorText,
					$nowUtc,
					$existingId
				)
			);

			return false === $updated ? $this->error( 'jimmy_pv_link_dynamic_update_failed' ) : $existingId;
		}

		$linkCount = (int) $this->wpdb->get_var(
			$this->wpdb->prepare( "SELECT COUNT(*) FROM {$this->tables->internalLinks()} WHERE source_page_id = %d", $sourcePageId )
		);
		if ( self::MAX_LINKS_PER_PAGE <= $linkCount ) {
			return new WP_Error( 'jimmy_pv_link_limit_reached', __( 'このページで計測できるリンク数の上限に達しました。', 'jimmy-pv-monitor' ) );
		}

		$query = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->internalLinks()}
(source_page_id,target_page_id,link_type,target_hash,target_url,anchor_text,is_active,first_seen_at,last_seen_at)
VALUES (%d,NULL,%s,%s,%s,%s,1,%s,%s)
ON DUPLICATE KEY UPDATE id = LAST_INSERT_ID(id),target_page_id = NULL,link_type = VALUES(link_type),target_url = VALUES(target_url),anchor_text = VALUES(anchor_text),is_active = 1,last_seen_at = VALUES(last_seen_at)",
			$sourcePageId,
			$linkType,
			$targetHash,
			$targetUrl,
			$anchorText,
			$nowUtc,
			$nowUtc
		);
		if ( false === $this->wpdb->query( $query ) ) {
			return $this->error( 'jimmy_pv_link_dynamic_insert_failed' );
		}

		$linkId = (int) $this->wpdb->insert_id;
		if ( 0 >= $linkId ) {
			$linkId = (int) $this->wpdb->get_var(
				$this->wpdb->prepare(
					"SELECT id FROM {$this->tables->internalLinks()} WHERE source_page_id = %d AND target_hash = %s LIMIT 1",
					$sourcePageId,
					$targetHash
				)
			);
		}

		return 0 < $linkId ? $linkId : $this->error( 'jimmy_pv_link_dynamic_id_missing' );
	}

	public function ensureExternalForPage( ResolvedPage $page, string $targetHash, string $targetUrl, string $anchorText ): int|WP_Error {
		return $this->ensureForPage( $page, $targetHash, $targetUrl, $anchorText, 'external' );
	}

	public function deactivateByPostId( int $postId ): void {
		$query = $this->wpdb->prepare(
			"UPDATE {$this->tables->internalLinks()} l INNER JOIN {$this->tables->pages()} p ON p.id = l.source_page_id
SET l.is_active = 0 WHERE p.page_key = %s",
			'post:' . $postId
		);
		$this->wpdb->query( $query );
	}

	/** @return array<string, int> */
	public function activeMapForPost( int $postId ): array {
		$query = $this->wpdb->prepare(
			"SELECT l.target_hash,l.id FROM {$this->tables->internalLinks()} l
INNER JOIN {$this->tables->pages()} p ON p.id = l.source_page_id
WHERE p.page_key = %s AND l.link_type IN ('internal','external') AND l.is_active = 1 ORDER BY l.id ASC LIMIT 200",
			'post:' . $postId
		);
		$map = array();
		foreach ( (array) $this->wpdb->get_results( $query, ARRAY_A ) as $row ) {
			$map[ (string) $row['target_hash'] ] = max( 0, (int) $row['id'] );
		}

		return array_filter( $map );
	}

	private function error( string $code ): WP_Error {
		return new WP_Error( $code, __( 'リンク索引を更新できませんでした。', 'jimmy-pv-monitor' ) );
	}
}
