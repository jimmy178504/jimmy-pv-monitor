<?php

namespace Jimmy\PVMonitor\Admin;

defined( 'ABSPATH' ) || exit;

final class Assets {
	private const PAGE_HOOKS = array(
		'index.php',
		'toplevel_page_jimmy-pv',
		'jimmy-pv_page_jimmy-pv-pages',
		'jimmy-pv_page_jimmy-pv-referrers',
		'jimmy-pv_page_jimmy-pv-links',
		'jimmy-pv_page_jimmy-pv-export',
		'jimmy-pv_page_jimmy-pv-settings',
	);

	public function register(): void {
		add_action( 'admin_enqueue_scripts', array( $this, 'enqueue' ) );
	}

	public function enqueue( string $hookSuffix ): void {
		if ( ! in_array( $hookSuffix, self::PAGE_HOOKS, true ) ) {
			return;
		}
		if ( 'index.php' === $hookSuffix && ! current_user_can( 'jimmy_pv_view_reports' ) ) {
			return;
		}

		wp_enqueue_style(
			'jimmy-pv-admin',
			JIMMY_PV_URL . 'assets/css/admin.css',
			array(),
			JIMMY_PV_VERSION
		);
		wp_enqueue_script(
			'jimmy-pv-admin',
			JIMMY_PV_URL . 'assets/js/admin.js',
			array(),
			JIMMY_PV_VERSION,
			array( 'in_footer' => true )
		);
		wp_localize_script(
			'jimmy-pv-admin',
			'jimmyPvAdminL10n',
			array(
				'chartLabel' => __( '日別PV推移グラフ', 'jimmy-pv-monitor' ),
				'noData'     => __( '選択期間のPVデータはまだありません。', 'jimmy-pv-monitor' ),
			)
		);
	}
}
