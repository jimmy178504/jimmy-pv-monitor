<?php

namespace Jimmy\PVMonitor\Admin;

defined( 'ABSPATH' ) || exit;

final class Menu {
	public function __construct(
		private readonly DashboardPage $dashboard,
		private readonly PagesPage $pages,
		private readonly ReferrersPage $referrers,
		private readonly LinksPage $links,
		private readonly ExportPage $export,
		private readonly SettingsPage $settings
	) {}

	public function register(): void {
		add_action( 'admin_menu', array( $this, 'addPages' ) );
	}

	public function addPages(): void {
		add_menu_page(
			__( 'Jimmy PV ダッシュボード', 'jimmy-pv-monitor' ),
			__( 'Jimmy PV', 'jimmy-pv-monitor' ),
			'jimmy_pv_view_reports',
			'jimmy-pv',
			array( $this->dashboard, 'render' ),
			'dashicons-chart-area',
			58
		);

		add_submenu_page(
			'jimmy-pv',
			__( 'ダッシュボード', 'jimmy-pv-monitor' ),
			__( 'ダッシュボード', 'jimmy-pv-monitor' ),
			'jimmy_pv_view_reports',
			'jimmy-pv',
			array( $this->dashboard, 'render' )
		);

		add_submenu_page(
			'jimmy-pv',
			__( 'ページ別PV', 'jimmy-pv-monitor' ),
			__( 'ページ別PV', 'jimmy-pv-monitor' ),
			'jimmy_pv_view_reports',
			'jimmy-pv-pages',
			array( $this->pages, 'render' )
		);

		add_submenu_page(
			'jimmy-pv',
			__( '流入元', 'jimmy-pv-monitor' ),
			__( '流入元', 'jimmy-pv-monitor' ),
			'jimmy_pv_view_reports',
			'jimmy-pv-referrers',
			array( $this->referrers, 'render' )
		);

		add_submenu_page(
			'jimmy-pv',
			__( 'クリック計測', 'jimmy-pv-monitor' ),
			__( 'クリック計測', 'jimmy-pv-monitor' ),
			'jimmy_pv_view_reports',
			'jimmy-pv-links',
			array( $this->links, 'render' )
		);

		add_submenu_page(
			'jimmy-pv',
			__( 'CSV出力', 'jimmy-pv-monitor' ),
			__( 'CSV出力', 'jimmy-pv-monitor' ),
			'jimmy_pv_export_data',
			'jimmy-pv-export',
			array( $this->export, 'render' )
		);

		add_submenu_page(
			'jimmy-pv',
			__( '設定', 'jimmy-pv-monitor' ),
			__( '設定', 'jimmy-pv-monitor' ),
			'jimmy_pv_manage_settings',
			'jimmy-pv-settings',
			array( $this->settings, 'render' )
		);

		do_action( 'jimmy_pv_register_admin_pages' );
	}
}
