<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Database\TableNames;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- DELETE targets are fixed identifiers from the internal TableNames registry.

final class DataResetter {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function reset(): bool|WP_Error {
		if ( false === $this->wpdb->query( 'START TRANSACTION' ) ) {
			return new WP_Error( 'jimmy_pv_reset_transaction_failed', __( 'データ削除を開始できませんでした。', 'jimmy-pv-monitor' ) );
		}

		$orderedTables = array(
			$this->tables->eventDedupe(),
			$this->tables->internalLinkDaily(),
			$this->tables->internalLinks(),
			$this->tables->campaignDaily(),
			$this->tables->referrerDaily(),
			$this->tables->referrers(),
			$this->tables->daily(),
			$this->tables->pages(),
		);

		foreach ( $orderedTables as $table ) {
			if ( false === $this->wpdb->query( "DELETE FROM {$table}" ) ) {
				$this->wpdb->query( 'ROLLBACK' );

				return new WP_Error( 'jimmy_pv_reset_delete_failed', __( '一部の解析データを削除できませんでした。', 'jimmy-pv-monitor' ) );
			}
		}

		if ( false === $this->wpdb->query( 'COMMIT' ) ) {
			$this->wpdb->query( 'ROLLBACK' );

			return new WP_Error( 'jimmy_pv_reset_commit_failed', __( '解析データの削除を確定できませんでした。', 'jimmy-pv-monitor' ) );
		}

		$generation = (int) get_option( 'jimmy_pv_report_cache_generation', 1 );
		update_option( 'jimmy_pv_report_cache_generation', $generation + 1, false );
		delete_option( 'jimmy_pv_link_index_state' );

		return true;
	}
}
