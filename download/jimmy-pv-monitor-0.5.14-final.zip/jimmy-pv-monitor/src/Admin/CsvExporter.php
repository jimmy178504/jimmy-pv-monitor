<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Reporting\AnalyticsRepository;
use Jimmy\PVMonitor\Reporting\DateRangeFactory;
use Jimmy\PVMonitor\Settings\SettingsRepository;

defined( 'ABSPATH' ) || exit;

final class CsvExporter {
	public function __construct(
		private readonly AnalyticsRepository $analytics,
		private readonly DateRangeFactory $dates,
		private readonly CsvSanitizer $sanitizer,
		private readonly SettingsRepository $settings
	) {}

	public function register(): void {
		add_action( 'admin_post_jimmy_pv_export', array( $this, 'export' ) );
	}

	public function export(): void {
		if ( ! current_user_can( 'jimmy_pv_export_data' ) ) {
			wp_die( esc_html__( 'CSVを出力する権限がありません。', 'jimmy-pv-monitor' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'jimmy_pv_export', 'jimmy_pv_nonce' );

		$report = isset( $_POST['report'] ) && is_scalar( $_POST['report'] )
			? sanitize_key( wp_unslash( (string) $_POST['report'] ) )
			: '';
		if ( ! in_array( $report, array( 'daily', 'pages', 'referrers', 'campaigns', 'clicks', 'external-links', 'internal-links' ), true ) ) {
			wp_die( esc_html__( 'CSVの種類が正しくありません。', 'jimmy-pv-monitor' ), '', array( 'response' => 400 ) );
		}

		$source = array(
			'range' => 'custom',
			'from'  => isset( $_POST['from'] ) && is_scalar( $_POST['from'] )
				? sanitize_text_field( wp_unslash( (string) $_POST['from'] ) )
				: '',
			'to'    => isset( $_POST['to'] ) && is_scalar( $_POST['to'] )
				? sanitize_text_field( wp_unslash( (string) $_POST['to'] ) )
				: '',
		);
		$range = $this->dates->fromRequest( $source, false );
		if ( headers_sent() ) {
			wp_die( esc_html__( 'HTTPヘッダーが既に送信されたためCSVを出力できません。', 'jimmy-pv-monitor' ) );
		}

		$filename = sprintf( 'jimmy-pv-%s-%s-%s.csv', $report, $range->fromSql(), $range->toSql() );
		nocache_headers();
		header( 'Content-Type: text/csv; charset=UTF-8' );
		header( 'Content-Disposition: attachment; filename="' . $filename . '"' );
		header( 'X-Content-Type-Options: nosniff' );

		$stream = fopen( 'php://output', 'wb' );
		if ( false === $stream ) {
			wp_die( esc_html__( 'CSV出力を開始できませんでした。', 'jimmy-pv-monitor' ) );
		}

			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fwrite -- This is a streamed HTTP download, not a filesystem write.
			fwrite( $stream, "\xEF\xBB\xBF" );
		if ( 'daily' === $report ) {
			$this->writeDaily( $stream, $range );
		} elseif ( 'pages' === $report ) {
			$this->writePages( $stream, $range );
		} elseif ( 'referrers' === $report ) {
			$this->writeReferrers( $stream, $range );
		} elseif ( 'campaigns' === $report ) {
			$this->writeCampaigns( $stream, $range );
		} else {
			$this->writeClicks( $stream, $range );
		}
			// phpcs:ignore WordPress.WP.AlternativeFunctions.file_system_operations_fclose -- Close the streamed HTTP response handle.
			fclose( $stream );
		exit;
	}

	/** @param resource $stream */
	private function writeDaily( $stream, \Jimmy\PVMonitor\Reporting\DateRange $range ): void {
		$this->row( $stream, array( __( '日付', 'jimmy-pv-monitor' ), 'PV' ) );
		foreach ( $this->analytics->dailyExport( $range ) as $item ) {
			$this->row( $stream, array( $item['date'], $item['pv'] ) );
		}
	}

	/** @param resource $stream */
	private function writePages( $stream, \Jimmy\PVMonitor\Reporting\DateRange $range ): void {
		$this->row(
			$stream,
			array(
				__( '記事ID（トップページは空欄）', 'jimmy-pv-monitor' ),
				__( 'タイトル', 'jimmy-pv-monitor' ),
				'URL',
				__( 'ページの種類', 'jimmy-pv-monitor' ),
				__( '期間PV', 'jimmy-pv-monitor' ),
				__( '累計PV', 'jimmy-pv-monitor' ),
			)
		);
		foreach ( $this->analytics->pageExport( $range, (bool) $this->settings->get( 'track_home', true ) ) as $item ) {
			$this->row(
				$stream,
				array(
					'home' === $item['object_type'] ? '' : $item['object_id'],
					'home' === $item['object_type'] ? __( 'トップページ', 'jimmy-pv-monitor' ) : $item['title'],
					$item['canonical_url'],
					$item['post_type'],
					$item['period_pv'],
					$item['total_pv'],
				)
			);
		}
	}

	/** @param resource $stream */
	private function writeReferrers( $stream, \Jimmy\PVMonitor\Reporting\DateRange $range ): void {
		$this->row( $stream, array( __( '日付', 'jimmy-pv-monitor' ), __( '最初に見られたページ', 'jimmy-pv-monitor' ), __( '最初に見られたページのURL', 'jimmy-pv-monitor' ), __( '分類', 'jimmy-pv-monitor' ), __( '流入元の名前', 'jimmy-pv-monitor' ), __( 'ドメイン', 'jimmy-pv-monitor' ), __( '参照元URL', 'jimmy-pv-monitor' ), 'PV' ) );
		foreach ( $this->analytics->referrerExport( $range ) as $item ) {
			$this->row( $stream, array( $item['stat_date'], $item['landing_title'], $item['landing_url'], SourceLabels::get( (string) $item['source_type'] ), $item['source_name'], $item['domain'], $item['referrer_url'], $item['pv'] ) );
		}
	}

	/** @param resource $stream */
	private function writeCampaigns( $stream, \Jimmy\PVMonitor\Reporting\DateRange $range ): void {
		$this->row( $stream, array( __( '日付', 'jimmy-pv-monitor' ), 'utm_source', 'utm_medium', 'utm_campaign', 'utm_term', 'utm_content', __( '広告サービス', 'jimmy-pv-monitor' ), __( '最初に見られたページ', 'jimmy-pv-monitor' ), __( '最初に見られたページのURL', 'jimmy-pv-monitor' ), 'PV' ) );
		foreach ( $this->analytics->campaignExport( $range ) as $item ) {
			$this->row( $stream, array( $item['stat_date'], $item['utm_source'], $item['utm_medium'], $item['utm_campaign'], $item['utm_term'], $item['utm_content'], $item['ad_platform'], $item['landing_title'], $item['landing_url'], $item['pv'] ) );
		}
	}

	/** @param resource $stream */
	private function writeClicks( $stream, \Jimmy\PVMonitor\Reporting\DateRange $range ): void {
		$this->row(
			$stream,
			array(
				__( 'リンクがある記事ID', 'jimmy-pv-monitor' ),
				__( 'リンクがあるページ', 'jimmy-pv-monitor' ),
				__( 'リンクがあるページのURL', 'jimmy-pv-monitor' ),
				__( 'リンクの文字', 'jimmy-pv-monitor' ),
				__( 'リンクの種類', 'jimmy-pv-monitor' ),
				__( 'クリック先ドメイン', 'jimmy-pv-monitor' ),
				__( 'クリック先URL', 'jimmy-pv-monitor' ),
				__( 'クリックがあった表示', 'jimmy-pv-monitor' ),
				__( 'クリック総数', 'jimmy-pv-monitor' ),
				__( '最終クリック日時', 'jimmy-pv-monitor' ),
				__( '掲載ページのPV', 'jimmy-pv-monitor' ),
				__( 'PVに対するクリック率（%）', 'jimmy-pv-monitor' ),
			)
		);
		foreach ( $this->analytics->clickExport( $range ) as $item ) {
			$this->row(
				$stream,
				array(
					$item['source_object_id'],
					$item['source_title'],
					$item['source_url'],
					$item['anchor_text'],
					'internal' === (string) $item['link_type'] ? __( 'サイト内', 'jimmy-pv-monitor' ) : __( '外部', 'jimmy-pv-monitor' ),
					$item['target_domain'],
					$item['target_url'],
					$item['clicked_views'],
					$item['raw_clicks'],
					$item['last_clicked_at'],
					$item['source_pv'],
					round( (float) $item['click_rate'] * 100, 1 ),
				)
			);
		}
	}

	/** @param resource $stream
	 *  @param array<int, mixed> $values
	 */
	private function row( $stream, array $values ): void {
		fputcsv( $stream, array_map( array( $this->sanitizer, 'cell' ), $values ), ',', '"', '', "\r\n" );
	}
}
