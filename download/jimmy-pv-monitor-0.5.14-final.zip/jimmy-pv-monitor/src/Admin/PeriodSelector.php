<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Reporting\DateRange;

defined( 'ABSPATH' ) || exit;

final class PeriodSelector {
	/** @param array<string, string|int> $hidden */
	public function render( string $pageSlug, DateRange $range, array $hidden = array() ): void {
		?>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="jimmy-pv-period-form">
			<input type="hidden" name="page" value="<?php echo esc_attr( $pageSlug ); ?>">
			<?php foreach ( $hidden as $name => $value ) : ?>
				<input type="hidden" name="<?php echo esc_attr( $name ); ?>" value="<?php echo esc_attr( (string) $value ); ?>">
			<?php endforeach; ?>
			<label>
				<span><?php esc_html_e( '期間', 'jimmy-pv-monitor' ); ?></span>
				<select name="range" data-jimmy-pv-range>
					<option value="today" <?php selected( $range->preset, 'today' ); ?>><?php esc_html_e( '今日', 'jimmy-pv-monitor' ); ?></option>
					<option value="3d" <?php selected( $range->preset, '3d' ); ?>><?php esc_html_e( '過去3日（今日を含む）', 'jimmy-pv-monitor' ); ?></option>
					<option value="7d" <?php selected( $range->preset, '7d' ); ?>><?php esc_html_e( '過去7日', 'jimmy-pv-monitor' ); ?></option>
					<option value="30d" <?php selected( $range->preset, '30d' ); ?>><?php esc_html_e( '過去30日', 'jimmy-pv-monitor' ); ?></option>
					<option value="custom" <?php selected( $range->preset, 'custom' ); ?>><?php esc_html_e( '任意期間', 'jimmy-pv-monitor' ); ?></option>
				</select>
			</label>
			<span class="jimmy-pv-custom-dates" data-jimmy-pv-custom-dates>
				<label>
					<span><?php esc_html_e( '開始日', 'jimmy-pv-monitor' ); ?></span>
					<input type="date" name="from" value="<?php echo esc_attr( $range->fromSql() ); ?>">
				</label>
				<label>
					<span><?php esc_html_e( '終了日', 'jimmy-pv-monitor' ); ?></span>
					<input type="date" name="to" value="<?php echo esc_attr( $range->toSql() ); ?>">
				</label>
			</span>
			<button type="submit" class="button button-primary"><?php esc_html_e( '適用', 'jimmy-pv-monitor' ); ?></button>
		</form>
		<?php
	}
}
