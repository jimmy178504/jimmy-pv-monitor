<?php

namespace Jimmy\PVMonitor\Admin;

defined( 'ABSPATH' ) || exit;

final class SourceLabels {
	public static function get( string $type ): string {
		$labels = array(
			'direct'   => __( '直接・不明', 'jimmy-pv-monitor' ),
			'search'   => __( '検索', 'jimmy-pv-monitor' ),
			'social'   => __( 'SNS', 'jimmy-pv-monitor' ),
			'referral' => __( '外部サイト', 'jimmy-pv-monitor' ),
			'internal' => __( 'サイト内', 'jimmy-pv-monitor' ),
		);

		return $labels[ $type ] ?? $type;
	}
}
