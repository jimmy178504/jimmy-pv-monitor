<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Reporting\AnalyticsRepository;
use Jimmy\PVMonitor\Reporting\DateRange;
use Jimmy\PVMonitor\Reporting\DateRangeFactory;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET values only filter and paginate this read-only report.

final class ReferrersPage {
	private const PER_PAGE_OPTIONS = array( 20, 50, 100, 200 );
	private const VIEWS = array( 'referrers', 'campaigns' );

	public function __construct(
		private readonly AnalyticsRepository $analytics,
		private readonly DateRangeFactory $dates,
		private readonly PeriodSelector $periods
	) {}

	public function render(): void {
		if ( ! current_user_can( 'jimmy_pv_view_reports' ) ) {
			wp_die( esc_html__( 'このレポートを表示する権限がありません。', 'jimmy-pv-monitor' ) );
		}

		$range      = $this->dates->fromRequest( $_GET );
		$view       = $this->view();
		$sourceType = $this->allowedGet( 'source_type', array( 'direct', 'search', 'social', 'referral' ), '' );
		$search     = $this->search();
		$orderBy    = $this->allowedGet( 'orderby', array( 'period_pv', 'domain', 'source_type' ), 'period_pv' );
		$order      = $this->allowedGet( 'order', array( 'asc', 'desc' ), 'desc' );
		$page       = max( 1, $this->integerGet( 'paged', 1 ) );
		$perPage    = $this->integerGet( 'per_page', 50 );
		$perPage    = in_array( $perPage, self::PER_PAGE_OPTIONS, true ) ? $perPage : 50;
		$report     = array( 'rows' => array(), 'total' => 0, 'page' => 1 );
		$campaigns  = array();
		if ( 'referrers' === $view ) {
			$report = $this->analytics->referrers( $range, $search, $sourceType, $orderBy, $order, $page, $perPage );
		} else {
			$campaigns = $this->analytics->campaigns( $range, 50 );
		}
		$page       = (int) $report['page'];
		?>
		<div class="wrap jimmy-pv-admin">
			<h1><?php esc_html_e( '流入元', 'jimmy-pv-monitor' ); ?></h1>
			<?php Tabs::render( 'jimmy-pv-referrers' ); ?>
			<p><?php esc_html_e( '検索サイトや他のWebサイトなど、読者がどこから訪れ、最初にどのページを見たかを確認できます。', 'jimmy-pv-monitor' ); ?></p>
			<p class="description"><?php esc_html_e( '参照元URLはブラウザーから提供された範囲で表示します。相手サイトやブラウザーの設定により、完全なURLではなくドメインのみ、または「直接・不明」になる場合があります。同じブログ内からのページ移動は流入元に含めません。', 'jimmy-pv-monitor' ); ?></p>
			<?php $this->renderViewTabs( $view, $range ); ?>

			<?php if ( 'referrers' === $view ) : ?>
			<?php $this->renderFilters( $range, $sourceType, $search, $orderBy, $order, $perPage ); ?>
			<p class="description">
				<?php echo esc_html( sprintf( '%s・流入元 %s件', $range->label(), number_format_i18n( (int) $report['total'] ) ) ); ?>
			</p>
			<p class="description"><?php esc_html_e( '流入元ごとに1行で表示します。「最初に見られたページの内訳」を押すと、その流入元からどのページへ何PVあったかを確認できます。', 'jimmy-pv-monitor' ); ?></p>

			<table class="widefat striped jimmy-pv-report-table">
				<thead><tr>
					<th><?php esc_html_e( '流入元', 'jimmy-pv-monitor' ); ?></th>
					<th><?php echo wp_kses_post( $this->sortLink( __( '分類', 'jimmy-pv-monitor' ), 'source_type', $orderBy, $order ) ); ?></th>
					<th><?php echo wp_kses_post( $this->sortLink( __( '参照元URL', 'jimmy-pv-monitor' ), 'domain', $orderBy, $order ) ); ?></th>
					<th class="jimmy-pv-number"><?php esc_html_e( '最初に見られたページ数', 'jimmy-pv-monitor' ); ?></th>
					<th class="jimmy-pv-number"><?php echo wp_kses_post( $this->sortLink( __( '期間PV', 'jimmy-pv-monitor' ), 'period_pv', $orderBy, $order ) ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( array() === $report['rows'] ) : ?>
					<tr><td colspan="5"><?php esc_html_e( '条件に一致する流入データはありません。', 'jimmy-pv-monitor' ); ?></td></tr>
				<?php else : foreach ( $report['rows'] as $row ) : ?>
					<tr class="jimmy-pv-group-summary">
						<td><strong><?php echo esc_html( $this->sourceName( $row ) ); ?></strong></td>
						<td><?php echo esc_html( SourceLabels::get( (string) $row['source_type'] ) ); ?></td>
						<td class="jimmy-pv-url-cell"><?php $this->referrer( (string) $row['referrer_url'], (string) $row['domain'] ); ?></td>
						<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['landing_count'] ) ); ?></td>
						<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['period_pv'] ) ); ?></td>
					</tr>
					<tr class="jimmy-pv-group-details"><td colspan="5"><details><summary><?php esc_html_e( '最初に見られたページの内訳を表示', 'jimmy-pv-monitor' ); ?></summary>
						<div class="jimmy-pv-breakdown-scroll"><table class="widefat striped jimmy-pv-breakdown-table"><thead><tr><th><?php esc_html_e( '最初に見られたページ', 'jimmy-pv-monitor' ); ?></th><th class="jimmy-pv-number"><?php esc_html_e( 'PV', 'jimmy-pv-monitor' ); ?></th><th class="jimmy-pv-number"><?php esc_html_e( 'この流入元のPVに占める割合', 'jimmy-pv-monitor' ); ?></th></tr></thead><tbody>
						<?php foreach ( (array) $row['landings'] as $landing ) : ?><tr><td><a href="<?php echo esc_url( (string) $landing['landing_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $this->pageTitle( $landing ) ); ?></a></td><td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $landing['period_pv'] ) ); ?></td><td class="jimmy-pv-number"><?php echo esc_html( 0 < (int) $row['period_pv'] ? number_format_i18n( (int) $landing['period_pv'] / (int) $row['period_pv'] * 100, 1 ) . '%' : '0.0%' ); ?></td></tr><?php endforeach; ?>
						</tbody></table></div>
					</details></td></tr>
				<?php endforeach; endif; ?>
				</tbody>
			</table>
			<?php $this->pagination( (int) $report['total'], $page, $perPage ); ?>
			<?php else : ?>
			<?php $this->periods->render( 'jimmy-pv-referrers', $range, array( 'view' => 'campaigns' ) ); ?>
			<section class="jimmy-pv-panel">
				<h2><?php esc_html_e( 'UTM・広告キャンペーン 上位50件', 'jimmy-pv-monitor' ); ?></h2>
				<p class="description"><?php esc_html_e( 'UTMは、広告やSNS投稿などのリンクに付けて流入経路を見分けるための識別情報です。広告固有のクリックIDは保存せず、広告サービス名だけを表示します。このPVは上の流入元集計にも含まれます。', 'jimmy-pv-monitor' ); ?></p>
				<?php $this->renderCampaigns( $campaigns ); ?>
			</section>
			<?php endif; ?>
		</div>
		<?php
	}

	private function renderViewTabs( string $current, DateRange $range ): void {
		$tabs = array(
			'referrers' => __( '検索・他サイトなどからの流入', 'jimmy-pv-monitor' ),
			'campaigns' => __( 'UTM・広告からの流入', 'jimmy-pv-monitor' ),
		);
		?>
		<nav class="jimmy-pv-view-tabs" aria-label="<?php esc_attr_e( '表示する流入元データ', 'jimmy-pv-monitor' ); ?>">
			<?php foreach ( $tabs as $view => $label ) : ?>
				<?php
				$url = add_query_arg(
					array(
						'page'  => 'jimmy-pv-referrers',
						'view'  => $view,
						'range' => $range->preset,
						'from'  => $range->fromSql(),
						'to'    => $range->toSql(),
					),
					admin_url( 'admin.php' )
				);
				$class = 'jimmy-pv-view-tab' . ( $current === $view ? ' is-active' : '' );
				?>
				<a class="<?php echo esc_attr( $class ); ?>" href="<?php echo esc_url( $url ); ?>"<?php if ( $current === $view ) : ?> aria-current="page"<?php endif; ?>><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>
		<?php
	}

	private function view(): string {
		$requested = isset( $_GET['view'] ) && is_scalar( $_GET['view'] ) ? sanitize_key( wp_unslash( (string) $_GET['view'] ) ) : 'referrers';

		return in_array( $requested, self::VIEWS, true ) ? $requested : 'referrers';
	}

	private function renderFilters( DateRange $range, string $sourceType, string $search, string $orderBy, string $order, int $perPage ): void {
		?>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="jimmy-pv-filter-form">
			<input type="hidden" name="page" value="jimmy-pv-referrers">
			<input type="hidden" name="view" value="referrers">
			<label><?php esc_html_e( '期間', 'jimmy-pv-monitor' ); ?><select name="range" data-jimmy-pv-range>
			<?php foreach ( array( 'today' => __( '今日', 'jimmy-pv-monitor' ), '3d' => __( '過去3日（今日を含む）', 'jimmy-pv-monitor' ), '7d' => __( '過去7日', 'jimmy-pv-monitor' ), '30d' => __( '過去30日', 'jimmy-pv-monitor' ), 'custom' => __( '任意期間', 'jimmy-pv-monitor' ) ) as $value => $label ) : ?>
				<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $range->preset, $value ); ?>><?php echo esc_html( $label ); ?></option>
			<?php endforeach; ?></select></label>
			<span class="jimmy-pv-custom-dates" data-jimmy-pv-custom-dates>
				<label><?php esc_html_e( '開始日', 'jimmy-pv-monitor' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $range->fromSql() ); ?>"></label>
				<label><?php esc_html_e( '終了日', 'jimmy-pv-monitor' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $range->toSql() ); ?>"></label>
			</span>
			<label><?php esc_html_e( '分類', 'jimmy-pv-monitor' ); ?><select name="source_type"><option value=""><?php esc_html_e( 'すべて', 'jimmy-pv-monitor' ); ?></option>
			<?php foreach ( array( 'direct', 'search', 'social', 'referral' ) as $type ) : ?><option value="<?php echo esc_attr( $type ); ?>" <?php selected( $sourceType, $type ); ?>><?php echo esc_html( SourceLabels::get( $type ) ); ?></option><?php endforeach; ?></select></label>
			<label><?php esc_html_e( '検索', 'jimmy-pv-monitor' ); ?> <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" maxlength="100"></label>
			<label><?php esc_html_e( '表示件数', 'jimmy-pv-monitor' ); ?><select name="per_page"><?php foreach ( self::PER_PAGE_OPTIONS as $option ) : ?><option value="<?php echo esc_attr( (string) $option ); ?>" <?php selected( $perPage, $option ); ?>><?php echo esc_html( (string) $option ); ?></option><?php endforeach; ?></select></label>
			<input type="hidden" name="orderby" value="<?php echo esc_attr( $orderBy ); ?>"><input type="hidden" name="order" value="<?php echo esc_attr( $order ); ?>">
			<button type="submit" class="button button-primary"><?php esc_html_e( '絞り込む', 'jimmy-pv-monitor' ); ?></button>
		</form>
		<?php
	}

	/** @param array<int, array<string, mixed>> $rows */
	private function renderCampaigns( array $rows ): void {
		if ( array() === $rows ) {
			echo '<p>' . esc_html__( '選択期間のキャンペーンデータはまだありません。', 'jimmy-pv-monitor' ) . '</p>';
			return;
		}
		?>
		<div class="jimmy-pv-table-scroll"><table class="widefat striped"><thead><tr>
			<th>utm_source</th><th>utm_medium</th><th>utm_campaign</th><th>utm_term</th><th>utm_content</th><th><?php esc_html_e( '広告', 'jimmy-pv-monitor' ); ?></th><th><?php esc_html_e( '最初に見られたページ', 'jimmy-pv-monitor' ); ?></th><th class="jimmy-pv-number">PV</th>
		</tr></thead><tbody><?php foreach ( $rows as $row ) : ?><tr>
			<td><?php echo esc_html( (string) $row['utm_source'] ); ?></td><td><?php echo esc_html( (string) $row['utm_medium'] ); ?></td><td><?php echo esc_html( (string) $row['utm_campaign'] ); ?></td><td><?php echo esc_html( (string) $row['utm_term'] ); ?></td><td><?php echo esc_html( (string) $row['utm_content'] ); ?></td><td><?php echo esc_html( (string) $row['ad_platform'] ); ?></td>
			<td><a href="<?php echo esc_url( (string) $row['landing_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( (string) $row['landing_title'] ); ?></a></td><td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['period_pv'] ) ); ?></td>
		</tr><?php endforeach; ?></tbody></table></div>
		<?php
	}

	private function referrer( string $url, string $domain ): void {
		if ( '' === $url ) {
			echo esc_html__( '参照元なし', 'jimmy-pv-monitor' );
			return;
		}
		echo '<strong>' . esc_html( $domain ) . '</strong><br><a href="' . esc_url( $url ) . '" target="_blank" rel="noopener noreferrer">' . esc_html( $url ) . '</a>';
	}

	/** @param array<string, mixed> $row */
	private function sourceName( array $row ): string {
		if ( '' !== (string) ( $row['source_name'] ?? '' ) ) {
			return (string) $row['source_name'];
		}
		if ( '' !== (string) ( $row['domain'] ?? '' ) ) {
			return (string) $row['domain'];
		}

		return __( '直接・不明', 'jimmy-pv-monitor' );
	}

	/** @param array<string, mixed> $row */
	private function pageTitle( array $row ): string {
		return 'home' === (string) ( $row['object_type'] ?? '' )
			? __( 'トップページ', 'jimmy-pv-monitor' )
			: (string) ( $row['landing_title'] ?? '' );
	}

	private function search(): string {
		$value = isset( $_GET['s'] ) && is_scalar( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['s'] ) ) : '';
		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, 100 ) : substr( $value, 0, 100 );
	}

	/** @param string[] $allowed */
	private function allowedGet( string $key, array $allowed, string $fallback ): string {
		$value = isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? sanitize_key( wp_unslash( (string) $_GET[ $key ] ) ) : '';
		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	private function integerGet( string $key, int $fallback ): int {
		return isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? absint( wp_unslash( (string) $_GET[ $key ] ) ) : $fallback;
	}

	private function sortLink( string $label, string $column, string $currentColumn, string $currentOrder ): string {
		$order = $column === $currentColumn && 'desc' === $currentOrder ? 'asc' : 'desc';
		return sprintf( '<a href="%1$s">%2$s</a>', esc_url( add_query_arg( array( 'orderby' => $column, 'order' => $order, 'paged' => false ) ) ), esc_html( $label ) );
	}

	private function pagination( int $total, int $page, int $perPage ): void {
		$totalPages = (int) ceil( $total / $perPage );
		if ( 1 >= $totalPages ) {
			return;
		}
		$base = str_replace( '999999999', '%#%', add_query_arg( 'paged', 999999999 ) );
		echo '<div class="tablenav"><div class="tablenav-pages">' . wp_kses_post( paginate_links( array( 'base' => $base, 'format' => '', 'current' => $page, 'total' => $totalPages, 'prev_text' => __( '前へ', 'jimmy-pv-monitor' ), 'next_text' => __( '次へ', 'jimmy-pv-monitor' ) ) ) ) . '</div></div>';
	}
}
