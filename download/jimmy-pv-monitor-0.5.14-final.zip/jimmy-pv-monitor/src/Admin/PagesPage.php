<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Reporting\AnalyticsRepository;
use Jimmy\PVMonitor\Reporting\DateRange;
use Jimmy\PVMonitor\Reporting\DateRangeFactory;
use Jimmy\PVMonitor\Settings\SettingsRepository;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET values only filter, sort, and paginate this read-only report.

final class PagesPage {
	private const PER_PAGE_OPTIONS = array( 20, 50, 100, 200 );

	public function __construct(
		private readonly AnalyticsRepository $analytics,
		private readonly DateRangeFactory $dates,
		private readonly SettingsRepository $settings
	) {}

	public function render(): void {
		if ( ! current_user_can( 'jimmy_pv_view_reports' ) ) {
			wp_die( esc_html__( 'このレポートを表示する権限がありません。', 'jimmy-pv-monitor' ) );
		}

		$range     = $this->dates->fromRequest( $_GET );
		$postTypes = get_post_types( array( 'public' => true ), 'objects' );
		unset( $postTypes['attachment'] );
		$postType  = $this->postType( array_keys( $postTypes ) );
		$search    = $this->search();
		$orderBy   = $this->allowedGet( 'orderby', array( 'period_pv', 'total_pv', 'title' ), 'period_pv' );
		$order     = $this->allowedGet( 'order', array( 'asc', 'desc' ), 'desc' );
		$page      = max( 1, $this->integerGet( 'paged', 1 ) );
		$perPage   = $this->integerGet( 'per_page', 50 );
		$perPage   = in_array( $perPage, self::PER_PAGE_OPTIONS, true ) ? $perPage : 50;
		$includeHome = (bool) $this->settings->get( 'track_home', true );
		$report    = $this->analytics->pages( $range, $search, $postType, $orderBy, $order, $page, $perPage, $includeHome );
		$page      = (int) $report['page'];
		$siteTotal = $this->analytics->total( $range );
		?>
		<div class="wrap jimmy-pv-admin">
			<h1><?php esc_html_e( 'ページ別PV', 'jimmy-pv-monitor' ); ?></h1>
			<?php Tabs::render( 'jimmy-pv-pages' ); ?>
			<p><?php esc_html_e( 'ページごとのPV（ページが表示された回数）を確認できます。選択した期間内に1回以上表示されたページだけを掲載します。', 'jimmy-pv-monitor' ); ?> <?php echo esc_html( $includeHome ? __( 'トップページも集計対象です。', 'jimmy-pv-monitor' ) : __( 'トップページの計測は現在オフです。', 'jimmy-pv-monitor' ) ); ?></p>
			<?php $this->renderFilters( $range, $postTypes, $postType, $search, $orderBy, $order, $perPage ); ?>
			<p class="description">
				<?php
				printf(
					/* translators: 1: date range, 2: number of pages */
					esc_html__( '%1$s・該当ページ %2$s件', 'jimmy-pv-monitor' ),
					esc_html( $range->label() ),
					esc_html( number_format_i18n( (int) $report['total'] ) )
				);
				?>
			</p>

			<table class="widefat striped jimmy-pv-report-table">
				<thead><tr>
					<th><?php esc_html_e( 'ページ', 'jimmy-pv-monitor' ); ?></th>
					<th class="jimmy-pv-number"><?php echo wp_kses_post( $this->sortLink( __( '期間PV', 'jimmy-pv-monitor' ), 'period_pv', $orderBy, $order ) ); ?></th>
					<th class="jimmy-pv-number"><?php echo wp_kses_post( $this->sortLink( __( '累計PV', 'jimmy-pv-monitor' ), 'total_pv', $orderBy, $order ) ); ?></th>
					<th class="jimmy-pv-number"><?php esc_html_e( '構成比', 'jimmy-pv-monitor' ); ?></th>
				</tr></thead>
				<tbody>
				<?php if ( array() === $report['rows'] ) : ?>
					<tr><td colspan="4"><?php esc_html_e( 'この期間に表示されたページはありません。', 'jimmy-pv-monitor' ); ?></td></tr>
				<?php else : ?>
					<?php foreach ( $report['rows'] as $row ) : ?>
						<?php
						$isHome = 'home' === (string) $row['object_type'];
						$share = 0 < $siteTotal ? ( (int) $row['period_pv'] / $siteTotal ) * 100 : 0.0;
						?>
						<tr>
							<td>
								<strong><a href="<?php echo esc_url( (string) $row['canonical_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( $isHome ? __( 'トップページ', 'jimmy-pv-monitor' ) : (string) $row['title'] ); ?></a></strong>
								<?php if ( $isHome && '' !== (string) $row['title'] ) : ?><div class="description"><?php echo esc_html( (string) $row['title'] ); ?></div><?php endif; ?>
								<div class="row-actions"><span><?php echo esc_html( (string) $row['canonical_url'] ); ?></span></div>
							</td>
							<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['period_pv'] ) ); ?></td>
							<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( (int) $row['total_pv'] ) ); ?></td>
							<td class="jimmy-pv-number"><?php echo esc_html( number_format_i18n( $share, 1 ) . '%' ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>
			<?php $this->pagination( (int) $report['total'], $page, $perPage ); ?>
		</div>
		<?php
	}

	/** @param array<string, object> $postTypes */
	private function renderFilters(
		DateRange $range,
		array $postTypes,
		string $postType,
		string $search,
		string $orderBy,
		string $order,
		int $perPage
	): void {
		?>
		<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="jimmy-pv-filter-form">
			<input type="hidden" name="page" value="jimmy-pv-pages">
			<label><?php esc_html_e( '期間', 'jimmy-pv-monitor' ); ?>
				<select name="range" data-jimmy-pv-range>
					<?php foreach ( array( 'today' => __( '今日', 'jimmy-pv-monitor' ), '3d' => __( '過去3日（今日を含む）', 'jimmy-pv-monitor' ), '7d' => __( '過去7日', 'jimmy-pv-monitor' ), '30d' => __( '過去30日', 'jimmy-pv-monitor' ), 'custom' => __( '任意期間', 'jimmy-pv-monitor' ) ) as $value => $label ) : ?>
						<option value="<?php echo esc_attr( $value ); ?>" <?php selected( $range->preset, $value ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
			<span class="jimmy-pv-custom-dates" data-jimmy-pv-custom-dates>
				<label><?php esc_html_e( '開始日', 'jimmy-pv-monitor' ); ?> <input type="date" name="from" value="<?php echo esc_attr( $range->fromSql() ); ?>"></label>
				<label><?php esc_html_e( '終了日', 'jimmy-pv-monitor' ); ?> <input type="date" name="to" value="<?php echo esc_attr( $range->toSql() ); ?>"></label>
			</span>
			<label><?php esc_html_e( '投稿タイプ', 'jimmy-pv-monitor' ); ?>
				<select name="post_type"><option value=""><?php esc_html_e( 'すべて', 'jimmy-pv-monitor' ); ?></option>
				<?php foreach ( $postTypes as $slug => $object ) : ?>
					<option value="<?php echo esc_attr( $slug ); ?>" <?php selected( $postType, $slug ); ?>><?php echo esc_html( $object->labels->singular_name ); ?></option>
				<?php endforeach; ?></select>
			</label>
			<label><?php esc_html_e( '検索', 'jimmy-pv-monitor' ); ?> <input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" maxlength="100"></label>
			<label><?php esc_html_e( '表示件数', 'jimmy-pv-monitor' ); ?>
				<select name="per_page"><?php foreach ( self::PER_PAGE_OPTIONS as $option ) : ?><option value="<?php echo esc_attr( (string) $option ); ?>" <?php selected( $perPage, $option ); ?>><?php echo esc_html( (string) $option ); ?></option><?php endforeach; ?></select>
			</label>
			<input type="hidden" name="orderby" value="<?php echo esc_attr( $orderBy ); ?>">
			<input type="hidden" name="order" value="<?php echo esc_attr( $order ); ?>">
			<button type="submit" class="button button-primary"><?php esc_html_e( '絞り込む', 'jimmy-pv-monitor' ); ?></button>
		</form>
		<?php
	}

	private function search(): string {
		$value = isset( $_GET['s'] ) && is_scalar( $_GET['s'] ) ? sanitize_text_field( wp_unslash( (string) $_GET['s'] ) ) : '';

		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, 100 ) : substr( $value, 0, 100 );
	}

	/** @param string[] $allowed */
	private function postType( array $allowed ): string {
		$value = $this->allowedGet( 'post_type', $allowed, '' );

		return 'attachment' === $value ? '' : $value;
	}

	/** @param string[] $allowed */
	private function allowedGet( string $key, array $allowed, string $fallback ): string {
		$value = isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] ) ? sanitize_key( wp_unslash( (string) $_GET[ $key ] ) ) : '';

		return in_array( $value, $allowed, true ) ? $value : $fallback;
	}

	private function integerGet( string $key, int $fallback ): int {
		return isset( $_GET[ $key ] ) && is_scalar( $_GET[ $key ] )
			? absint( wp_unslash( (string) $_GET[ $key ] ) )
			: $fallback;
	}

	private function sortLink( string $label, string $column, string $currentColumn, string $currentOrder ): string {
		$order = $column === $currentColumn && 'desc' === $currentOrder ? 'asc' : 'desc';
		$url   = add_query_arg( array( 'orderby' => $column, 'order' => $order, 'paged' => false ) );

		return sprintf( '<a href="%1$s">%2$s</a>', esc_url( $url ), esc_html( $label ) );
	}

	private function pagination( int $total, int $page, int $perPage ): void {
		$totalPages = (int) ceil( $total / $perPage );
		if ( 1 >= $totalPages ) {
			return;
		}

		$base = str_replace( '999999999', '%#%', add_query_arg( 'paged', 999999999 ) );
		echo '<div class="tablenav"><div class="tablenav-pages">';
		echo wp_kses_post(
			paginate_links(
				array(
					'base'      => $base,
					'format'    => '',
					'current'   => $page,
					'total'     => $totalPages,
					'prev_text' => __( '前へ', 'jimmy-pv-monitor' ),
					'next_text' => __( '次へ', 'jimmy-pv-monitor' ),
				)
			)
		);
		echo '</div></div>';
	}
}
