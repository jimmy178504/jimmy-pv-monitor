<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Reporting\DateRangeFactory;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- GET values only filter this read-only export form.

final class ExportPage {
	public function __construct( private readonly DateRangeFactory $dates ) {}

	public function render(): void {
		if ( ! current_user_can( 'jimmy_pv_export_data' ) ) {
			wp_die( esc_html__( 'CSVを出力する権限がありません。', 'jimmy-pv-monitor' ) );
		}

		$range = $this->dates->fromRequest( $_GET );
		?>
		<div class="wrap jimmy-pv-admin">
			<h1><?php esc_html_e( 'CSV出力', 'jimmy-pv-monitor' ); ?></h1>
			<?php Tabs::render( 'jimmy-pv-export' ); ?>
			<p><?php esc_html_e( 'PV（ページが表示された回数）や流入元などの集計結果を、表計算ソフトで開けるCSVファイルとして保存できます。', 'jimmy-pv-monitor' ); ?></p>
			<p class="description"><?php esc_html_e( '日本語が文字化けしにくく、タイトルやURLが表計算ソフトで誤って計算式として扱われない形式で保存します。', 'jimmy-pv-monitor' ); ?></p>
			<div class="jimmy-pv-cards">
				<?php $this->form( 'daily', __( '日別PV', 'jimmy-pv-monitor' ), __( '日付ごとのサイト全体PVを出力します。', 'jimmy-pv-monitor' ), $range->fromSql(), $range->toSql() ); ?>
				<?php $this->form( 'pages', __( 'ページ別PV', 'jimmy-pv-monitor' ), __( '期間内に1回以上表示された公開ページを出力します。トップページを計測中の場合はトップページも含みます。', 'jimmy-pv-monitor' ), $range->fromSql(), $range->toSql() ); ?>
				<?php $this->form( 'referrers', __( '流入元別PV', 'jimmy-pv-monitor' ), __( '日別の分類、完全な参照元URL、最初に見られたページ、PVを出力します。', 'jimmy-pv-monitor' ), $range->fromSql(), $range->toSql() ); ?>
				<?php $this->form( 'campaigns', __( 'UTM・広告PV', 'jimmy-pv-monitor' ), __( '広告やSNS投稿などに付けた識別情報、広告サービス名、最初に見られたページ、PVを出力します。', 'jimmy-pv-monitor' ), $range->fromSql(), $range->toSql() ); ?>
				<?php $this->form( 'clicks', __( 'クリック計測', 'jimmy-pv-monitor' ), __( 'クリックされたサイト内・外部リンク、リンクがあるページ、クリック総数、ページのPV、PVに対するクリック率を出力します。', 'jimmy-pv-monitor' ), $range->fromSql(), $range->toSql() ); ?>
			</div>
		</div>
		<?php
	}

	private function form( string $report, string $title, string $description, string $from, string $to ): void {
		?>
		<section class="jimmy-pv-card">
			<h2><?php echo esc_html( $title ); ?></h2>
			<p><?php echo esc_html( $description ); ?></p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="jimmy_pv_export">
				<input type="hidden" name="report" value="<?php echo esc_attr( $report ); ?>">
				<?php wp_nonce_field( 'jimmy_pv_export', 'jimmy_pv_nonce' ); ?>
				<p><label><?php esc_html_e( '開始日', 'jimmy-pv-monitor' ); ?><br><input type="date" name="from" value="<?php echo esc_attr( $from ); ?>" required></label></p>
				<p><label><?php esc_html_e( '終了日', 'jimmy-pv-monitor' ); ?><br><input type="date" name="to" value="<?php echo esc_attr( $to ); ?>" required></label></p>
				<button type="submit" class="button button-primary"><?php esc_html_e( 'CSVをダウンロード', 'jimmy-pv-monitor' ); ?></button>
			</form>
		</section>
		<?php
	}
}
