<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Maintenance\Scheduler;
use Jimmy\PVMonitor\Settings\SettingsRepository;
use WP_Error;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.Security.NonceVerification.Recommended -- The GET status value only selects a read-only admin notice.

final class SettingsPage {
	private const BOOLEAN_KEYS = array(
		'tracking_enabled',
		'track_home',
		'track_archives',
		'track_search',
		'track_404',
		'exclude_empty_user_agent',
		'distinguish_query_strings',
		'referrer_enabled',
		'dashboard_widget_enabled',
		'delete_data_on_uninstall',
	);

	public function __construct(
		private readonly SettingsRepository $settings,
		private readonly DataResetter $resetter
	) {}

	public function register(): void {
		add_action( 'admin_post_jimmy_pv_save_settings', array( $this, 'save' ) );
		add_action( 'admin_post_jimmy_pv_delete_data', array( $this, 'deleteData' ) );
	}

	public function render(): void {
		if ( ! current_user_can( 'jimmy_pv_manage_settings' ) ) {
			wp_die( esc_html__( '設定を変更する権限がありません。', 'jimmy-pv-monitor' ) );
		}

		$settings  = $this->settings->all();
		$postTypes = get_post_types( array( 'public' => true ), 'objects' );
		$roles     = wp_roles()->roles;
		$status    = isset( $_GET['jimmy_pv_status'] ) && is_scalar( $_GET['jimmy_pv_status'] )
			? sanitize_key( wp_unslash( (string) $_GET['jimmy_pv_status'] ) )
			: '';
		?>
		<div class="wrap jimmy-pv-admin">
			<h1><?php esc_html_e( '設定', 'jimmy-pv-monitor' ); ?></h1>
			<?php Tabs::render( 'jimmy-pv-settings' ); ?>
			<p><?php esc_html_e( 'PV（ページが表示された回数）を計測するページ、データの保存期間、公開用ショートコードなど、Jimmy PV Monitorの動作を設定します。', 'jimmy-pv-monitor' ); ?></p>
			<?php $this->statusNotice( $status ); ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="jimmy_pv_save_settings">
				<?php wp_nonce_field( 'jimmy_pv_save_settings', 'jimmy_pv_nonce' ); ?>

				<h2><?php esc_html_e( '計測', 'jimmy-pv-monitor' ); ?></h2>
				<table class="form-table" role="presentation"><tbody>
					<?php $this->checkboxRow( $settings, 'tracking_enabled', __( 'PV計測を有効にする', 'jimmy-pv-monitor' ), __( 'オフにすると新しいPVの収集を停止します。保存済みデータは残ります。', 'jimmy-pv-monitor' ) ); ?>
					<tr><th scope="row"><?php esc_html_e( '投稿タイプの扱い', 'jimmy-pv-monitor' ); ?></th><td>
						<select name="settings[post_type_mode]">
							<option value="all_public" <?php selected( $settings['post_type_mode'], 'all_public' ); ?>><?php esc_html_e( '公開投稿タイプをすべて計測', 'jimmy-pv-monitor' ); ?></option>
							<option value="selected" <?php selected( $settings['post_type_mode'], 'selected' ); ?>><?php esc_html_e( '選択した投稿タイプだけ計測', 'jimmy-pv-monitor' ); ?></option>
						</select>
						<p class="description"><?php esc_html_e( '通常のブログでは「公開投稿タイプをすべて計測」がおすすめです。特定の記事種類だけを計測したい場合は「選択した投稿タイプだけ計測」を選び、下の項目にチェックを付けます。', 'jimmy-pv-monitor' ); ?></p>
						<fieldset><legend class="screen-reader-text"><?php esc_html_e( '計測する投稿タイプ', 'jimmy-pv-monitor' ); ?></legend>
						<?php foreach ( $postTypes as $slug => $object ) : ?>
							<label><input type="checkbox" name="settings[included_post_types][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, (array) $settings['included_post_types'], true ) ); ?>> <?php echo esc_html( $object->labels->singular_name ); ?></label><br>
						<?php endforeach; ?>
						</fieldset>
					</td></tr>
					<tr><th scope="row"><?php esc_html_e( '除外する投稿タイプ', 'jimmy-pv-monitor' ); ?></th><td><fieldset>
						<?php foreach ( $postTypes as $slug => $object ) : ?>
							<label><input type="checkbox" name="settings[excluded_post_types][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, (array) $settings['excluded_post_types'], true ) ); ?>> <?php echo esc_html( $object->labels->singular_name ); ?></label><br>
						<?php endforeach; ?>
					</fieldset><p class="description"><?php esc_html_e( 'ここでチェックした記事種類は、上の設定で選ばれていても計測しません。添付ファイルは通常そのまま除外するのがおすすめです。', 'jimmy-pv-monitor' ); ?></p></td></tr>
					<?php $this->checkboxRow( $settings, 'track_home', __( 'トップページを計測', 'jimmy-pv-monitor' ), __( 'オンにするとトップページのPVを記録し、ページ別PVにも表示します。ブログ全体の入口を確認したい場合はオンがおすすめです。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->checkboxRow( $settings, 'track_archives', __( 'アーカイブを計測', 'jimmy-pv-monitor' ), __( 'カテゴリー、タグ、月別一覧などの記事一覧ページを計測します。一覧ページの利用状況も確認したい場合にオンにします。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->checkboxRow( $settings, 'track_search', __( 'サイト内検索結果を計測', 'jimmy-pv-monitor' ), __( '読者がブログ内検索を使ったときの検索結果ページを計測します。検索機能があるブログではオンがおすすめです。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->checkboxRow( $settings, 'track_404', __( '404ページを計測', 'jimmy-pv-monitor' ), __( '存在しないURLが表示された回数を計測します。通常のPVと混ぜたくない場合はオフのままにしてください。初期設定はオフです。', 'jimmy-pv-monitor' ) ); ?>
				</tbody></table>

				<h2><?php esc_html_e( '除外条件', 'jimmy-pv-monitor' ); ?></h2>
				<table class="form-table" role="presentation"><tbody>
					<tr><th scope="row"><?php esc_html_e( '除外するログイン権限', 'jimmy-pv-monitor' ); ?></th><td><fieldset>
						<?php foreach ( $roles as $slug => $role ) : ?>
							<label><input type="checkbox" name="settings[excluded_roles][]" value="<?php echo esc_attr( $slug ); ?>" <?php checked( in_array( $slug, (array) $settings['excluded_roles'], true ) ); ?>> <?php echo esc_html( translate_user_role( (string) ( $role['name'] ?? $slug ) ) ); ?></label><br>
						<?php endforeach; ?>
					</fieldset><p class="description"><?php esc_html_e( 'チェックした権限でログイン中の人はPVに数えません。自分の確認操作を除くため、管理者は除外したままがおすすめです。', 'jimmy-pv-monitor' ); ?></p></td></tr>
					<?php $this->checkboxRow( $settings, 'exclude_empty_user_agent', __( 'ブラウザー情報が空のアクセスを除外', 'jimmy-pv-monitor' ), __( '通常のブラウザーには種類を示す情報があります。空のアクセスは自動巡回の可能性が高いため、オンがおすすめです。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->textareaRow( 'custom_bot_patterns', __( '独自ボット除外文字列', 'jimmy-pv-monitor' ), (array) $settings['custom_bot_patterns'], __( '1行に1件。User-Agentに含まれる文字列を大文字小文字を区別せず照合します。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->textRow( 'excluded_post_ids', __( '除外する投稿ID', 'jimmy-pv-monitor' ), implode( ',', (array) $settings['excluded_post_ids'] ), __( 'カンマ区切りで入力します。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->textareaRow( 'excluded_url_patterns', __( '除外URLパターン', 'jimmy-pv-monitor' ), (array) $settings['excluded_url_patterns'], __( '1行に1件。ワイルドカードとして*を使用できます。', 'jimmy-pv-monitor' ) ); ?>
				</tbody></table>

				<h2><?php esc_html_e( '保存と表示', 'jimmy-pv-monitor' ); ?></h2>
				<table class="form-table" role="presentation"><tbody>
					<?php $this->checkboxRow( $settings, 'distinguish_query_strings', __( 'URLの「?」以降が違う場合に別ページとして扱う', 'jimmy-pv-monitor' ), __( '「?」以降には検索語などが含まれる場合があります。保存が必要な場合だけ有効にしてください。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->checkboxRow( $settings, 'referrer_enabled', __( '参照元URL（リファラー）を保存する', 'jimmy-pv-monitor' ), __( '読者がどこから訪れたかを示すURLです。オフにすると新しい流入元の記録を停止しますが、UTM・広告集計は継続します。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->textareaRow( 'sensitive_query_keys', __( 'URLから保存しない項目', 'jimmy-pv-monitor' ), (array) $settings['sensitive_query_keys'], __( 'URLの「?」以降にある項目名を1行に1件入力します。ページURLと参照元URLを保存するとき、該当する項目を削除します。', 'jimmy-pv-monitor' ) ); ?>
					<tr><th scope="row"><label for="jimmy-pv-retention"><?php esc_html_e( '日別データ保存日数', 'jimmy-pv-monitor' ); ?></label></th><td><input id="jimmy-pv-retention" type="number" name="settings[retention_days]" value="<?php echo esc_attr( (string) $settings['retention_days'] ); ?>" min="30" max="3650"> <span><?php esc_html_e( '日', 'jimmy-pv-monitor' ); ?></span><p class="description"><?php esc_html_e( '初期値365日。累計PVは期限後も維持されます。', 'jimmy-pv-monitor' ); ?></p></td></tr>
					<?php $this->textRow( 'shortcode_format', __( 'ショートコード標準文言', 'jimmy-pv-monitor' ), (string) $settings['shortcode_format'], __( '{count}、{count_raw}、{title}を使用できます。HTMLは使用できません。', 'jimmy-pv-monitor' ) ); ?>
					<tr><th scope="row"><label for="jimmy-pv-shortcode-min"><?php esc_html_e( '最低表示PV数', 'jimmy-pv-monitor' ); ?></label></th><td><input id="jimmy-pv-shortcode-min" type="number" name="settings[shortcode_min]" value="<?php echo esc_attr( (string) $settings['shortcode_min'] ); ?>" min="0"><p class="description"><?php esc_html_e( '0の場合は1PV以上で表示します。', 'jimmy-pv-monitor' ); ?></p></td></tr>
					<?php $this->checkboxRow( $settings, 'dashboard_widget_enabled', __( 'WordPressダッシュボードウィジェットを表示', 'jimmy-pv-monitor' ), __( 'オンにするとWordPressへログインした直後のダッシュボードに、今日・昨日・7日間・今月のPVと今日の人気記事を表示します。', 'jimmy-pv-monitor' ) ); ?>
					<?php $this->checkboxRow( $settings, 'delete_data_on_uninstall', __( 'アンインストール時に全データを削除', 'jimmy-pv-monitor' ), __( 'オンにしてプラグインを削除すると、PVや流入元などの解析データも完全に削除され、元に戻せません。通常はオフがおすすめです。無効化だけでは削除されません。', 'jimmy-pv-monitor' ) ); ?>
				</tbody></table>

				<?php submit_button( __( '設定を保存', 'jimmy-pv-monitor' ) ); ?>
			</form>

			<h2><?php esc_html_e( '状態', 'jimmy-pv-monitor' ); ?></h2>
			<div class="jimmy-pv-panel">
				<p><?php esc_html_e( '解析データはこのWordPressのデータベース内だけに保存されます。無料版は外部サーバーへ解析データやテレメトリーを送信しません。', 'jimmy-pv-monitor' ); ?></p>
				<p>
					<strong><?php esc_html_e( '集計タイムゾーン:', 'jimmy-pv-monitor' ); ?></strong>
					<?php echo esc_html( wp_timezone_string() ); ?>
					<span class="description"><?php esc_html_e( '変更すると、変更前後で日付境界が異なる場合があります。', 'jimmy-pv-monitor' ); ?></span>
				</p>
				<?php $this->cronStatus(); ?>
			</div>

			<?php if ( current_user_can( 'jimmy_pv_delete_data' ) ) : ?>
				<h2><?php esc_html_e( '解析データの全削除', 'jimmy-pv-monitor' ); ?></h2>
				<div class="jimmy-pv-danger-zone">
					<p><?php esc_html_e( '累計PV、日別PV、流入・キャンペーン・リンククリック記録を含むすべてのJimmy PV解析データを削除します。設定は残ります。この操作は元に戻せません。', 'jimmy-pv-monitor' ); ?></p>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="jimmy_pv_delete_data">
						<?php wp_nonce_field( 'jimmy_pv_delete_data', 'jimmy_pv_nonce' ); ?>
						<label><?php esc_html_e( '確認のため DELETE と入力', 'jimmy-pv-monitor' ); ?> <input type="text" name="confirmation" autocomplete="off" required pattern="DELETE"></label>
						<?php submit_button( __( '解析データを完全に削除', 'jimmy-pv-monitor' ), 'delete', 'submit', false ); ?>
					</form>
				</div>
			<?php endif; ?>
		</div>
		<?php
	}

	public function save(): void {
		if ( ! current_user_can( 'jimmy_pv_manage_settings' ) ) {
			wp_die( esc_html__( '設定を変更する権限がありません。', 'jimmy-pv-monitor' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'jimmy_pv_save_settings', 'jimmy_pv_nonce' );

			// Values are unslashed here and sanitized by the typed helpers below before persistence.
			// phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$raw = isset( $_POST['settings'] ) && is_array( $_POST['settings'] ) ? wp_unslash( $_POST['settings'] ) : array();
		$candidate = array();
		foreach ( self::BOOLEAN_KEYS as $key ) {
			$candidate[ $key ] = isset( $raw[ $key ] );
		}

		$candidate['post_type_mode']       = $this->scalar( $raw, 'post_type_mode' );
		$candidate['included_post_types']  = $this->arrayValues( $raw, 'included_post_types' );
		$candidate['excluded_post_types']  = $this->arrayValues( $raw, 'excluded_post_types' );
		$candidate['excluded_roles']       = $this->arrayValues( $raw, 'excluded_roles' );
		$candidate['custom_bot_patterns']  = $this->lines( $raw, 'custom_bot_patterns' );
		$candidate['excluded_url_patterns'] = $this->lines( $raw, 'excluded_url_patterns' );
		$candidate['sensitive_query_keys'] = $this->lines( $raw, 'sensitive_query_keys' );
		$excluded_post_ids                 = preg_split( '/[\s,]+/', $this->scalar( $raw, 'excluded_post_ids' ), -1, PREG_SPLIT_NO_EMPTY );
		$candidate['excluded_post_ids']    = is_array( $excluded_post_ids ) ? $excluded_post_ids : array();
		$candidate['retention_days']       = $this->scalar( $raw, 'retention_days' );
		$candidate['shortcode_format']     = $this->scalar( $raw, 'shortcode_format' );
		$candidate['shortcode_min']        = $this->scalar( $raw, 'shortcode_min' );

		$success = $this->settings->update( $candidate );
		if ( $success ) {
			$this->incrementCacheGeneration();
		}
		$this->redirect( $success ? 'saved' : 'save-error' );
	}

	public function deleteData(): void {
		if ( ! current_user_can( 'jimmy_pv_delete_data' ) ) {
			wp_die( esc_html__( '解析データを削除する権限がありません。', 'jimmy-pv-monitor' ), '', array( 'response' => 403 ) );
		}
		check_admin_referer( 'jimmy_pv_delete_data', 'jimmy_pv_nonce' );

		$confirmation = isset( $_POST['confirmation'] ) && is_scalar( $_POST['confirmation'] )
			? sanitize_text_field( wp_unslash( (string) $_POST['confirmation'] ) )
			: '';
		if ( 'DELETE' !== $confirmation ) {
			$this->redirect( 'confirmation-error' );
		}

		$result = $this->resetter->reset();
		$this->redirect( $result instanceof WP_Error ? 'delete-error' : 'deleted' );
	}

	/** @param array<string, mixed> $settings */
	private function checkboxRow( array $settings, string $key, string $label, string $description = '' ): void {
		?>
		<tr><th scope="row"><?php echo esc_html( $label ); ?></th><td>
			<label><input type="checkbox" name="settings[<?php echo esc_attr( $key ); ?>]" value="1" <?php checked( (bool) $settings[ $key ] ); ?>> <?php echo esc_html( $label ); ?></label>
			<?php if ( '' !== $description ) : ?><p class="description"><?php echo esc_html( $description ); ?></p><?php endif; ?>
		</td></tr>
		<?php
	}

	/** @param string[] $values */
	private function textareaRow( string $key, string $label, array $values, string $description ): void {
		?>
		<tr><th scope="row"><label for="jimmy-pv-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th><td>
			<textarea id="jimmy-pv-<?php echo esc_attr( $key ); ?>" name="settings[<?php echo esc_attr( $key ); ?>]" rows="5" class="large-text code"><?php echo esc_textarea( implode( "\n", $values ) ); ?></textarea>
			<p class="description"><?php echo esc_html( $description ); ?></p>
		</td></tr>
		<?php
	}

	private function textRow( string $key, string $label, string $value, string $description ): void {
		?>
		<tr><th scope="row"><label for="jimmy-pv-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></label></th><td>
			<input id="jimmy-pv-<?php echo esc_attr( $key ); ?>" type="text" name="settings[<?php echo esc_attr( $key ); ?>]" value="<?php echo esc_attr( $value ); ?>" class="regular-text">
			<p class="description"><?php echo esc_html( $description ); ?></p>
		</td></tr>
		<?php
	}

	private function statusNotice( string $status ): void {
		$messages = array(
			'saved'              => array( 'success', __( '設定を保存しました。', 'jimmy-pv-monitor' ) ),
			'save-error'         => array( 'error', __( '設定を保存できませんでした。', 'jimmy-pv-monitor' ) ),
			'deleted'            => array( 'success', __( 'Jimmy PVの解析データをすべて削除しました。', 'jimmy-pv-monitor' ) ),
			'delete-error'       => array( 'error', __( '解析データを完全に削除できませんでした。データベース状態を確認してください。', 'jimmy-pv-monitor' ) ),
			'confirmation-error' => array( 'error', __( '確認文字列が一致しないため削除しませんでした。', 'jimmy-pv-monitor' ) ),
		);
		if ( ! isset( $messages[ $status ] ) ) {
			return;
		}

		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $messages[ $status ][0] ),
			esc_html( $messages[ $status ][1] )
		);
	}

	private function cronStatus(): void {
		$next = wp_next_scheduled( Scheduler::DAILY_HOOK );
		if ( false === $next ) {
			echo '<p><strong>' . esc_html__( '日次保守:', 'jimmy-pv-monitor' ) . '</strong> ' . esc_html__( '未予約', 'jimmy-pv-monitor' ) . '</p>';

			return;
		}

		printf(
			'<p><strong>%1$s</strong> %2$s</p>',
			esc_html__( '次回の日次保守:', 'jimmy-pv-monitor' ),
			esc_html( wp_date( 'Y年n月j日 H:i:s', $next, wp_timezone() ) )
		);
	}

	/** @param array<string, mixed> $raw */
	private function scalar( array $raw, string $key ): string {
		return isset( $raw[ $key ] ) && is_scalar( $raw[ $key ] ) ? (string) $raw[ $key ] : '';
	}

	/** @param array<string, mixed> $raw
	 *  @return array<int, mixed>
	 */
	private function arrayValues( array $raw, string $key ): array {
		if ( ! isset( $raw[ $key ] ) || ! is_array( $raw[ $key ] ) ) {
			return array();
		}

		return array_values( array_filter( $raw[ $key ], 'is_scalar' ) );
	}

	/** @param array<string, mixed> $raw
	 *  @return string[]
	 */
	private function lines( array $raw, string $key ): array {
		$lines = preg_split( '/\R/u', $this->scalar( $raw, $key ), -1, PREG_SPLIT_NO_EMPTY );

		return is_array( $lines ) ? $lines : array();
	}

	private function redirect( string $status ): never {
		$url = add_query_arg(
			array( 'page' => 'jimmy-pv-settings', 'jimmy_pv_status' => $status ),
			admin_url( 'admin.php' )
		);
		wp_safe_redirect( $url );
		exit;
	}

	private function incrementCacheGeneration(): void {
		$generation = (int) get_option( 'jimmy_pv_report_cache_generation', 1 );
		update_option( 'jimmy_pv_report_cache_generation', $generation + 1, false );
	}
}
