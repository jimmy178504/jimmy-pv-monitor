<?php

namespace Jimmy\PVMonitor\Admin;

defined( 'ABSPATH' ) || exit;

final class CsvSanitizer {
	public function cell( mixed $value ): string {
		if ( is_bool( $value ) ) {
			$value = $value ? '1' : '0';
		} elseif ( null === $value ) {
			$value = '';
		} elseif ( ! is_scalar( $value ) ) {
			$value = wp_json_encode( $value );
		}

		$value = str_replace( "\0", '', (string) $value );
		if ( 1 === preg_match( '/^[\x20\t\r\n]*[=+\-@]/u', $value ) || 1 === preg_match( '/^[\t\r\n]/u', $value ) ) {
			$value = "'" . $value;
		}

		return $value;
	}
}
