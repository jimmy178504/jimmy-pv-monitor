<?php

namespace Jimmy\PVMonitor\Admin;

use Jimmy\PVMonitor\Reporting\AnalyticsRepository;
use Jimmy\PVMonitor\Reporting\DateRangeFactory;
use Jimmy\PVMonitor\Settings\SettingsRepository;

defined( 'ABSPATH' ) || exit;

final class DashboardWidget {
	public function __construct(
		private readonly AnalyticsRepository $analytics,
		private readonly DateRangeFactory $dates,
		private readonly SettingsRepository $settings
	) {}

	public function register(): void {
		add_action( 'wp_dashboard_setup', array( $this, 'add' ) );
	}

	public function add(): void {
		if ( ! current_user_can( 'jimmy_pv_view_reports' ) || ! (bool) $this->settings->get( 'dashboard_widget_enabled', true ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'jimmy_pv_summary',
			__( 'Jimmy PV サマリー', 'jimmy-pv-monitor' ),
			array( $this, 'render' )
		);
	}

	public function render(): void {
		$todayRange = $this->dates->preset( 'today' );
		$today     = $this->analytics->total( $todayRange );
		$yesterday = $this->analytics->total( $this->dates->preset( 'yesterday' ) );
		$weekRange = $this->dates->preset( '7d' );
		$week      = $this->analytics->total( $weekRange );
		$monthRange = $this->dates->fromRequest(
			array(
				'range' => 'custom',
				'from'  => wp_date( 'Y-m-01', null, wp_timezone() ),
				'to'    => wp_date( 'Y-m-d', null, wp_timezone() ),
			),
			false
		);
		$month     = $this->analytics->total( $monthRange );
		$topPages  = $this->analytics->topPages( $todayRange, 10 );
		?>
		<div class="jimmy-pv-widget-metrics">
			<p><strong><?php esc_html_e( '今日', 'jimmy-pv-monitor' ); ?></strong><br><?php echo esc_html( number_format_i18n( $today ) ); ?> PV</p>
			<p><strong><?php esc_html_e( '昨日', 'jimmy-pv-monitor' ); ?></strong><br><?php echo esc_html( number_format_i18n( $yesterday ) ); ?> PV</p>
			<p><strong><?php esc_html_e( '過去7日', 'jimmy-pv-monitor' ); ?></strong><br><?php echo esc_html( number_format_i18n( $week ) ); ?> PV</p>
			<p><strong><?php esc_html_e( '今月', 'jimmy-pv-monitor' ); ?></strong><br><?php echo esc_html( number_format_i18n( $month ) ); ?> PV</p>
		</div>
		<h3><?php esc_html_e( '今日の人気記事（上位10件）', 'jimmy-pv-monitor' ); ?></h3>
		<?php if ( array() === $topPages ) : ?>
			<p><?php esc_html_e( '今日のPVデータはまだありません。', 'jimmy-pv-monitor' ); ?></p>
		<?php else : ?>
			<ol>
			<?php foreach ( $topPages as $row ) : ?>
				<li><a href="<?php echo esc_url( (string) $row['canonical_url'] ); ?>" target="_blank" rel="noopener noreferrer"><?php echo esc_html( (string) $row['title'] ); ?></a> — <?php echo esc_html( number_format_i18n( (int) $row['period_pv'] ) ); ?> PV</li>
			<?php endforeach; ?>
			</ol>
		<?php endif; ?>
		<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=jimmy-pv' ) ); ?>"><?php esc_html_e( '詳細レポートを見る', 'jimmy-pv-monitor' ); ?></a></p>
		<?php
	}
}
