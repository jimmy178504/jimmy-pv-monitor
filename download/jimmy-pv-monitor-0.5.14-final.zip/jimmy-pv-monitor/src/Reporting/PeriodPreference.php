<?php

namespace Jimmy\PVMonitor\Reporting;

defined( 'ABSPATH' ) || exit;

final class PeriodPreference {
	private const USER_META_KEY = 'jimmy_pv_report_period';

	/** @param array<string, mixed> $source
	 *  @return array<string, mixed>
	 */
	public static function apply( array $source ): array {
		if ( isset( $source['range'] ) && is_scalar( $source['range'] ) ) {
			return $source;
		}

		$userId = get_current_user_id();
		if ( 0 >= $userId ) {
			return $source;
		}

		$saved = get_user_meta( $userId, self::USER_META_KEY, true );
		if ( ! is_array( $saved ) || ! isset( $saved['range'] ) ) {
			return $source;
		}

		return array_merge( $saved, $source );
	}

	public static function remember( DateRange $range ): void {
		$userId = get_current_user_id();
		if ( 0 >= $userId ) {
			return;
		}

		update_user_meta(
			$userId,
			self::USER_META_KEY,
			array(
				'range' => $range->preset,
				'from'  => $range->fromSql(),
				'to'    => $range->toSql(),
			)
		);
	}
}
