<?php

namespace Jimmy\PVMonitor\Reporting;

use DateTimeImmutable;
use Jimmy\PVMonitor\Settings\SettingsRepository;

defined( 'ABSPATH' ) || exit;

final class DateRangeFactory {
	private const PRESETS = array( 'today', '3d', '7d', '30d', 'custom' );

	public function __construct( private readonly SettingsRepository $settings ) {}

	/** @param array<string, mixed> $source */
	public function fromRequest( array $source, bool $remember = true ): DateRange {
		$explicit = isset( $source['range'] ) && is_scalar( $source['range'] );
		$source   = PeriodPreference::apply( $source );
		$preset = isset( $source['range'] ) && is_scalar( $source['range'] )
			? sanitize_key( wp_unslash( (string) $source['range'] ) )
			: 'today';
		$preset = in_array( $preset, self::PRESETS, true ) ? $preset : 'today';

		if ( 'custom' === $preset ) {
			$from = $this->parseDate( $source['from'] ?? '' );
			$to   = $this->parseDate( $source['to'] ?? '' );
			if ( null !== $from && null !== $to ) {
				$range = $this->clamp( $from, $to, 'custom' );
				if ( $remember && $explicit ) {
					PeriodPreference::remember( $range );
				}

				return $range;
			}
			$preset = 'today';
		}

		$range = $this->preset( $preset );
		if ( $remember && $explicit ) {
			PeriodPreference::remember( $range );
		}

		return $range;
	}

	public function preset( string $preset ): DateRange {
		$today = new DateTimeImmutable( 'today', wp_timezone() );

		return match ( $preset ) {
			'today'     => $this->clamp( $today, $today, 'today' ),
			'yesterday' => $this->clamp( $today->modify( '-1 day' ), $today->modify( '-1 day' ), 'yesterday' ),
			'3d'        => $this->clamp( $today->modify( '-2 days' ), $today, '3d' ),
			'7d'        => $this->clamp( $today->modify( '-6 days' ), $today, '7d' ),
			default     => $this->clamp( $today->modify( '-29 days' ), $today, '30d' ),
		};
	}

	private function clamp( DateTimeImmutable $from, DateTimeImmutable $to, string $preset ): DateRange {
		$today         = new DateTimeImmutable( 'today', wp_timezone() );
		$retentionDays = max( 30, (int) $this->settings->get( 'retention_days', 365 ) );
		$earliest      = $today->modify( '-' . ( $retentionDays - 1 ) . ' days' );
		$from          = $from < $earliest ? $earliest : $from;
		$to            = $to > $today ? $today : $to;

		if ( $from > $to ) {
			return new DateRange( $today, $today, 'today' );
		}

		return new DateRange( $from, $to, $preset );
	}

	private function parseDate( mixed $value ): ?DateTimeImmutable {
		if ( ! is_scalar( $value ) ) {
			return null;
		}

		$value = trim( wp_unslash( (string) $value ) );
		if ( 1 !== preg_match( '/^\d{4}-\d{2}-\d{2}$/D', $value ) ) {
			return null;
		}

		$date   = DateTimeImmutable::createFromFormat( '!Y-m-d', $value, wp_timezone() );
		$errors = DateTimeImmutable::getLastErrors();
		if ( false === $date || ( is_array( $errors ) && ( 0 < $errors['warning_count'] || 0 < $errors['error_count'] ) ) ) {
			return null;
		}

		return $date;
	}
}
