<?php

namespace Jimmy\PVMonitor\Reporting;

use DateInterval;
use DatePeriod;
use DateTimeImmutable;

defined( 'ABSPATH' ) || exit;

final class DateRange {
	public function __construct(
		public readonly DateTimeImmutable $from,
		public readonly DateTimeImmutable $to,
		public readonly string $preset
	) {}

	public function fromSql(): string {
		return $this->from->format( 'Y-m-d' );
	}

	public function toSql(): string {
		return $this->to->format( 'Y-m-d' );
	}

	public function days(): int {
		return (int) $this->from->diff( $this->to )->days + 1;
	}

	public function previous(): self {
		$previousTo   = $this->from->modify( '-1 day' );
		$previousFrom = $previousTo->modify( '-' . max( 0, $this->days() - 1 ) . ' days' );

		return new self( $previousFrom, $previousTo, 'previous' );
	}

	/** @return string[] */
	public function dates(): array {
		$period = new DatePeriod( $this->from, new DateInterval( 'P1D' ), $this->to->modify( '+1 day' ) );
		$dates  = array();
		foreach ( $period as $date ) {
			$dates[] = $date->format( 'Y-m-d' );
		}

		return $dates;
	}

	public function label(): string {
		if ( $this->fromSql() === $this->toSql() ) {
			return wp_date( 'Y年n月j日', $this->from->getTimestamp(), $this->from->getTimezone() );
		}

		return sprintf(
			/* translators: 1: start date, 2: end date */
			__( '%1$s〜%2$s', 'jimmy-pv-monitor' ),
			wp_date( 'Y年n月j日', $this->from->getTimestamp(), $this->from->getTimezone() ),
			wp_date( 'Y年n月j日', $this->to->getTimestamp(), $this->to->getTimezone() )
		);
	}
}
