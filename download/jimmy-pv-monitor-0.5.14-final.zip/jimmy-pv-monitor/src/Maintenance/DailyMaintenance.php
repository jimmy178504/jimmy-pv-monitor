<?php

namespace Jimmy\PVMonitor\Maintenance;

use DateTimeImmutable;
use Jimmy\PVMonitor\Database\TableNames;
use Jimmy\PVMonitor\Settings\SettingsRepository;
use RuntimeException;
use Throwable;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,WordPress.DB.PreparedSQLPlaceholders.UnfinishedPrepare,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Values and ID lists are prepared; identifiers come from TableNames or a strict allow-pattern.

final class DailyMaintenance {
	private const DELETE_LIMIT       = 5000;
	private const PAGE_DELETE_LIMIT  = 200;
	private const MAX_RUNTIME_SECONDS = 20.0;

	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables,
		private readonly SettingsRepository $settings,
		private readonly OptionLock $lock
	) {}

	public function run(): void {
		if ( ! $this->lock->acquire() ) {
			return;
		}

		$startedAt = microtime( true );
		$hasMore   = false;

		try {
			$retentionDays = (int) $this->settings->get( 'retention_days', 365 );
			$cutoffDate    = ( new DateTimeImmutable( 'today', wp_timezone() ) )
				->modify( '-' . max( 0, $retentionDays - 1 ) . ' days' )
				->format( 'Y-m-d' );

			$hasMore = $this->deleteExpiredEvents() || $hasMore;
			$hasMore = $this->deleteDateRows( $this->tables->daily(), $cutoffDate ) || $hasMore;
			$hasMore = $this->deleteDateRows( $this->tables->referrerDaily(), $cutoffDate ) || $hasMore;
			$hasMore = $this->deleteDateRows( $this->tables->campaignDaily(), $cutoffDate ) || $hasMore;
			$hasMore = $this->deleteDateRows( $this->tables->internalLinkDaily(), $cutoffDate ) || $hasMore;

			if ( ! $this->timeExceeded( $startedAt ) ) {
				$hasMore = $this->deleteExpiredPosts() || $hasMore;
			}

			if ( ! $this->timeExceeded( $startedAt ) ) {
				$hasMore = $this->deleteOrphanReferrers( $cutoffDate ) || $hasMore;
			}

			update_option( 'jimmy_pv_last_maintenance', gmdate( 'Y-m-d H:i:s' ), false );
			delete_option( 'jimmy_pv_maintenance_error' );

			if ( $hasMore || $this->timeExceeded( $startedAt ) ) {
				Scheduler::scheduleContinuation();
			}
		} catch ( Throwable $throwable ) {
			update_option(
				'jimmy_pv_maintenance_error',
				array(
					'code'        => 'maintenance.failed:' . get_class( $throwable ),
					'occurred_at' => gmdate( 'Y-m-d H:i:s' ),
				),
				false
			);
		} finally {
			$this->lock->release();
		}
	}

	private function deleteExpiredEvents(): bool {
		$query = $this->wpdb->prepare(
			"DELETE FROM {$this->tables->eventDedupe()} WHERE expires_at < %s LIMIT %d",
			gmdate( 'Y-m-d H:i:s' ),
			self::DELETE_LIMIT
		);

		return $this->executeDelete( $query, self::DELETE_LIMIT );
	}

	private function deleteDateRows( string $table, string $cutoffDate ): bool {
		$query = $this->wpdb->prepare(
			"DELETE FROM {$table} WHERE stat_date < %s LIMIT %d",
			$cutoffDate,
			self::DELETE_LIMIT
		);

		return $this->executeDelete( $query, self::DELETE_LIMIT );
	}

	private function deleteExpiredPosts(): bool {
		$cutoff = gmdate( 'Y-m-d H:i:s', time() - 30 * DAY_IN_SECONDS );
		$query  = $this->wpdb->prepare(
			"SELECT id FROM {$this->tables->pages()} WHERE deleted_at IS NOT NULL AND deleted_at < %s ORDER BY id ASC LIMIT %d",
			$cutoff,
			self::PAGE_DELETE_LIMIT
		);
		$pageIds = array_map( 'absint', (array) $this->wpdb->get_col( $query ) );
		if ( array() === $pageIds ) {
			return false;
		}

		$linkIds = $this->linkIdsFromPages( $pageIds );
		if ( array() !== $linkIds ) {
			$this->deleteByIds( $this->tables->internalLinkDaily(), 'link_id', $linkIds );
		}

		$this->deleteLinksFromPages( $pageIds );
		$this->detachLinkTargets( $pageIds );
		$this->deleteByIds( $this->tables->referrerDaily(), 'page_id', $pageIds );
		$this->deleteByIds( $this->tables->campaignDaily(), 'page_id', $pageIds );
		$this->deleteByIds( $this->tables->daily(), 'page_id', $pageIds );
		$this->deleteByIds( $this->tables->pages(), 'id', $pageIds );

		return self::PAGE_DELETE_LIMIT === count( $pageIds );
	}

	/** @param int[] $pageIds
	 *  @return int[]
	 */
	private function linkIdsFromPages( array $pageIds ): array {
		$placeholders = implode( ',', array_fill( 0, count( $pageIds ), '%d' ) );
		$sql = "SELECT id FROM {$this->tables->internalLinks()} WHERE source_page_id IN ({$placeholders})";
		$query = $this->wpdb->prepare( $sql, ...$pageIds );

		return array_map( 'absint', (array) $this->wpdb->get_col( $query ) );
	}

	/** @param int[] $pageIds */
	private function deleteLinksFromPages( array $pageIds ): void {
		$placeholders = implode( ',', array_fill( 0, count( $pageIds ), '%d' ) );
		$sql = "DELETE FROM {$this->tables->internalLinks()} WHERE source_page_id IN ({$placeholders})";
		$query = $this->wpdb->prepare( $sql, ...$pageIds );
		$this->executeDelete( $query );
	}

	/** @param int[] $pageIds */
	private function detachLinkTargets( array $pageIds ): void {
		$placeholders = implode( ',', array_fill( 0, count( $pageIds ), '%d' ) );
		$sql = "UPDATE {$this->tables->internalLinks()} SET target_page_id = NULL WHERE target_page_id IN ({$placeholders})";
		$query = $this->wpdb->prepare( $sql, ...$pageIds );
		$result = $this->wpdb->query( $query );
		if ( false === $result ) {
			throw new RuntimeException( 'Database maintenance query failed.' );
		}
	}

	private function deleteOrphanReferrers( string $cutoffDate ): bool {
		$cutoffUtc = $cutoffDate . ' 00:00:00';
		$query = $this->wpdb->prepare(
			"SELECT r.id FROM {$this->tables->referrers()} r
LEFT JOIN {$this->tables->referrerDaily()} d ON d.referrer_id = r.id
WHERE r.last_seen_at < %s AND d.id IS NULL
ORDER BY r.id ASC LIMIT %d",
			$cutoffUtc,
			self::PAGE_DELETE_LIMIT
		);
		$ids = array_map( 'absint', (array) $this->wpdb->get_col( $query ) );
		if ( array() === $ids ) {
			return false;
		}

		$this->deleteByIds( $this->tables->referrers(), 'id', $ids );

		return self::PAGE_DELETE_LIMIT === count( $ids );
	}

	/** @param int[] $ids */
	private function deleteByIds( string $table, string $column, array $ids ): void {
		if ( array() === $ids || ! preg_match( '/^[a-z_]+$/D', $column ) ) {
			return;
		}

		$placeholders = implode( ',', array_fill( 0, count( $ids ), '%d' ) );
		$query = $this->wpdb->prepare( "DELETE FROM {$table} WHERE {$column} IN ({$placeholders})", ...$ids );
		$this->executeDelete( $query );
	}

	private function executeDelete( string $query, int $limit = 0 ): bool {
		$result = $this->wpdb->query( $query );
		if ( false === $result ) {
			throw new RuntimeException( 'Database maintenance query failed.' );
		}

		return 0 < $limit && $limit === $result;
	}

	private function timeExceeded( float $startedAt ): bool {
		return self::MAX_RUNTIME_SECONDS <= microtime( true ) - $startedAt;
	}
}
