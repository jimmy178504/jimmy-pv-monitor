<?php

namespace Jimmy\PVMonitor\Maintenance;

use DateTimeImmutable;
use WP_Error;

defined( 'ABSPATH' ) || exit;

final class Scheduler {
	public const DAILY_HOOK = 'jimmy_pv_daily_maintenance';
	public const ERROR_OPTION = 'jimmy_pv_cron_error';

	public static function register( DailyMaintenance $maintenance ): void {
		add_action( self::DAILY_HOOK, array( $maintenance, 'run' ) );
	}

	public static function ensureScheduled(): bool {
		if ( false !== wp_next_scheduled( self::DAILY_HOOK ) ) {
			delete_option( self::ERROR_OPTION );

			return true;
		}

		$now   = new DateTimeImmutable( 'now', wp_timezone() );
		$first = $now->modify( '+1 day' )->setTime( 3, random_int( 0, 59 ), random_int( 0, 59 ) );
		$result = wp_schedule_event( $first->getTimestamp(), 'daily', self::DAILY_HOOK, array(), true );

		if ( $result instanceof WP_Error || false === $result ) {
			update_option(
				self::ERROR_OPTION,
				array(
					'code'        => $result instanceof WP_Error ? $result->get_error_code() : 'cron.schedule_failed',
					'occurred_at' => gmdate( 'Y-m-d H:i:s' ),
				),
				false
			);

			return false;
		}

		delete_option( self::ERROR_OPTION );

		return true;
	}

	public static function scheduleContinuation(): void {
		wp_schedule_single_event( time() + MINUTE_IN_SECONDS, self::DAILY_HOOK, array(), true );
	}

	public static function unschedule(): void {
		wp_clear_scheduled_hook( self::DAILY_HOOK );
		wp_clear_scheduled_hook( 'jimmy_pv_link_index_batch' );
	}
}
