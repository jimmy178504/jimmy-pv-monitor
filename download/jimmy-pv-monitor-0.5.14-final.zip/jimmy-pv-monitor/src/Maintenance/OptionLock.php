<?php

namespace Jimmy\PVMonitor\Maintenance;

defined( 'ABSPATH' ) || exit;

final class OptionLock {
	private ?string $owner = null;

	public function __construct(
		private readonly string $optionName,
		private readonly int $ttlSeconds
	) {}

	public function acquire(): bool {
		if ( null !== $this->owner ) {
			return true;
		}

		$owner   = bin2hex( random_bytes( 16 ) );
		$payload = array(
			'owner'      => $owner,
			'expires_at' => time() + $this->ttlSeconds,
		);

		if ( add_option( $this->optionName, $payload, '', false ) ) {
			$this->owner = $owner;

			return true;
		}

		$current = get_option( $this->optionName, array() );
		if ( ! is_array( $current ) || (int) ( $current['expires_at'] ?? 0 ) >= time() ) {
			return false;
		}

		delete_option( $this->optionName );
		if ( ! add_option( $this->optionName, $payload, '', false ) ) {
			return false;
		}

		$this->owner = $owner;

		return true;
	}

	public function release(): void {
		if ( null === $this->owner ) {
			return;
		}

		$current = get_option( $this->optionName, array() );
		if ( is_array( $current ) && hash_equals( $this->owner, (string) ( $current['owner'] ?? '' ) ) ) {
			delete_option( $this->optionName );
		}

		$this->owner = null;
	}
}
