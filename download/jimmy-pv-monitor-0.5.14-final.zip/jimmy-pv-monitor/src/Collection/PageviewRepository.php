<?php

namespace Jimmy\PVMonitor\Collection;

use Jimmy\PVMonitor\Database\TableNames;
use Jimmy\PVMonitor\Pages\ResolvedPage;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Scalar values are prepared; identifiers come from TableNames and a fixed query builder.

final class PageviewRepository {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function increment( ResolvedPage $page ): PageviewResult|WP_Error {
		$nowUtc   = gmdate( 'Y-m-d H:i:s' );
		$statDate = wp_date( 'Y-m-d', null, wp_timezone() );

		if ( false === $this->wpdb->query( 'START TRANSACTION' ) ) {
			return new WP_Error( 'jimmy_pv_transaction_failed', __( 'PVを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
		}

		$pageId = $this->incrementPage( $page, $nowUtc );
		if ( $pageId instanceof WP_Error ) {
			$this->wpdb->query( 'ROLLBACK' );

			return $pageId;
		}

		$dailyQuery = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->daily()} (stat_date,page_id,pv,updated_at)
VALUES (%s,%d,1,%s)
ON DUPLICATE KEY UPDATE pv = pv + 1, updated_at = VALUES(updated_at)",
			$statDate,
			$pageId,
			$nowUtc
		);

		if ( false === $this->wpdb->query( $dailyQuery ) ) {
			$this->wpdb->query( 'ROLLBACK' );

			return new WP_Error( 'jimmy_pv_daily_write_failed', __( 'PVを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
		}

		if ( false === $this->wpdb->query( 'COMMIT' ) ) {
			$this->wpdb->query( 'ROLLBACK' );

			return new WP_Error( 'jimmy_pv_commit_failed', __( 'PVを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
		}

		return new PageviewResult( $pageId, $statDate, $nowUtc );
	}

	private function incrementPage( ResolvedPage $page, string $nowUtc ): int|WP_Error {
		if ( null === $page->objectId ) {
			$query = $this->wpdb->prepare(
				$this->pageUpsertSql( true ),
				$page->pageKey,
				$page->objectType,
				$page->canonicalHash,
				$page->canonicalUrl,
				$page->title,
				$nowUtc,
				$nowUtc,
				$nowUtc,
				$nowUtc
			);
		} else {
			$query = $this->wpdb->prepare(
				$this->pageUpsertSql( false ),
				$page->pageKey,
				$page->objectType,
				$page->objectId,
				$page->canonicalHash,
				$page->canonicalUrl,
				$page->title,
				$nowUtc,
				$nowUtc,
				$nowUtc,
				$nowUtc
			);
		}

		if ( false === $this->wpdb->query( $query ) ) {
			return new WP_Error( 'jimmy_pv_page_write_failed', __( 'PVを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
		}

		$pageId = (int) $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT id FROM {$this->tables->pages()} WHERE page_key = %s LIMIT 1",
				$page->pageKey
			)
		);

		return 0 < $pageId
			? $pageId
			: new WP_Error( 'jimmy_pv_page_id_missing', __( 'PVを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
	}

	private function pageUpsertSql( bool $nullObjectId ): string {
		$objectIdValue = $nullObjectId ? 'NULL' : '%d';

		return "INSERT INTO {$this->tables->pages()}
(page_key,object_type,object_id,canonical_hash,canonical_url,title,total_pv,first_viewed_at,last_viewed_at,deleted_at,created_at,updated_at)
VALUES (%s,%s,{$objectIdValue},%s,%s,%s,1,%s,%s,NULL,%s,%s)
ON DUPLICATE KEY UPDATE
object_type = VALUES(object_type),
object_id = VALUES(object_id),
canonical_hash = VALUES(canonical_hash),
canonical_url = VALUES(canonical_url),
title = VALUES(title),
total_pv = total_pv + 1,
first_viewed_at = COALESCE(first_viewed_at,VALUES(first_viewed_at)),
last_viewed_at = VALUES(last_viewed_at),
deleted_at = NULL,
updated_at = VALUES(updated_at)";
	}
}
