<?php

namespace Jimmy\PVMonitor\Collection;

use Jimmy\PVMonitor\Core\SiteSecret;
use Jimmy\PVMonitor\Database\TableNames;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Scalar values are prepared; table identifiers come from the internal TableNames registry.

final class EventDeduplicator {
	private const EVENT_TYPES = array( 'pageview', 'link_click', 'link_view' );

	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function claim( string $eventId, string $eventType = 'pageview' ): bool|WP_Error {
		$eventType = in_array( $eventType, self::EVENT_TYPES, true ) ? $eventType : 'pageview';
		$hash    = $this->hash( $eventId, $eventType );
		$nowUtc  = gmdate( 'Y-m-d H:i:s' );
		$expires = gmdate( 'Y-m-d H:i:s', time() + 2 * DAY_IN_SECONDS );
		$query   = $this->wpdb->prepare(
			"INSERT IGNORE INTO {$this->tables->eventDedupe()}
(dedupe_hash,event_type,hit_count,expires_at,created_at)
VALUES (%s,%s,1,%s,%s)",
			$hash,
			$eventType,
			$expires,
			$nowUtc
		);
		$result = $this->wpdb->query( $query );

		if ( false === $result ) {
			return new WP_Error( 'jimmy_pv_dedupe_failed', __( 'PVを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
		}

		return 1 === $result;
	}

	public function forget( string $eventId, string $eventType = 'pageview' ): void {
		$eventType = in_array( $eventType, self::EVENT_TYPES, true ) ? $eventType : 'pageview';
		$this->wpdb->delete(
			$this->tables->eventDedupe(),
			array(
				'dedupe_hash' => $this->hash( $eventId, $eventType ),
				'event_type'  => $eventType,
			),
			array( '%s', '%s' )
		);
	}

	public function claimLinkView( string $viewId, int $linkId ): bool|WP_Error {
		return $this->claim( $viewId . '|' . $linkId, 'link_view' );
	}

	public function forgetLinkView( string $viewId, int $linkId ): void {
		$this->forget( $viewId . '|' . $linkId, 'link_view' );
	}

	private function hash( string $eventId, string $eventType ): string {
		return hash_hmac( 'sha256', $eventType . '|' . $eventId, SiteSecret::bytes( true ) );
	}
}
