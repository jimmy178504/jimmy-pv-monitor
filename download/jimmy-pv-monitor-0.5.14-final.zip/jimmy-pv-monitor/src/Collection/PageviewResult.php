<?php

namespace Jimmy\PVMonitor\Collection;

defined( 'ABSPATH' ) || exit;

final class PageviewResult {
	public function __construct(
		public readonly int $pageId,
		public readonly string $statDate,
		public readonly string $recordedAtUtc
	) {}
}
