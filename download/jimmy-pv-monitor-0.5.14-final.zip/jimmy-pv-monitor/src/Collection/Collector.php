<?php

namespace Jimmy\PVMonitor\Collection;

use Jimmy\PVMonitor\Inflow\Campaign;
use Jimmy\PVMonitor\Inflow\InflowRepository;
use Jimmy\PVMonitor\Inflow\Referrer;
use Jimmy\PVMonitor\Links\LinkMetricsRepository;
use Jimmy\PVMonitor\Pages\ResolvedPage;
use WP_Error;

defined( 'ABSPATH' ) || exit;

final class Collector {
	public function __construct(
		private readonly PageviewRepository $pageviews,
		private readonly InflowRepository $inflow,
		private readonly LinkMetricsRepository $linkMetrics
	) {}

	/** @param int[] $linkIds */
	public function collect( ResolvedPage $page, ?Referrer $referrer, ?Campaign $campaign, array $linkIds = array() ): bool|WP_Error {
		$result = $this->pageviews->increment( $page );

		if ( $result instanceof WP_Error ) {
			return $result;
		}

		$inflowResult = $this->inflow->record( $result, $referrer, $campaign );
		if ( $inflowResult instanceof WP_Error ) {
			do_action( 'jimmy_pv_inflow_collection_failed', $inflowResult, $page );
		}

		$linkResult = $this->linkMetrics->recordImpressions( $result, $linkIds );
		if ( $linkResult instanceof WP_Error ) {
			do_action( 'jimmy_pv_link_impression_collection_failed', $linkResult, $page );
		}

		do_action( 'jimmy_pv_after_pageview_collected', $page );

		return true;
	}
}
