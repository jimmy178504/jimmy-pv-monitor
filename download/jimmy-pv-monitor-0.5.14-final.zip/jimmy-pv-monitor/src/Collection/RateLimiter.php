<?php

namespace Jimmy\PVMonitor\Collection;

use Jimmy\PVMonitor\Core\SiteSecret;
use Jimmy\PVMonitor\Database\TableNames;
use WP_Error;
use WP_REST_Request;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Scalar values are prepared; table identifiers come from the internal TableNames registry.

final class RateLimiter {
	private const DEFAULT_LIMIT_PER_MINUTE = 300;

	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function check( WP_REST_Request $request ): bool|WP_Error {
			$remoteAddress = isset( $_SERVER['REMOTE_ADDR'] )
				? sanitize_text_field( wp_unslash( (string) $_SERVER['REMOTE_ADDR'] ) )
				: '';
		$userAgent     = substr( sanitize_text_field( $request->get_header( 'user-agent' ) ), 0, 512 );
		$identifier    = (string) apply_filters(
			'jimmy_pv_rate_limit_identifier',
			$remoteAddress . '|' . $userAgent,
			$request
		);
		$identifier = substr( $identifier, 0, 1024 );

		$bucket  = gmdate( 'YmdHi' );
		$hash    = hash_hmac( 'sha256', 'rate|' . $bucket . '|' . $identifier, SiteSecret::bytes( true ) );
		$nowUtc  = gmdate( 'Y-m-d H:i:s' );
		$expires = gmdate( 'Y-m-d H:i:s', time() + 2 * MINUTE_IN_SECONDS );
		$query   = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->eventDedupe()}
(dedupe_hash,event_type,hit_count,expires_at,created_at)
VALUES (%s,'rate_limit',1,%s,%s)
ON DUPLICATE KEY UPDATE hit_count = hit_count + 1, expires_at = VALUES(expires_at)",
			$hash,
			$expires,
			$nowUtc
		);

		if ( false === $this->wpdb->query( $query ) ) {
			return new WP_Error( 'jimmy_pv_rate_limit_failed', __( 'PVを記録できませんでした。', 'jimmy-pv-monitor' ), array( 'status' => 503 ) );
		}

		$hitCount = (int) $this->wpdb->get_var(
			$this->wpdb->prepare(
				"SELECT hit_count FROM {$this->tables->eventDedupe()} WHERE dedupe_hash = %s LIMIT 1",
				$hash
			)
		);
		$limit = (int) apply_filters( 'jimmy_pv_rate_limit_per_minute', self::DEFAULT_LIMIT_PER_MINUTE );
		$limit = max( 60, min( 5000, $limit ) );

		if ( $limit < $hitCount ) {
			return new WP_Error(
				'jimmy_pv_rate_limited',
				__( '計測リクエストが多すぎます。', 'jimmy-pv-monitor' ),
				array(
					'status'      => 429,
					'retry_after' => 60,
				)
			);
		}

		return true;
	}
}
