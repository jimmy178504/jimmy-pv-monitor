<?php

namespace Jimmy\PVMonitor\Collection;

use Jimmy\PVMonitor\Pages\CollectionPageResolver;
use Jimmy\PVMonitor\Pages\PageTokenService;
use Jimmy\PVMonitor\Pages\TrackingPolicy;
use Jimmy\PVMonitor\Pages\UrlNormalizer;
use Jimmy\PVMonitor\Inflow\CampaignParser;
use Jimmy\PVMonitor\Inflow\ReferrerNormalizer;
use WP_Error;
use WP_REST_Request;
use WP_REST_Response;
use WP_REST_Server;

defined( 'ABSPATH' ) || exit;

final class PageviewController {
	private const MAX_BODY_BYTES = 16384;

	public function __construct(
		private readonly CollectionPageResolver $pages,
		private readonly TrackingPolicy $tracking,
		private readonly PageTokenService $tokens,
		private readonly UrlNormalizer $urls,
		private readonly RateLimiter $rateLimiter,
		private readonly EventDeduplicator $deduplicator,
		private readonly Collector $collector,
		private readonly ReferrerNormalizer $referrers,
		private readonly CampaignParser $campaigns
	) {}

	public function register(): void {
		register_rest_route(
			'jimmy-pv/v1',
			'/collect/pageview',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'handle' ),
				'permission_callback' => '__return_true',
				'args'                => $this->routeArguments(),
			)
		);
	}

	public function handle( WP_REST_Request $request ): WP_REST_Response|WP_Error {
		$contentType = strtolower( $request->get_header( 'content-type' ) );
		$mediaType   = trim( explode( ';', $contentType, 2 )[0] );
		if ( 'application/json' !== $mediaType || self::MAX_BODY_BYTES < strlen( $request->get_body() ) ) {
			return $this->error( 'jimmy_pv_invalid_content', 415 );
		}

		$origin = trim( $request->get_header( 'origin' ) );
		if ( '' !== $origin && ! $this->urls->isSameOrigin( $origin ) ) {
			return $this->error( 'jimmy_pv_invalid_origin', 403 );
		}

		$payload = $request->get_json_params();
		if ( ! is_array( $payload ) ) {
			return $this->error( 'jimmy_pv_invalid_content', 400 );
		}

		$eventId   = $this->payloadString( $payload, 'event_id' );
		$viewId    = $this->payloadString( $payload, 'view_id' );
		$pageKey   = $this->payloadString( $payload, 'page_key' );
		$url       = $this->payloadString( $payload, 'url' );
		$referrer  = $this->payloadString( $payload, 'referrer' );
		$signature = $this->payloadString( $payload, 'signature' );
		$linkIds   = $this->payloadLinkIds( $payload );
		if (
			! $this->isIdentifier( $eventId )
			|| ! $this->isIdentifier( $viewId )
			|| ! $this->isPageKey( $pageKey )
			|| ! $this->isSignature( $signature )
			|| ! $this->isUrl( $url )
			|| ! $this->isOptionalUrl( $referrer )
			|| ! $this->urls->isInternal( $url )
			|| null === $linkIds
		) {
			return $this->error( 'jimmy_pv_invalid_content', 400 );
		}

		$page = $this->pages->resolve( $pageKey, $url );

		if ( ! $page->isTrackable ) {
			return $this->error( 'jimmy_pv_invalid_page', 400 );
		}

		if ( ! $this->tokens->verify( $page, $signature ) ) {
			return $this->error( 'jimmy_pv_invalid_signature', 403 );
		}

		$decision = $this->tracking->evaluate( $page, null, $request->get_header( 'user-agent' ) );
		if ( ! $decision->allowed ) {
			return $this->noContent();
		}

		$rateLimit = $this->rateLimiter->check( $request );
		if ( $rateLimit instanceof WP_Error ) {
			return $rateLimit;
		}

		$claim = $this->deduplicator->claim( $eventId );
		if ( $claim instanceof WP_Error ) {
			return $claim;
		}
		if ( false === $claim ) {
			return $this->noContent();
		}

		$result = $this->collector->collect(
			$page,
			$this->referrers->resolve( $referrer ),
			$this->campaigns->parse( $url ),
			$linkIds
		);
		if ( $result instanceof WP_Error ) {
			$this->deduplicator->forget( $eventId );

			return $result;
		}
		if ( false === $result ) {
			$this->deduplicator->forget( $eventId );

			return $this->error( 'jimmy_pv_collection_failed', 503 );
		}

		return $this->noContent();
	}

	/** @return array<string, array<string, mixed>> */
	private function routeArguments(): array {
		return array(
			'event_id' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => static fn ( mixed $value ): string => trim( (string) $value ),
				'validate_callback' => fn ( mixed $value ): bool => $this->isIdentifier( $value ),
			),
			'view_id' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => static fn ( mixed $value ): string => trim( (string) $value ),
				'validate_callback' => fn ( mixed $value ): bool => $this->isIdentifier( $value ),
			),
			'page_key' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => static fn ( mixed $value ): string => trim( (string) $value ),
				'validate_callback' => fn ( mixed $value ): bool => $this->isPageKey( $value ),
			),
			'signature' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => static fn ( mixed $value ): string => trim( (string) $value ),
				'validate_callback' => fn ( mixed $value ): bool => $this->isSignature( $value ),
			),
			'url' => array(
				'required'          => true,
				'type'              => 'string',
				'sanitize_callback' => static fn ( mixed $value ): string => trim( (string) $value ),
				'validate_callback' => fn ( mixed $value ): bool => $this->isUrl( $value ),
			),
			'referrer' => array(
				'required'          => false,
				'default'           => '',
				'type'              => 'string',
				'sanitize_callback' => static fn ( mixed $value ): string => trim( (string) $value ),
				'validate_callback' => fn ( mixed $value ): bool => $this->isOptionalUrl( $value ),
			),
			'link_ids' => array(
				'required' => false,
				'default'  => array(),
				'type'     => 'array',
				'maxItems' => 200,
				'items'    => array( 'type' => 'integer', 'minimum' => 1 ),
			),
		);
	}

	/** @param array<string, mixed> $payload */
	private function payloadString( array $payload, string $key ): string {
		return isset( $payload[ $key ] ) && is_string( $payload[ $key ] )
			? trim( $payload[ $key ] )
			: '';
	}

	private function isIdentifier( mixed $value ): bool {
		return is_string( $value )
			&& 16 <= strlen( $value )
			&& 64 >= strlen( $value )
			&& 1 === preg_match( '/^[A-Fa-f0-9-]+$/D', $value );
	}

	private function isPageKey( mixed $value ): bool {
		return is_string( $value )
			&& 191 >= strlen( $value )
			&& 1 === preg_match(
				'/^(?:post:\d+|special:(?:home|search)|(?:archive|search|404):[a-f0-9]{64})$/D',
				$value
			);
	}

	private function isSignature( mixed $value ): bool {
		return is_string( $value )
			&& 32 <= strlen( $value )
			&& 128 >= strlen( $value )
			&& 1 === preg_match( '/^[A-Za-z0-9_-]+$/D', $value );
	}

	private function isUrl( mixed $value ): bool {
		return is_string( $value ) && 1 <= strlen( $value ) && 2048 >= strlen( $value );
	}

	private function isOptionalUrl( mixed $value ): bool {
		return is_string( $value ) && 2048 >= strlen( $value );
	}

	/** @param array<string, mixed> $payload
	 *  @return int[]|null
	 */
	private function payloadLinkIds( array $payload ): ?array {
		if ( ! array_key_exists( 'link_ids', $payload ) ) {
			return array();
		}
		if ( ! is_array( $payload['link_ids'] ) || 200 < count( $payload['link_ids'] ) ) {
			return null;
		}

		$ids = array();
		foreach ( $payload['link_ids'] as $value ) {
			if ( ! is_int( $value ) || 0 >= $value ) {
				return null;
			}
			$ids[ $value ] = $value;
		}

		return array_values( $ids );
	}

	private function noContent(): WP_REST_Response {
		$response = new WP_REST_Response( null, 204 );
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );

		return $response;
	}

	private function error( string $code, int $status ): WP_Error {
		return new WP_Error(
			$code,
			__( '計測リクエストを処理できませんでした。', 'jimmy-pv-monitor' ),
			array( 'status' => $status )
		);
	}
}
