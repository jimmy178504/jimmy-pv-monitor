<?php

namespace Jimmy\PVMonitor\Database;

use InvalidArgumentException;
use wpdb;

defined( 'ABSPATH' ) || exit;

final class TableNames {
	private readonly string $prefix;

	public function __construct( wpdb $wpdb ) {
		if ( ! preg_match( '/^[A-Za-z0-9_]+$/D', $wpdb->prefix ) ) {
			throw new InvalidArgumentException( 'Invalid WordPress database table prefix.' );
		}

		$this->prefix = $wpdb->prefix . 'jimmy_pv_';
	}

	public function pages(): string {
		return $this->prefix . 'pages';
	}

	public function daily(): string {
		return $this->prefix . 'daily';
	}

	public function referrers(): string {
		return $this->prefix . 'referrers';
	}

	public function referrerDaily(): string {
		return $this->prefix . 'referrer_daily';
	}

	public function campaignDaily(): string {
		return $this->prefix . 'campaign_daily';
	}

	public function internalLinks(): string {
		return $this->prefix . 'internal_links';
	}

	public function internalLinkDaily(): string {
		return $this->prefix . 'internal_link_daily';
	}

	public function eventDedupe(): string {
		return $this->prefix . 'event_dedupe';
	}

	/** @return string[] */
	public function all(): array {
		return array(
			$this->pages(),
			$this->daily(),
			$this->referrers(),
			$this->referrerDaily(),
			$this->campaignDaily(),
			$this->internalLinks(),
			$this->internalLinkDaily(),
			$this->eventDedupe(),
		);
	}
}
