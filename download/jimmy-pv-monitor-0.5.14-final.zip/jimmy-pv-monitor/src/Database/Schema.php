<?php

namespace Jimmy\PVMonitor\Database;

use wpdb;

defined( 'ABSPATH' ) || exit;

final class Schema {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	/** @return string[] */
	public function statements(): array {
		$charsetCollate = $this->wpdb->get_charset_collate();
		$pages         = $this->tables->pages();
		$daily         = $this->tables->daily();
		$referrers     = $this->tables->referrers();
		$referrerDaily = $this->tables->referrerDaily();
		$campaignDaily = $this->tables->campaignDaily();
		$internalLinks = $this->tables->internalLinks();
		$linkDaily     = $this->tables->internalLinkDaily();
		$eventDedupe   = $this->tables->eventDedupe();

		return array(
			"CREATE TABLE {$pages} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
page_key varchar(191) NOT NULL,
object_type varchar(32) NOT NULL,
object_id bigint(20) unsigned DEFAULT NULL,
canonical_hash char(64) NOT NULL,
canonical_url text NOT NULL,
title text NOT NULL,
total_pv bigint(20) unsigned NOT NULL DEFAULT 0,
first_viewed_at datetime DEFAULT NULL,
last_viewed_at datetime DEFAULT NULL,
deleted_at datetime DEFAULT NULL,
created_at datetime NOT NULL,
updated_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY page_key (page_key),
KEY object_lookup (object_type,object_id),
KEY canonical_hash (canonical_hash),
KEY deleted_at (deleted_at),
KEY total_pv (total_pv)
) {$charsetCollate};",
			"CREATE TABLE {$daily} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
stat_date date NOT NULL,
page_id bigint(20) unsigned NOT NULL,
pv bigint(20) unsigned NOT NULL DEFAULT 0,
updated_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY stat_page (stat_date,page_id),
KEY page_date (page_id,stat_date),
KEY date_pv (stat_date,pv)
) {$charsetCollate};",
			"CREATE TABLE {$referrers} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
url_hash char(64) NOT NULL,
referrer_url text NOT NULL,
domain varchar(191) NOT NULL DEFAULT '',
source_type varchar(32) NOT NULL,
source_name varchar(100) NOT NULL DEFAULT '',
first_seen_at datetime NOT NULL,
last_seen_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY url_hash (url_hash),
KEY domain (domain),
KEY source_lookup (source_type,source_name),
KEY last_seen_at (last_seen_at)
) {$charsetCollate};",
			"CREATE TABLE {$referrerDaily} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
stat_date date NOT NULL,
page_id bigint(20) unsigned NOT NULL,
referrer_id bigint(20) unsigned NOT NULL DEFAULT 0,
pv bigint(20) unsigned NOT NULL DEFAULT 0,
updated_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY date_page_referrer (stat_date,page_id,referrer_id),
KEY referrer_date (referrer_id,stat_date),
KEY date_pv (stat_date,pv)
) {$charsetCollate};",
			"CREATE TABLE {$campaignDaily} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
stat_date date NOT NULL,
page_id bigint(20) unsigned NOT NULL,
campaign_key char(64) NOT NULL,
utm_source varchar(191) NOT NULL DEFAULT '',
utm_medium varchar(191) NOT NULL DEFAULT '',
utm_campaign varchar(191) NOT NULL DEFAULT '',
utm_term varchar(191) NOT NULL DEFAULT '',
utm_content varchar(191) NOT NULL DEFAULT '',
ad_platform varchar(32) NOT NULL DEFAULT '',
pv bigint(20) unsigned NOT NULL DEFAULT 0,
updated_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY date_page_campaign (stat_date,page_id,campaign_key),
KEY page_date (page_id,stat_date),
KEY stat_date (stat_date)
) {$charsetCollate};",
			"CREATE TABLE {$internalLinks} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
source_page_id bigint(20) unsigned NOT NULL,
target_page_id bigint(20) unsigned DEFAULT NULL,
link_type varchar(12) NOT NULL DEFAULT 'internal',
target_hash char(64) NOT NULL,
target_url text NOT NULL,
anchor_text text NOT NULL,
is_active tinyint(1) unsigned NOT NULL DEFAULT 1,
first_seen_at datetime NOT NULL,
last_seen_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY source_target (source_page_id,target_hash),
KEY target_page_id (target_page_id),
KEY source_active (source_page_id,is_active),
KEY source_type_active (source_page_id,link_type,is_active)
) {$charsetCollate};",
			"CREATE TABLE {$linkDaily} (
id bigint(20) unsigned NOT NULL AUTO_INCREMENT,
stat_date date NOT NULL,
link_id bigint(20) unsigned NOT NULL,
impression_views bigint(20) unsigned NOT NULL DEFAULT 0,
clicked_views bigint(20) unsigned NOT NULL DEFAULT 0,
raw_clicks bigint(20) unsigned NOT NULL DEFAULT 0,
last_clicked_at datetime DEFAULT NULL,
updated_at datetime NOT NULL,
PRIMARY KEY  (id),
UNIQUE KEY date_link (stat_date,link_id),
KEY link_date (link_id,stat_date),
KEY date_clicked (stat_date,clicked_views)
) {$charsetCollate};",
			"CREATE TABLE {$eventDedupe} (
dedupe_hash char(64) NOT NULL,
event_type varchar(16) NOT NULL,
hit_count bigint(20) unsigned NOT NULL DEFAULT 1,
expires_at datetime NOT NULL,
created_at datetime NOT NULL,
PRIMARY KEY  (dedupe_hash),
KEY expires_at (expires_at)
) {$charsetCollate};",
		);
	}
}
