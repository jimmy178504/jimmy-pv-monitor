<?php

namespace Jimmy\PVMonitor\Database;

use Jimmy\PVMonitor\Maintenance\OptionLock;
use Throwable;

defined( 'ABSPATH' ) || exit;

final class Migrator {
	public const VERSION_OPTION = 'jimmy_pv_db_version';
	public const ERROR_OPTION   = 'jimmy_pv_schema_error';

	public function __construct(
		private readonly Schema $schema,
		private readonly SchemaVerifier $verifier,
		private readonly OptionLock $lock
	) {}

	public function needsMigration(): bool {
		return (int) get_option( self::VERSION_OPTION, 0 ) < (int) JIMMY_PV_DB_VERSION;
	}

	public function migrate(): MigrationResult {
		if ( ! $this->lock->acquire() ) {
			return MigrationResult::failure( array( 'schema.locked' ) );
		}

		try {
			require_once ABSPATH . 'wp-admin/includes/upgrade.php';
			dbDelta( $this->schema->statements() );

			$errors = $this->verifier->verify();
			if ( array() !== $errors ) {
				$this->recordFailure( $errors );

				return MigrationResult::failure( $errors );
			}

			update_option( self::VERSION_OPTION, (int) JIMMY_PV_DB_VERSION, false );
			delete_option( self::ERROR_OPTION );

			return MigrationResult::success();
		} catch ( Throwable $throwable ) {
			$errors = array( 'schema.migration_failed:' . get_class( $throwable ) );
			$this->recordFailure( $errors );

			return MigrationResult::failure( $errors );
		} finally {
			$this->lock->release();
		}
	}

	/** @param string[] $errors */
	private function recordFailure( array $errors ): void {
		update_option(
			self::ERROR_OPTION,
			array(
				'codes'       => array_map( 'sanitize_text_field', $errors ),
				'occurred_at' => gmdate( 'Y-m-d H:i:s' ),
			),
			false
		);
	}
}
