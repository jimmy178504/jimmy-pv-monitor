<?php

namespace Jimmy\PVMonitor\Database;

use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared,PluginCheck.Security.DirectDB.UnescapedDBParameter -- Schema checks use only identifiers from the internal TableNames registry.

final class SchemaVerifier {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	/** @return string[] */
	public function verify(): array {
		$errors   = array();
		$expected = $this->expectedColumns();

		foreach ( $expected as $table => $columns ) {
			if ( ! $this->tableExists( $table ) ) {
				$errors[] = 'schema.table_missing:' . $table;
				continue;
			}

			$actualColumns = $this->wpdb->get_col( "DESCRIBE {$table}", 0 );
			$actualColumns = is_array( $actualColumns ) ? $actualColumns : array();
			foreach ( $columns as $column ) {
				if ( ! in_array( $column, $actualColumns, true ) ) {
					$errors[] = 'schema.column_missing:' . $table . ':' . $column;
				}
			}
		}

		return $errors;
	}

	private function tableExists( string $table ): bool {
		$query = $this->wpdb->prepare( 'SHOW TABLES LIKE %s', $this->wpdb->esc_like( $table ) );

		return $table === $this->wpdb->get_var( $query );
	}

	/** @return array<string, string[]> */
	private function expectedColumns(): array {
		return array(
			$this->tables->pages() => array(
				'id', 'page_key', 'object_type', 'object_id', 'canonical_hash', 'canonical_url',
				'title', 'total_pv', 'first_viewed_at', 'last_viewed_at', 'deleted_at', 'created_at', 'updated_at',
			),
			$this->tables->daily() => array( 'id', 'stat_date', 'page_id', 'pv', 'updated_at' ),
			$this->tables->referrers() => array(
				'id', 'url_hash', 'referrer_url', 'domain', 'source_type', 'source_name', 'first_seen_at', 'last_seen_at',
			),
			$this->tables->referrerDaily() => array( 'id', 'stat_date', 'page_id', 'referrer_id', 'pv', 'updated_at' ),
			$this->tables->campaignDaily() => array(
				'id', 'stat_date', 'page_id', 'campaign_key', 'utm_source', 'utm_medium', 'utm_campaign',
				'utm_term', 'utm_content', 'ad_platform', 'pv', 'updated_at',
			),
			$this->tables->internalLinks() => array(
				'id', 'source_page_id', 'target_page_id', 'link_type', 'target_hash', 'target_url', 'anchor_text',
				'is_active', 'first_seen_at', 'last_seen_at',
			),
			$this->tables->internalLinkDaily() => array(
				'id', 'stat_date', 'link_id', 'impression_views', 'clicked_views', 'raw_clicks', 'last_clicked_at', 'updated_at',
			),
			$this->tables->eventDedupe() => array( 'dedupe_hash', 'event_type', 'hit_count', 'expires_at', 'created_at' ),
		);
	}
}
