<?php

namespace Jimmy\PVMonitor\Database;

defined( 'ABSPATH' ) || exit;

final class MigrationResult {
	/** @param string[] $errors */
	public function __construct(
		private readonly bool $successful,
		private readonly array $errors
	) {}

	public static function success(): self {
		return new self( true, array() );
	}

	/** @param string[] $errors */
	public static function failure( array $errors ): self {
		return new self( false, $errors );
	}

	public function isSuccessful(): bool {
		return $this->successful;
	}

	/** @return string[] */
	public function errors(): array {
		return $this->errors;
	}
}
