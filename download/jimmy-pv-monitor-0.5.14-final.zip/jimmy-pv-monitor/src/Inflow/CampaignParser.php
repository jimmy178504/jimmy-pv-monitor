<?php

namespace Jimmy\PVMonitor\Inflow;

defined( 'ABSPATH' ) || exit;

final class CampaignParser {
	public function parse( string $url ): ?Campaign {
		$query = wp_parse_url( $url, PHP_URL_QUERY );
		if ( ! is_string( $query ) || '' === $query ) {
			return null;
		}

		$values = $this->values( $query );
		$source = $this->value( $values, 'utm_source' );
		$medium = $this->value( $values, 'utm_medium' );
		$name   = $this->value( $values, 'utm_campaign' );
		$term   = $this->value( $values, 'utm_term' );
		$content = $this->value( $values, 'utm_content' );
		$platform = '';
		foreach ( array( 'gclid' => 'google', 'fbclid' => 'meta', 'msclkid' => 'microsoft' ) as $key => $candidate ) {
			if ( '' !== $this->value( $values, $key ) ) {
				$platform = $candidate;
				break;
			}
		}

		$identity = array( $source, $medium, $name, $term, $content, $platform );
		if ( array() === array_filter( $identity, static fn ( string $value ): bool => '' !== $value ) ) {
			return null;
		}

		$serialized = '';
		foreach ( $identity as $value ) {
			$serialized .= strlen( $value ) . ':' . $value . '|';
		}

		return new Campaign( hash( 'sha256', $serialized ), $source, $medium, $name, $term, $content, $platform );
	}

	/** @return array<string, string> */
	private function values( string $query ): array {
		$result = array();
		foreach ( explode( '&', $query ) as $pair ) {
			$parts = explode( '=', $pair, 2 );
			$key   = strtolower( rawurldecode( str_replace( '+', ' ', $parts[0] ) ) );
			if ( '' === $key || isset( $result[ $key ] ) ) {
				continue;
			}
			$result[ $key ] = isset( $parts[1] ) ? rawurldecode( str_replace( '+', ' ', $parts[1] ) ) : '';
		}

		return $result;
	}

	/** @param array<string, string> $values */
	private function value( array $values, string $key ): string {
		$value = sanitize_text_field( $values[ $key ] ?? '' );

		return function_exists( 'mb_substr' ) ? mb_substr( $value, 0, 191 ) : substr( $value, 0, 191 );
	}
}
