<?php

namespace Jimmy\PVMonitor\Inflow;

use Jimmy\PVMonitor\Settings\SettingsRepository;

defined( 'ABSPATH' ) || exit;

final class ReferrerNormalizer {
	private const MAX_URL_LENGTH = 2048;

	public function __construct(
		private readonly SettingsRepository $settings,
		private readonly SourceClassifier $classifier
	) {}

	public function resolve( string $url ): ?Referrer {
		$settings = $this->settings->all();
		if ( ! (bool) ( $settings['referrer_enabled'] ?? true ) ) {
			return null;
		}

		$url = trim( $url );
		if ( '' === $url ) {
			return Referrer::direct();
		}

		$normalized = $this->normalize( $url, (array) ( $settings['sensitive_query_keys'] ?? array() ) );
		if ( null === $normalized ) {
			return Referrer::direct();
		}

		$domain = strtolower( rtrim( (string) wp_parse_url( $normalized, PHP_URL_HOST ), '.' ) );
		if ( '' === $domain || 191 < strlen( $domain ) ) {
			return Referrer::direct();
		}

		$classification = $this->classifier->classify( $normalized, $domain );

		return new Referrer(
			hash( 'sha256', $normalized ),
			$normalized,
			$domain,
			$classification->type,
			$classification->name
		);
	}

	/** @param string[] $sensitiveKeys */
	private function normalize( string $url, array $sensitiveKeys ): ?string {
		if ( self::MAX_URL_LENGTH < strlen( $url ) || preg_match( '/[\x00-\x1F\x7F]/', $url ) ) {
			return null;
		}

		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) ) {
			return null;
		}

		$scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
		$host   = strtolower( rtrim( (string) ( $parts['host'] ?? '' ), '.' ) );
		if ( ! in_array( $scheme, array( 'http', 'https' ), true ) || '' === $host ) {
			return null;
		}

		$port = isset( $parts['port'] ) ? (int) $parts['port'] : null;
		if ( ( 'http' === $scheme && 80 === $port ) || ( 'https' === $scheme && 443 === $port ) ) {
			$port = null;
		}

		$path       = (string) ( $parts['path'] ?? '/' );
		$path       = '' === $path ? '/' : '/' . ltrim( $path, '/' );
		$hostForUrl = str_contains( $host, ':' ) ? '[' . trim( $host, '[]' ) . ']' : $host;
		$result     = $scheme . '://' . $hostForUrl . ( null !== $port ? ':' . $port : '' ) . $path;

		if ( isset( $parts['query'] ) && '' !== $parts['query'] ) {
			$query = $this->normalizeQuery( (string) $parts['query'], $sensitiveKeys );
			if ( '' !== $query ) {
				$result .= '?' . $query;
			}
		}

		return self::MAX_URL_LENGTH >= strlen( $result ) ? $result : null;
	}

	/** @param string[] $sensitiveKeys */
	private function normalizeQuery( string $query, array $sensitiveKeys ): string {
		$lookup = array_fill_keys( array_map( 'strtolower', array_filter( $sensitiveKeys, 'is_string' ) ), true );
		$pairs  = array();

		foreach ( explode( '&', $query ) as $pair ) {
			if ( '' === $pair ) {
				continue;
			}
			$parts = explode( '=', $pair, 2 );
			$key   = rawurldecode( str_replace( '+', ' ', $parts[0] ) );
			if ( '' === $key || $this->isSensitiveQueryKey( $key, $lookup ) ) {
				continue;
			}

			$encoded = rawurlencode( $key );
			if ( isset( $parts[1] ) ) {
				$value    = rawurldecode( str_replace( '+', ' ', $parts[1] ) );
				$encoded .= '=' . rawurlencode( $value );
			}
			$pairs[] = $encoded;
		}

		sort( $pairs, SORT_STRING );

		return implode( '&', $pairs );
	}

	/** @param array<string, bool> $lookup */
	private function isSensitiveQueryKey( string $key, array $lookup ): bool {
		$segments = preg_split( '/[\[\]]+/', strtolower( $key ), -1, PREG_SPLIT_NO_EMPTY );
		$segments = is_array( $segments ) ? $segments : array();
		foreach ( $segments as $segment ) {
			if ( isset( $lookup[ $segment ] ) ) {
				return true;
			}
		}

		return false;
	}
}
