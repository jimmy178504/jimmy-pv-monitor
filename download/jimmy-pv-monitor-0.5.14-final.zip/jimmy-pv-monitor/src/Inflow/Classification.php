<?php

namespace Jimmy\PVMonitor\Inflow;

defined( 'ABSPATH' ) || exit;

final class Classification {
	public const TYPES = array( 'search', 'social', 'referral', 'internal' );

	public function __construct(
		public readonly string $type,
		public readonly string $name = ''
	) {}

	public function isValid(): bool {
		return in_array( $this->type, self::TYPES, true ) && 100 >= strlen( $this->name );
	}
}
