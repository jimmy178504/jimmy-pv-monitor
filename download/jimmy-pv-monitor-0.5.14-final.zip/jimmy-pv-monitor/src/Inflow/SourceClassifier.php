<?php

namespace Jimmy\PVMonitor\Inflow;

use Jimmy\PVMonitor\Pages\UrlNormalizer;

defined( 'ABSPATH' ) || exit;

final class SourceClassifier {
	public function __construct( private readonly UrlNormalizer $urls ) {}

	public function classify( string $url, string $domain ): Classification {
		if ( $this->urls->isInternal( $url ) ) {
			$classification = new Classification( 'internal', __( 'サイト内', 'jimmy-pv-monitor' ) );
		} elseif ( preg_match( '/^(?:www\.)?google\.[a-z.]+$/D', $domain ) ) {
			$classification = new Classification( 'search', 'Google' );
		} elseif ( $this->isDomain( $domain, 'bing.com' ) ) {
			$classification = new Classification( 'search', 'Bing' );
		} elseif ( preg_match( '/^(?:search\.)?yahoo\.[a-z.]+$/D', $domain ) ) {
			$classification = new Classification( 'search', 'Yahoo!' );
		} elseif ( $this->isDomain( $domain, 'duckduckgo.com' ) ) {
			$classification = new Classification( 'search', 'DuckDuckGo' );
		} else {
			$social = $this->socialName( $domain );
			$classification = null !== $social
				? new Classification( 'social', $social )
				: new Classification( 'referral' );
		}

		/**
		 * Filters a server-derived referrer classification.
		 *
		 * Return a valid Classification object. Invalid values are ignored.
		 */
		$filtered = apply_filters( 'jimmy_pv_referrer_classification', $classification, $url, $domain );

		return $filtered instanceof Classification && $filtered->isValid() ? $filtered : $classification;
	}

	private function socialName( string $domain ): ?string {
		$services = array(
			'X'         => array( 'x.com', 'twitter.com', 't.co' ),
			'Facebook'  => array( 'facebook.com', 'fb.com' ),
			'Instagram' => array( 'instagram.com' ),
			'Threads'   => array( 'threads.net' ),
			'LinkedIn'  => array( 'linkedin.com', 'lnkd.in' ),
			'Pinterest' => array( 'pinterest.com', 'pin.it' ),
			'YouTube'   => array( 'youtube.com', 'youtu.be' ),
			'TikTok'    => array( 'tiktok.com' ),
			'Reddit'    => array( 'reddit.com', 'redd.it' ),
			'はてなブックマーク' => array( 'b.hatena.ne.jp' ),
		);

		foreach ( $services as $name => $domains ) {
			foreach ( $domains as $serviceDomain ) {
				if ( $this->isDomain( $domain, $serviceDomain ) ) {
					return $name;
				}
			}
		}

		return null;
	}

	private function isDomain( string $domain, string $expected ): bool {
		return $domain === $expected || str_ends_with( $domain, '.' . $expected );
	}
}
