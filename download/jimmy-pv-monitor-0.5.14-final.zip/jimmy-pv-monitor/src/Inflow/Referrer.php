<?php

namespace Jimmy\PVMonitor\Inflow;

defined( 'ABSPATH' ) || exit;

final class Referrer {
	public function __construct(
		public readonly string $urlHash,
		public readonly string $url,
		public readonly string $domain,
		public readonly string $sourceType,
		public readonly string $sourceName
	) {}

	public static function direct(): self {
		return new self( '', '', '', 'direct', '' );
	}

	public function isDirect(): bool {
		return 'direct' === $this->sourceType;
	}
}
