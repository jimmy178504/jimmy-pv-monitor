<?php

namespace Jimmy\PVMonitor\Inflow;

use Jimmy\PVMonitor\Collection\PageviewResult;
use Jimmy\PVMonitor\Database\TableNames;
use WP_Error;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Scalar values are prepared; table identifiers come from the internal TableNames registry.

final class InflowRepository {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function record( PageviewResult $pageview, ?Referrer $referrer, ?Campaign $campaign ): bool|WP_Error {
		// A same-site page move is navigation, not a new inflow. Pro route reports handle it separately.
		if ( null !== $referrer && 'internal' === $referrer->sourceType ) {
			$referrer = null;
		}
		if ( null === $referrer && null === $campaign ) {
			return true;
		}
		if ( false === $this->wpdb->query( 'START TRANSACTION' ) ) {
			return $this->error( 'jimmy_pv_inflow_transaction_failed' );
		}

		if ( null !== $referrer ) {
			$referrerId = $referrer->isDirect() ? 0 : $this->upsertReferrer( $referrer, $pageview->recordedAtUtc );
			if ( $referrerId instanceof WP_Error || ! $this->incrementReferrerDaily( $pageview, $referrerId ) ) {
				$this->wpdb->query( 'ROLLBACK' );
				return $referrerId instanceof WP_Error ? $referrerId : $this->error( 'jimmy_pv_referrer_daily_failed' );
			}
		}

		if ( null !== $campaign && ! $this->incrementCampaignDaily( $pageview, $campaign ) ) {
			$this->wpdb->query( 'ROLLBACK' );
			return $this->error( 'jimmy_pv_campaign_daily_failed' );
		}

		if ( false === $this->wpdb->query( 'COMMIT' ) ) {
			$this->wpdb->query( 'ROLLBACK' );
			return $this->error( 'jimmy_pv_inflow_commit_failed' );
		}

		return true;
	}

	private function upsertReferrer( Referrer $referrer, string $nowUtc ): int|WP_Error {
		$query = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->referrers()}
(url_hash,referrer_url,domain,source_type,source_name,first_seen_at,last_seen_at)
VALUES (%s,%s,%s,%s,%s,%s,%s)
ON DUPLICATE KEY UPDATE referrer_url = VALUES(referrer_url),domain = VALUES(domain),
source_type = VALUES(source_type),source_name = VALUES(source_name),last_seen_at = VALUES(last_seen_at)",
			$referrer->urlHash,
			$referrer->url,
			$referrer->domain,
			$referrer->sourceType,
			$referrer->sourceName,
			$nowUtc,
			$nowUtc
		);
		if ( false === $this->wpdb->query( $query ) ) {
			return $this->error( 'jimmy_pv_referrer_write_failed' );
		}

		$id = (int) $this->wpdb->get_var(
			$this->wpdb->prepare( "SELECT id FROM {$this->tables->referrers()} WHERE url_hash = %s LIMIT 1", $referrer->urlHash )
		);

		return 0 < $id ? $id : $this->error( 'jimmy_pv_referrer_id_missing' );
	}

	private function incrementReferrerDaily( PageviewResult $pageview, int $referrerId ): bool {
		$query = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->referrerDaily()} (stat_date,page_id,referrer_id,pv,updated_at)
VALUES (%s,%d,%d,1,%s) ON DUPLICATE KEY UPDATE pv = pv + 1,updated_at = VALUES(updated_at)",
			$pageview->statDate,
			$pageview->pageId,
			$referrerId,
			$pageview->recordedAtUtc
		);

		return false !== $this->wpdb->query( $query );
	}

	private function incrementCampaignDaily( PageviewResult $pageview, Campaign $campaign ): bool {
		$query = $this->wpdb->prepare(
			"INSERT INTO {$this->tables->campaignDaily()}
(stat_date,page_id,campaign_key,utm_source,utm_medium,utm_campaign,utm_term,utm_content,ad_platform,pv,updated_at)
VALUES (%s,%d,%s,%s,%s,%s,%s,%s,%s,1,%s)
ON DUPLICATE KEY UPDATE pv = pv + 1,updated_at = VALUES(updated_at)",
			$pageview->statDate,
			$pageview->pageId,
			$campaign->key,
			$campaign->source,
			$campaign->medium,
			$campaign->campaign,
			$campaign->term,
			$campaign->content,
			$campaign->adPlatform,
			$pageview->recordedAtUtc
		);

		return false !== $this->wpdb->query( $query );
	}

	private function error( string $code ): WP_Error {
		return new WP_Error( $code, __( '流入元を記録できませんでした。', 'jimmy-pv-monitor' ) );
	}
}
