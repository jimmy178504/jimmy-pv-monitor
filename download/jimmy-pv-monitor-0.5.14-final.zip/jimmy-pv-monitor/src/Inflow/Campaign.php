<?php

namespace Jimmy\PVMonitor\Inflow;

defined( 'ABSPATH' ) || exit;

final class Campaign {
	public function __construct(
		public readonly string $key,
		public readonly string $source,
		public readonly string $medium,
		public readonly string $campaign,
		public readonly string $term,
		public readonly string $content,
		public readonly string $adPlatform
	) {}
}
