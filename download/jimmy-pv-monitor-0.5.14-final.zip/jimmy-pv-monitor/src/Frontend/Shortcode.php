<?php

namespace Jimmy\PVMonitor\Frontend;

use Jimmy\PVMonitor\Database\TableNames;
use Jimmy\PVMonitor\Settings\SettingsRepository;
use WP_Post;
use wpdb;

defined( 'ABSPATH' ) || exit;

// phpcs:disable WordPress.DB.PreparedSQL.NotPrepared,WordPress.DB.PreparedSQL.InterpolatedNotPrepared -- Scalar values are prepared; the table identifier comes from the internal TableNames registry.

final class Shortcode {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables,
		private readonly SettingsRepository $settings
	) {}

	public function register(): void {
		add_shortcode( 'jimmy_pv', array( $this, 'render' ) );
	}

	/**
	 * @param array<string, mixed>|string $attributes
	 */
	public function render( array|string $attributes = array() ): string {
		$attributes = shortcode_atts(
			array(
				'post_id' => '',
				'min'     => '',
				'format'  => '',
			),
			is_array( $attributes ) ? $attributes : array(),
			'jimmy_pv'
		);

		$requestedPostId = trim( (string) $attributes['post_id'] );
		if ( '' !== $requestedPostId && 1 !== preg_match( '/^[1-9]\d*$/D', $requestedPostId ) ) {
			return '';
		}
		$postId = '' !== $requestedPostId ? absint( $requestedPostId ) : (int) get_the_ID();
		if ( 0 >= $postId ) {
			return '';
		}

		$post   = get_post( $postId );
		if ( ! $post instanceof WP_Post || ! $this->isPublicPost( $post ) ) {
			return '';
		}

		$total = $this->totalForPost( $postId );
		$requestedMinimum = trim( (string) $attributes['min'] );
		if ( '' !== $requestedMinimum && 1 !== preg_match( '/^\d+$/D', $requestedMinimum ) ) {
			return '';
		}
		$minimum = '' !== $requestedMinimum
			? absint( $requestedMinimum )
			: (int) $this->settings->get( 'shortcode_min', 0 );
		$threshold = 0 === $minimum ? 1 : $minimum;

		if ( $total < $threshold ) {
			return '';
		}

		$format = '' !== (string) $attributes['format']
			? sanitize_text_field( (string) $attributes['format'] )
			: (string) $this->settings->get( 'shortcode_format', 'この記事は{count}回閲覧されました' );
		$text = strtr(
			$format,
			array(
				'{count}'     => number_format_i18n( $total ),
				'{count_raw}' => (string) $total,
				'{title}'     => get_the_title( $post ),
			)
		);

		return sprintf(
			'<span class="jimmy-pv" data-post-id="%1$d">%2$s</span>',
			$postId,
			esc_html( $text )
		);
	}

	private function totalForPost( int $postId ): int {
		$query = $this->wpdb->prepare(
			"SELECT total_pv FROM {$this->tables->pages()} WHERE page_key = %s AND deleted_at IS NULL LIMIT 1",
			'post:' . $postId
		);

		return max( 0, (int) $this->wpdb->get_var( $query ) );
	}

	private function isPublicPost( WP_Post $post ): bool {
		if ( 'publish' !== $post->post_status || '' !== (string) $post->post_password ) {
			return false;
		}

		$postType = get_post_type_object( $post->post_type );

		return null !== $postType && $postType->public && $postType->publicly_queryable;
	}
}
