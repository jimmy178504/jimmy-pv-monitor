<?php

namespace Jimmy\PVMonitor\Frontend;

use Jimmy\PVMonitor\Pages\PageResolver;
use Jimmy\PVMonitor\Pages\PageTokenService;
use Jimmy\PVMonitor\Pages\TrackingPolicy;

defined( 'ABSPATH' ) || exit;

final class Assets {
	private const SCRIPT_HANDLE = 'jimmy-pv-collector';

	public function __construct(
		private readonly PageResolver $pages,
		private readonly TrackingPolicy $tracking,
		private readonly PageTokenService $tokens
	) {}

	public function register(): void {
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueueCollector' ) );
	}

	public function enqueueCollector(): void {
		$page     = $this->pages->resolveCurrent();
		$decision = $this->tracking->evaluate( $page );
		if ( ! $decision->allowed ) {
			return;
		}

		$config = array(
			'endpoint'      => rest_url( 'jimmy-pv/v1/collect/pageview' ),
			'clickEndpoint' => rest_url( 'jimmy-pv/v1/collect/link-click' ),
			'pageKey'       => $page->pageKey,
			'url'           => $page->canonicalUrl,
			'signature'     => $this->tokens->issue( $page ),
			'homeUrl'       => home_url( '/' ),
		);
		$encoded = wp_json_encode( $config, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
		if ( false === $encoded ) {
			return;
		}

		wp_register_script(
			self::SCRIPT_HANDLE,
			JIMMY_PV_URL . 'assets/js/collector.js',
			array(),
			JIMMY_PV_VERSION,
			array( 'in_footer' => true )
		);
		wp_enqueue_script( self::SCRIPT_HANDLE );
		wp_add_inline_script( self::SCRIPT_HANDLE, 'window.jimmyPvConfig = ' . $encoded . ';', 'before' );
	}
}
