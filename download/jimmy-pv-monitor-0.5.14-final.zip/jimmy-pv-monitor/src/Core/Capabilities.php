<?php

namespace Jimmy\PVMonitor\Core;

defined( 'ABSPATH' ) || exit;

final class Capabilities {
	/** @return string[] */
	public static function all(): array {
		return array(
			'jimmy_pv_view_reports',
			'jimmy_pv_export_data',
			'jimmy_pv_manage_settings',
			'jimmy_pv_delete_data',
		);
	}

	public static function grantToAdministrator(): bool {
		$role = get_role( 'administrator' );
		if ( null === $role ) {
			return false;
		}

		foreach ( self::all() as $capability ) {
			$role->add_cap( $capability );
		}

		return true;
	}

	public static function removeFromAllRoles(): void {
		$roles = wp_roles();
		foreach ( array_keys( $roles->roles ) as $roleName ) {
			$role = get_role( $roleName );
			if ( null === $role ) {
				continue;
			}

			foreach ( self::all() as $capability ) {
				$role->remove_cap( $capability );
			}
		}
	}
}
