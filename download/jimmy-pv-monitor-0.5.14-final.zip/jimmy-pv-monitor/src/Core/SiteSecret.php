<?php

namespace Jimmy\PVMonitor\Core;

defined( 'ABSPATH' ) || exit;

final class SiteSecret {
	public const OPTION_NAME = 'jimmy_pv_site_secret';

	public static function ensure( bool $recordRegeneration = false ): string {
		$existing = get_option( self::OPTION_NAME, '' );
		if ( is_string( $existing ) && self::isValid( $existing ) ) {
			return $existing;
		}

		$secret = base64_encode( random_bytes( 32 ) );
		if ( false === add_option( self::OPTION_NAME, $secret, '', false ) ) {
			update_option( self::OPTION_NAME, $secret, false );
		}

		if ( $recordRegeneration ) {
			update_option( 'jimmy_pv_secret_regenerated_at', gmdate( 'Y-m-d H:i:s' ), false );
		}

		return $secret;
	}

	public static function bytes( bool $recordRegeneration = false ): string {
		$encoded = self::ensure( $recordRegeneration );
		$decoded = base64_decode( $encoded, true );

		return false !== $decoded ? $decoded : $encoded;
	}

	private static function isValid( string $secret ): bool {
		$decoded = base64_decode( $secret, true );

		return false !== $decoded && 32 === strlen( $decoded );
	}
}
