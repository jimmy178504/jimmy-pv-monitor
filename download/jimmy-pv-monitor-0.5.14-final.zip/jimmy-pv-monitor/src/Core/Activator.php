<?php

namespace Jimmy\PVMonitor\Core;

use Jimmy\PVMonitor\Database\Migrator;
use Jimmy\PVMonitor\Database\Schema;
use Jimmy\PVMonitor\Database\SchemaVerifier;
use Jimmy\PVMonitor\Database\TableNames;
use Jimmy\PVMonitor\Maintenance\OptionLock;
use Jimmy\PVMonitor\Maintenance\Scheduler;
use Jimmy\PVMonitor\Settings\SettingsRepository;

defined( 'ABSPATH' ) || exit;

final class Activator {
	public static function activate( bool $networkWide = false ): void {
		if ( $networkWide || is_multisite() ) {
			self::abort( __( 'Jimmy PV Monitorは現在マルチサイトに対応していません。', 'jimmy-pv-monitor' ) );
		}

		$requirements = Requirements::check();
		if ( ! $requirements->isSupported() ) {
			self::abort( __( 'Jimmy PV Monitorの動作要件を満たしていません。PHP、WordPress、データベースのバージョンを確認してください。', 'jimmy-pv-monitor' ) );
		}

		global $wpdb;

		SettingsRepository::installDefaults();
		SiteSecret::ensure();

		$tables   = new TableNames( $wpdb );
		$schema   = new Schema( $wpdb, $tables );
		$verifier = new SchemaVerifier( $wpdb, $tables );
		$migrator = new Migrator( $schema, $verifier, new OptionLock( 'jimmy_pv_schema_lock', 5 * MINUTE_IN_SECONDS ) );
		$result   = $migrator->migrate();

		if ( ! $result->isSuccessful() ) {
			self::abort( __( 'Jimmy PV Monitorのデータベースを作成できませんでした。データベース権限を確認してください。', 'jimmy-pv-monitor' ) );
		}

		if ( ! Capabilities::grantToAdministrator() ) {
			self::abort( __( 'Jimmy PV Monitorの管理権限を登録できませんでした。', 'jimmy-pv-monitor' ) );
		}

		Scheduler::ensureScheduled();
		add_option( 'jimmy_pv_installed_at', gmdate( 'Y-m-d H:i:s' ), '', false );
		add_option( 'jimmy_pv_report_cache_generation', 1, '', false );
		update_option( 'jimmy_pv_version', JIMMY_PV_VERSION, false );
	}

	private static function abort( string $message ): void {
		if ( function_exists( 'deactivate_plugins' ) && defined( 'JIMMY_PV_BASENAME' ) ) {
			deactivate_plugins( JIMMY_PV_BASENAME );
		}

		wp_die(
			esc_html( $message ),
			esc_html__( 'Jimmy PV Monitorを有効化できません', 'jimmy-pv-monitor' ),
			array( 'back_link' => true )
		);
	}
}
