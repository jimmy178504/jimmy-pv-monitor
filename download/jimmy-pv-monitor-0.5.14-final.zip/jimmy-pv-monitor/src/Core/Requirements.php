<?php

namespace Jimmy\PVMonitor\Core;

use wpdb;

defined( 'ABSPATH' ) || exit;

final class Requirements {
	private const MINIMUM_PHP       = '8.1';
	private const MINIMUM_WORDPRESS = '6.7';
	private const MINIMUM_MYSQL     = '5.7';
	private const MINIMUM_MARIADB   = '10.4';

	public static function check(): RequirementResult {
		global $wpdb, $wp_version;

		$errors     = array();
		$warnings   = array();
		$serverInfo = self::databaseServerInfo( $wpdb );
		$dbVersion  = self::extractVersion( $serverInfo, $wpdb->db_version() );
		$isMariaDb  = false !== stripos( $serverInfo, 'mariadb' );
		$minimumDb  = $isMariaDb ? self::MINIMUM_MARIADB : self::MINIMUM_MYSQL;

		if ( version_compare( PHP_VERSION, self::MINIMUM_PHP, '<' ) ) {
			$errors[] = 'requirements.php_version';
		}

		if ( version_compare( (string) $wp_version, self::MINIMUM_WORDPRESS, '<' ) ) {
			$errors[] = 'requirements.wp_version';
		}

		if ( version_compare( $dbVersion, $minimumDb, '<' ) ) {
			$errors[] = 'requirements.db_version';
		}

		if ( is_multisite() ) {
			$errors[] = 'requirements.multisite';
		}

		if ( ! function_exists( 'hash_hmac' ) || ! function_exists( 'random_bytes' ) ) {
			$errors[] = 'requirements.crypto';
		}

		if ( ! is_ssl() ) {
			$warnings[] = 'requirements.https_recommended';
		}

		return new RequirementResult(
			array_values( array_unique( $errors ) ),
			array_values( array_unique( $warnings ) ),
			array(
				'php'       => PHP_VERSION,
				'wordpress' => (string) $wp_version,
				'database'  => $dbVersion,
				'db_type'   => $isMariaDb ? 'MariaDB' : 'MySQL',
			)
		);
	}

	private static function databaseServerInfo( wpdb $wpdb ): string {
		if ( method_exists( $wpdb, 'db_server_info' ) ) {
			return (string) $wpdb->db_server_info();
		}

			// phpcs:ignore WordPress.DB.DirectDatabaseQuery.DirectQuery,WordPress.DB.DirectDatabaseQuery.NoCaching -- A live server version is required for activation compatibility checks.
			$serverInfo = $wpdb->get_var( 'SELECT VERSION()' );

		return is_string( $serverInfo ) ? $serverInfo : (string) $wpdb->db_version();
	}

	private static function extractVersion( string $serverInfo, string $fallback ): string {
		if ( preg_match( '/\d+(?:\.\d+){1,3}/', $serverInfo, $matches ) ) {
			return $matches[0];
		}

		return $fallback;
	}
}
