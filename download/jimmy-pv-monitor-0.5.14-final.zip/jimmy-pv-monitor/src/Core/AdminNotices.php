<?php

namespace Jimmy\PVMonitor\Core;

use Jimmy\PVMonitor\Database\Migrator;
use Jimmy\PVMonitor\Maintenance\Scheduler;

defined( 'ABSPATH' ) || exit;

final class AdminNotices {
	public function __construct( private readonly RequirementResult $requirements ) {}

	public function register(): void {
		add_action( 'admin_notices', array( $this, 'render' ) );
	}

	public function render(): void {
		if ( ! current_user_can( 'jimmy_pv_manage_settings' ) && ! current_user_can( 'manage_options' ) ) {
			return;
		}

		if ( ! $this->requirements->isSupported() ) {
			$this->notice( 'error', __( 'Jimmy PV Monitorは現在の動作環境に対応していないため停止しています。', 'jimmy-pv-monitor' ) );
		}

		if ( false !== get_option( Migrator::ERROR_OPTION, false ) ) {
			$this->notice( 'error', __( 'Jimmy PV Monitorのデータベース更新に失敗しました。プラグインを再有効化して再試行してください。', 'jimmy-pv-monitor' ) );
		}

		if ( false !== get_option( Scheduler::ERROR_OPTION, false ) ) {
			$this->notice( 'warning', __( 'Jimmy PV Monitorの日次保守処理を予約できませんでした。WP-Cronの設定を確認してください。', 'jimmy-pv-monitor' ) );
		}

		if ( $this->maintenanceIsStale() ) {
			$this->notice( 'warning', __( 'Jimmy PV Monitorの日次保守処理が48時間以上実行されていません。WP-Cronの設定を確認してください。', 'jimmy-pv-monitor' ) );
		}

		if ( false !== get_option( 'jimmy_pv_secret_regenerated_at', false ) ) {
			$this->notice( 'warning', __( 'Jimmy PV Monitorのサイト秘密値を再生成しました。古いページキャッシュでは一時的に計測できない場合があります。', 'jimmy-pv-monitor' ) );
			delete_option( 'jimmy_pv_secret_regenerated_at' );
		}
	}

	private function maintenanceIsStale(): bool {
		$reference = get_option( 'jimmy_pv_last_maintenance', get_option( 'jimmy_pv_installed_at', '' ) );
		if ( ! is_string( $reference ) || '' === $reference ) {
			return false;
		}

		$timestamp = strtotime( $reference . ' UTC' );

		return false !== $timestamp && 48 * HOUR_IN_SECONDS < time() - $timestamp;
	}

	private function notice( string $type, string $message ): void {
		printf(
			'<div class="notice notice-%1$s"><p>%2$s</p></div>',
			esc_attr( $type ),
			esc_html( $message )
		);
	}
}
