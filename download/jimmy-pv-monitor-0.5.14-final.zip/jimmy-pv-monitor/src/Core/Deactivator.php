<?php

namespace Jimmy\PVMonitor\Core;

use Jimmy\PVMonitor\Maintenance\Scheduler;

defined( 'ABSPATH' ) || exit;

final class Deactivator {
	public static function deactivate(): void {
		Scheduler::unschedule();
		delete_option( 'jimmy_pv_schema_lock' );
		delete_option( 'jimmy_pv_maintenance_lock' );
		delete_option( 'jimmy_pv_link_index_lock' );

		do_action( 'jimmy_pv_deactivated' );
	}
}
