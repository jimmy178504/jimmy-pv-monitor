<?php

namespace Jimmy\PVMonitor\Core;

defined( 'ABSPATH' ) || exit;

final class RequirementResult {
	/**
	 * @param string[]              $errors
	 * @param string[]              $warnings
	 * @param array<string, string> $detected
	 */
	public function __construct(
		private readonly array $errors,
		private readonly array $warnings,
		private readonly array $detected
	) {}

	public function isSupported(): bool {
		return array() === $this->errors;
	}

	/** @return string[] */
	public function errors(): array {
		return $this->errors;
	}

	/** @return string[] */
	public function warnings(): array {
		return $this->warnings;
	}

	/** @return array<string, string> */
	public function detected(): array {
		return $this->detected;
	}
}
