<?php

namespace Jimmy\PVMonitor\Core;

defined( 'ABSPATH' ) || exit;

use Jimmy\PVMonitor\Admin\Assets as AdminAssets;
use Jimmy\PVMonitor\Admin\CsvExporter;
use Jimmy\PVMonitor\Admin\CsvSanitizer;
use Jimmy\PVMonitor\Admin\DashboardPage;
use Jimmy\PVMonitor\Admin\DashboardWidget;
use Jimmy\PVMonitor\Admin\DataResetter;
use Jimmy\PVMonitor\Admin\ExportPage;
use Jimmy\PVMonitor\Admin\LinksPage;
use Jimmy\PVMonitor\Admin\Menu;
use Jimmy\PVMonitor\Admin\PagesPage;
use Jimmy\PVMonitor\Admin\PeriodSelector;
use Jimmy\PVMonitor\Admin\ReferrersPage;
use Jimmy\PVMonitor\Admin\SettingsPage;
use Jimmy\PVMonitor\Collection\Collector;
use Jimmy\PVMonitor\Collection\EventDeduplicator;
use Jimmy\PVMonitor\Collection\PageviewController;
use Jimmy\PVMonitor\Collection\PageviewRepository;
use Jimmy\PVMonitor\Collection\RateLimiter;
use Jimmy\PVMonitor\Database\Migrator;
use Jimmy\PVMonitor\Database\Schema;
use Jimmy\PVMonitor\Database\SchemaVerifier;
use Jimmy\PVMonitor\Database\TableNames;
use Jimmy\PVMonitor\Frontend\Assets as FrontendAssets;
use Jimmy\PVMonitor\Frontend\Shortcode;
use Jimmy\PVMonitor\Inflow\CampaignParser;
use Jimmy\PVMonitor\Inflow\InflowRepository;
use Jimmy\PVMonitor\Inflow\ReferrerNormalizer;
use Jimmy\PVMonitor\Inflow\SourceClassifier;
use Jimmy\PVMonitor\Links\ContentDecorator;
use Jimmy\PVMonitor\Links\LinkClickController;
use Jimmy\PVMonitor\Links\LinkIndexBatch;
use Jimmy\PVMonitor\Links\LinkIndexer;
use Jimmy\PVMonitor\Links\LinkMetricsRepository;
use Jimmy\PVMonitor\Links\LinkRepository;
use Jimmy\PVMonitor\Links\LinkUrlResolver;
use Jimmy\PVMonitor\Maintenance\DailyMaintenance;
use Jimmy\PVMonitor\Maintenance\OptionLock;
use Jimmy\PVMonitor\Maintenance\Scheduler;
use Jimmy\PVMonitor\Pages\CollectionPageResolver;
use Jimmy\PVMonitor\Pages\PageResolver;
use Jimmy\PVMonitor\Pages\PageTokenService;
use Jimmy\PVMonitor\Pages\PostDeletion;
use Jimmy\PVMonitor\Pages\TrackingPolicy;
use Jimmy\PVMonitor\Pages\UrlNormalizer;
use Jimmy\PVMonitor\Reporting\AnalyticsRepository;
use Jimmy\PVMonitor\Reporting\DateRangeFactory;
use Jimmy\PVMonitor\Settings\SettingsRepository;
use Jimmy\PVMonitor\Settings\SettingsSanitizer;

final class Plugin {
	private static bool $booted = false;

	public static function boot(): void {
		if ( self::$booted ) {
			return;
		}
		self::$booted = true;

		$requirements = Requirements::check();
		$notices      = new AdminNotices( $requirements );
		$notices->register();

		if ( ! $requirements->isSupported() ) {
			return;
		}

		global $wpdb;

		$settings = new SettingsRepository( new SettingsSanitizer() );
		$tables   = new TableNames( $wpdb );
		$schema   = new Schema( $wpdb, $tables );
		$verifier = new SchemaVerifier( $wpdb, $tables );
		$migrator = new Migrator( $schema, $verifier, new OptionLock( 'jimmy_pv_schema_lock', 5 * MINUTE_IN_SECONDS ) );

		if ( $migrator->needsMigration() && ! $migrator->migrate()->isSuccessful() ) {
			return;
		}

		SiteSecret::ensure( true );
		update_option( 'jimmy_pv_version', JIMMY_PV_VERSION, false );

		$urlNormalizer     = new UrlNormalizer();
		$pageResolver      = new PageResolver( $settings, $urlNormalizer );
		$collectionPages   = new CollectionPageResolver( $pageResolver, $urlNormalizer );
		$tracking          = new TrackingPolicy( $settings );
		$tokens            = new PageTokenService();
		$pageviews         = new PageviewRepository( $wpdb, $tables );
		$inflow            = new InflowRepository( $wpdb, $tables );
		$linkMetrics       = new LinkMetricsRepository( $wpdb, $tables );
		$linkRepository    = new LinkRepository( $wpdb, $tables );
		$linkTargets       = new LinkUrlResolver( $urlNormalizer, $settings );
		$referrers         = new ReferrerNormalizer( $settings, new SourceClassifier( $urlNormalizer ) );
		$campaigns         = new CampaignParser();
		$collector         = new Collector( $pageviews, $inflow, $linkMetrics );
		$deduplicator      = new EventDeduplicator( $wpdb, $tables );
		$rateLimiter       = new RateLimiter( $wpdb, $tables );
		$pageviewController = new PageviewController(
			$collectionPages,
			$tracking,
			$tokens,
			$urlNormalizer,
			$rateLimiter,
			$deduplicator,
			$collector,
			$referrers,
			$campaigns
		);
		add_action( 'rest_api_init', array( $pageviewController, 'register' ) );

		$linkClickController = new LinkClickController(
			$pageResolver,
			$tracking,
			$tokens,
			$urlNormalizer,
			$rateLimiter,
			$deduplicator,
			$linkMetrics,
			$linkRepository,
			$linkTargets
		);
		add_action( 'rest_api_init', array( $linkClickController, 'register' ) );

		$linkIndexer    = new LinkIndexer( $pageResolver, $urlNormalizer, $linkTargets, $linkRepository );
		$linkIndexer->register();
		$linkDecorator = new ContentDecorator( $linkRepository, $linkTargets, $urlNormalizer );
		$linkDecorator->register();
		$linkBatch = new LinkIndexBatch(
			$wpdb,
			$linkIndexer,
			new OptionLock( 'jimmy_pv_link_index_lock', 10 * MINUTE_IN_SECONDS )
		);
		$linkBatch->register();
		$linkBatch->ensureScheduled();

		$assets = new FrontendAssets( $pageResolver, $tracking, $tokens );
		$assets->register();

		$shortcode = new Shortcode( $wpdb, $tables, $settings );
		add_action( 'init', array( $shortcode, 'register' ) );

		$analytics     = new AnalyticsRepository( $wpdb, $tables );
		$dateRanges    = new DateRangeFactory( $settings );
		$periods       = new PeriodSelector();
		$dashboardPage = new DashboardPage( $analytics, $dateRanges, $periods );
		$pagesPage     = new PagesPage( $analytics, $dateRanges, $settings );
		$referrersPage = new ReferrersPage( $analytics, $dateRanges, $periods );
		$linksPage     = new LinksPage( $analytics, $dateRanges, $linkBatch );
		$exportPage    = new ExportPage( $dateRanges );
		$settingsPage  = new SettingsPage( $settings, new DataResetter( $wpdb, $tables ) );
		$menu          = new Menu( $dashboardPage, $pagesPage, $referrersPage, $linksPage, $exportPage, $settingsPage );
		$menu->register();
		$linksPage->register();
		$settingsPage->register();

		$adminAssets = new AdminAssets();
		$adminAssets->register();

		$csvExporter = new CsvExporter( $analytics, $dateRanges, new CsvSanitizer(), $settings );
		$csvExporter->register();

		$dashboardWidget = new DashboardWidget( $analytics, $dateRanges, $settings );
		$dashboardWidget->register();

		$maintenance = new DailyMaintenance(
			$wpdb,
			$tables,
			$settings,
			new OptionLock( 'jimmy_pv_maintenance_lock', 10 * MINUTE_IN_SECONDS )
		);
		Scheduler::register( $maintenance );
		Scheduler::ensureScheduled();

		$postDeletion = new PostDeletion( $wpdb, $tables );
		add_action( 'before_delete_post', array( $postDeletion, 'markDeleted' ) );
		add_action( 'admin_init', array( Privacy::class, 'registerPolicyText' ) );

		do_action( 'jimmy_pv_loaded', JIMMY_PV_API_VERSION );
	}
}
