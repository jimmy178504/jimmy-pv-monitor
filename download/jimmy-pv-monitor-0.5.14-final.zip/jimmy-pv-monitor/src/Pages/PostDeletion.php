<?php

namespace Jimmy\PVMonitor\Pages;

use Jimmy\PVMonitor\Database\TableNames;
use wpdb;

defined( 'ABSPATH' ) || exit;

final class PostDeletion {
	public function __construct(
		private readonly wpdb $wpdb,
		private readonly TableNames $tables
	) {}

	public function markDeleted( int $postId ): void {
		$this->wpdb->update(
			$this->tables->pages(),
			array(
				'deleted_at' => gmdate( 'Y-m-d H:i:s' ),
				'updated_at' => gmdate( 'Y-m-d H:i:s' ),
			),
			array(
				'object_type' => 'post',
				'object_id'   => $postId,
			),
			array( '%s', '%s' ),
			array( '%s', '%d' )
		);
	}
}
