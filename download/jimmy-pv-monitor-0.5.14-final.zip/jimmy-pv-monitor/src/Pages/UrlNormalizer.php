<?php

namespace Jimmy\PVMonitor\Pages;

defined( 'ABSPATH' ) || exit;

final class UrlNormalizer {
	private const MAX_URL_LENGTH = 2048;

	/**
	 * @param string[] $sensitiveKeys
	 */
	public function normalize( string $url, bool $includeQuery = false, array $sensitiveKeys = array() ): ?string {
		$url = trim( $url );
		if ( '' === $url || self::MAX_URL_LENGTH < strlen( $url ) || preg_match( '/[\x00-\x1F\x7F]/', $url ) ) {
			return null;
		}

		$url   = $this->makeAbsolute( $url );
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) ) {
			return null;
		}

		$scheme = strtolower( (string) ( $parts['scheme'] ?? '' ) );
		$host   = strtolower( rtrim( (string) ( $parts['host'] ?? '' ), '.' ) );
		if ( ! in_array( $scheme, array( 'http', 'https' ), true ) || '' === $host ) {
			return null;
		}

		$port = isset( $parts['port'] ) ? (int) $parts['port'] : null;
		if ( ( 'http' === $scheme && 80 === $port ) || ( 'https' === $scheme && 443 === $port ) ) {
			$port = null;
		}

		$path = (string) ( $parts['path'] ?? '/' );
		$path = '' === $path ? '/' : '/' . ltrim( $path, '/' );
		$hostForUrl = str_contains( $host, ':' ) ? '[' . trim( $host, '[]' ) . ']' : $host;
		$normalized = $scheme . '://' . $hostForUrl . ( null !== $port ? ':' . $port : '' ) . $path;

		if ( $includeQuery && isset( $parts['query'] ) && '' !== $parts['query'] ) {
			$query = $this->normalizeQuery( (string) $parts['query'], $sensitiveKeys );
			if ( '' !== $query ) {
				$normalized .= '?' . $query;
			}
		}

		return self::MAX_URL_LENGTH >= strlen( $normalized ) ? $normalized : null;
	}

	public function hash( string $normalizedUrl ): string {
		return hash( 'sha256', $normalizedUrl );
	}

	public function isInternal( string $url ): bool {
		$normalized = $this->normalize( $url, true );
		$home       = $this->normalize( home_url( '/' ), false );
		if ( null === $normalized || null === $home ) {
			return false;
		}

		$urlParts  = wp_parse_url( $normalized );
		$homeParts = wp_parse_url( $home );
		if ( ! is_array( $urlParts ) || ! is_array( $homeParts ) ) {
			return false;
		}

		if ( strtolower( (string) $urlParts['host'] ) !== strtolower( (string) $homeParts['host'] ) ) {
			return false;
		}

		$urlPort  = (int) ( $urlParts['port'] ?? 0 );
		$homePort = (int) ( $homeParts['port'] ?? 0 );
		if ( $urlPort !== $homePort ) {
			return false;
		}

		$basePath = rtrim( (string) ( $homeParts['path'] ?? '/' ), '/' );
		$urlPath  = (string) ( $urlParts['path'] ?? '/' );
		if ( '' === $basePath ) {
			return true;
		}

		return $urlPath === $basePath || str_starts_with( $urlPath, $basePath . '/' );
	}

	public function isSameOrigin( string $url ): bool {
		$normalized = $this->normalize( $url, false );
		$home       = $this->normalize( home_url( '/' ), false );
		if ( null === $normalized || null === $home ) {
			return false;
		}

		$urlParts  = wp_parse_url( $normalized );
		$homeParts = wp_parse_url( $home );
		if ( ! is_array( $urlParts ) || ! is_array( $homeParts ) ) {
			return false;
		}

		return strtolower( (string) ( $urlParts['scheme'] ?? '' ) ) === strtolower( (string) ( $homeParts['scheme'] ?? '' ) )
			&& strtolower( (string) ( $urlParts['host'] ?? '' ) ) === strtolower( (string) ( $homeParts['host'] ?? '' ) )
			&& (int) ( $urlParts['port'] ?? 0 ) === (int) ( $homeParts['port'] ?? 0 );
	}

	private function makeAbsolute( string $url ): string {
		if ( str_starts_with( $url, '//' ) ) {
			$homeScheme = (string) wp_parse_url( home_url( '/' ), PHP_URL_SCHEME );

			return ( '' !== $homeScheme ? $homeScheme : 'https' ) . ':' . $url;
		}

		if ( preg_match( '#^https?://#i', $url ) ) {
			return $url;
		}

		if ( str_starts_with( $url, '/' ) ) {
			$home = wp_parse_url( home_url( '/' ) );
			if ( ! is_array( $home ) ) {
				return $url;
			}

			$scheme = (string) ( $home['scheme'] ?? 'https' );
			$host   = (string) ( $home['host'] ?? '' );
			$port   = isset( $home['port'] ) ? ':' . (int) $home['port'] : '';

			return $scheme . '://' . $host . $port . $url;
		}

		return home_url( '/' . ltrim( $url, '/' ) );
	}

	/** @param string[] $sensitiveKeys */
	private function normalizeQuery( string $query, array $sensitiveKeys ): string {
		$sensitiveLookup = array_fill_keys( array_map( 'strtolower', $sensitiveKeys ), true );
		$normalizedPairs = array();

		foreach ( explode( '&', $query ) as $pair ) {
			if ( '' === $pair ) {
				continue;
			}

			$parts = explode( '=', $pair, 2 );
			$key   = rawurldecode( str_replace( '+', ' ', $parts[0] ) );
			if ( '' === $key || $this->isSensitiveQueryKey( $key, $sensitiveLookup ) ) {
				continue;
			}

			$value = isset( $parts[1] ) ? rawurldecode( str_replace( '+', ' ', $parts[1] ) ) : null;
			$encoded = rawurlencode( $key );
			if ( null !== $value ) {
				$encoded .= '=' . rawurlencode( $value );
			}
			$normalizedPairs[] = $encoded;
		}

		sort( $normalizedPairs, SORT_STRING );

		return implode( '&', $normalizedPairs );
	}

	/** @param array<string, bool> $lookup */
	private function isSensitiveQueryKey( string $key, array $lookup ): bool {
		$segments = preg_split( '/[\[\]]+/', strtolower( $key ), -1, PREG_SPLIT_NO_EMPTY );
		$segments = is_array( $segments ) ? $segments : array();
		foreach ( $segments as $segment ) {
			if ( isset( $lookup[ $segment ] ) ) {
				return true;
			}
		}

		return false;
	}
}
