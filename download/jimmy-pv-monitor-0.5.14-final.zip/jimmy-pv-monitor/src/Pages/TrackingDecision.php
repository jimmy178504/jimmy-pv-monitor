<?php

namespace Jimmy\PVMonitor\Pages;

defined( 'ABSPATH' ) || exit;

final class TrackingDecision {
	public function __construct(
		public readonly bool $allowed,
		public readonly string $reason
	) {}
}
