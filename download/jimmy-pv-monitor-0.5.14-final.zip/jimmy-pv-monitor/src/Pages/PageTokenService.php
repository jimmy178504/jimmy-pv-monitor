<?php

namespace Jimmy\PVMonitor\Pages;

use Jimmy\PVMonitor\Core\SiteSecret;

defined( 'ABSPATH' ) || exit;

final class PageTokenService {
	public function issue( ResolvedPage $page ): string {
		if ( ! $page->isTrackable ) {
			return '';
		}

		$secret = $this->decodedSecret();
		$binary = hash_hmac( 'sha256', $this->input( $page ), $secret, true );

		return rtrim( strtr( base64_encode( $binary ), '+/', '-_' ), '=' );
	}

	public function verify( ResolvedPage $page, string $signature ): bool {
		if ( '' === $signature || 128 < strlen( $signature ) || ! preg_match( '/^[A-Za-z0-9_-]+$/D', $signature ) ) {
			return false;
		}

		return hash_equals( $this->issue( $page ), $signature );
	}

	private function input( ResolvedPage $page ): string {
		$homeHash = hash( 'sha256', untrailingslashit( home_url( '/' ) ) );

		return 'v1|' . $page->pageKey . '|' . $page->canonicalHash . '|' . $homeHash;
	}

	private function decodedSecret(): string {
		return SiteSecret::bytes( true );
	}
}
