<?php

namespace Jimmy\PVMonitor\Pages;

defined( 'ABSPATH' ) || exit;

final class CollectionPageResolver {
	public function __construct(
		private readonly PageResolver $resolver,
		private readonly UrlNormalizer $normalizer
	) {}

	public function resolve( string $pageKey, string $url ): ResolvedPage {
		if ( preg_match( '/^post:(\d+)$/D', $pageKey, $matches ) ) {
			return $this->validateCanonicalUrl( $this->resolver->resolvePostById( (int) $matches[1] ), $url );
		}

		if ( 'special:home' === $pageKey ) {
			return $this->validateCanonicalUrl( $this->resolver->resolveHome(), $url );
		}

		if ( 'special:search' === $pageKey ) {
			$home = $this->normalizer->normalize( home_url( '/' ), false );
			if ( null === $home || ! $this->normalizer->isInternal( $url ) ) {
				return ResolvedPage::excluded( 'invalid_url' );
			}

			return new ResolvedPage(
				'special:search',
				'search',
				null,
				$home,
				$this->normalizer->hash( $home ),
				__( 'サイト内検索', 'jimmy-pv-monitor' ),
				true
			);
		}

		foreach ( array( 'archive', 'search', '404' ) as $type ) {
			if ( str_starts_with( $pageKey, $type . ':' ) ) {
				$titles = array(
					'archive' => __( 'アーカイブ', 'jimmy-pv-monitor' ),
					'search'  => __( 'サイト内検索', 'jimmy-pv-monitor' ),
					'404'     => __( '404ページ', 'jimmy-pv-monitor' ),
				);
				$page = $this->resolver->resolveSpecialUrl( $type, $url, $titles[ $type ] );

				return $page->isTrackable && hash_equals( $page->pageKey, $pageKey )
					? $page
					: ResolvedPage::excluded( 'page_key_mismatch' );
			}
		}

		return ResolvedPage::excluded( 'invalid_page_key' );
	}

	private function validateCanonicalUrl( ResolvedPage $page, string $url ): ResolvedPage {
		$normalized = $this->normalizer->normalize( $url, false );
		if ( ! $page->isTrackable || null === $normalized || ! hash_equals( $page->canonicalHash, $this->normalizer->hash( $normalized ) ) ) {
			return ResolvedPage::excluded( 'canonical_url_mismatch' );
		}

		return $page;
	}
}
