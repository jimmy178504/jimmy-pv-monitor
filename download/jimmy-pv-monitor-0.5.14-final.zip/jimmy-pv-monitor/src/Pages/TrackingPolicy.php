<?php

namespace Jimmy\PVMonitor\Pages;

use Jimmy\PVMonitor\Settings\SettingsRepository;
use WP_User;

defined( 'ABSPATH' ) || exit;

final class TrackingPolicy {
	private const KNOWN_BOT_PATTERNS = array(
		'bot',
		'crawler',
		'spider',
		'slurp',
		'bingpreview',
		'facebookexternalhit',
		'whatsapp',
		'headlesschrome',
		'uptimerobot',
		'pingdom',
		'curl/',
		'wget/',
	);

	public function __construct( private readonly SettingsRepository $settings ) {}

	public function evaluate( ResolvedPage $page, ?WP_User $user = null, ?string $userAgent = null ): TrackingDecision {
		if ( ! (bool) $this->settings->get( 'tracking_enabled', true ) ) {
			return new TrackingDecision( false, 'tracking_disabled' );
		}

		if ( ! $page->isTrackable ) {
			return new TrackingDecision( false, $page->exclusionReason ?? 'unsupported_request' );
		}

		if ( ! $this->pageTypeEnabled( $page ) ) {
			return new TrackingDecision( false, 'disabled_page_type' );
		}

		$user = $user ?? wp_get_current_user();
		$excludedRoles = (array) $this->settings->get( 'excluded_roles', array( 'administrator' ) );
		if ( array_intersect( $user->roles, $excludedRoles ) ) {
			return new TrackingDecision( false, 'excluded_role' );
		}

			$userAgent = null !== $userAgent
				? $userAgent
				: ( isset( $_SERVER['HTTP_USER_AGENT'] ) ? sanitize_text_field( wp_unslash( (string) $_SERVER['HTTP_USER_AGENT'] ) ) : '' );
		$userAgent = substr( sanitize_text_field( $userAgent ), 0, 512 );

		if ( '' === $userAgent && (bool) $this->settings->get( 'exclude_empty_user_agent', true ) ) {
			return new TrackingDecision( false, 'empty_user_agent' );
		}

		$lowerUserAgent = strtolower( $userAgent );
		foreach ( self::KNOWN_BOT_PATTERNS as $pattern ) {
			if ( str_contains( $lowerUserAgent, $pattern ) ) {
				return new TrackingDecision( false, 'known_bot' );
			}
		}

		foreach ( (array) $this->settings->get( 'custom_bot_patterns', array() ) as $pattern ) {
			if ( '' !== $pattern && str_contains( $lowerUserAgent, strtolower( (string) $pattern ) ) ) {
				return new TrackingDecision( false, 'custom_bot' );
			}
		}

		if ( null !== $page->objectId && in_array( $page->objectId, (array) $this->settings->get( 'excluded_post_ids', array() ), true ) ) {
			return new TrackingDecision( false, 'excluded_post' );
		}

		foreach ( (array) $this->settings->get( 'excluded_url_patterns', array() ) as $pattern ) {
			if ( $this->matchesUrlPattern( $page->canonicalUrl, (string) $pattern ) ) {
				return new TrackingDecision( false, 'excluded_url' );
			}
		}

		return new TrackingDecision( true, 'allowed' );
	}

	private function pageTypeEnabled( ResolvedPage $page ): bool {
		return match ( $page->objectType ) {
			'home'    => (bool) $this->settings->get( 'track_home', true ),
			'archive' => (bool) $this->settings->get( 'track_archives', true ),
			'search'  => (bool) $this->settings->get( 'track_search', true ),
			'404'     => (bool) $this->settings->get( 'track_404', false ),
			'post'    => $this->postTypeEnabled( $page->objectId ),
			default   => false,
		};
	}

	private function postTypeEnabled( ?int $postId ): bool {
		if ( null === $postId ) {
			return false;
		}

		$postType = get_post_type( $postId );
		if ( ! is_string( $postType ) || in_array( $postType, (array) $this->settings->get( 'excluded_post_types', array() ), true ) ) {
			return false;
		}

		if (
			'selected' === $this->settings->get( 'post_type_mode', 'all_public' )
			&& ! in_array( $postType, (array) $this->settings->get( 'included_post_types', array( 'post', 'page' ) ), true )
		) {
			return false;
		}

		$postTypeObject = get_post_type_object( $postType );

		return null !== $postTypeObject && $postTypeObject->public && $postTypeObject->publicly_queryable;
	}

	private function matchesUrlPattern( string $url, string $pattern ): bool {
		if ( '' === $pattern ) {
			return false;
		}

		$quoted = preg_quote( $pattern, '#' );
		$regex  = '#^' . str_replace( '\\*', '.*', $quoted ) . '$#iu';

		return 1 === preg_match( $regex, $url );
	}
}
