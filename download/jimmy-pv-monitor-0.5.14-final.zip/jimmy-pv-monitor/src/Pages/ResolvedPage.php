<?php

namespace Jimmy\PVMonitor\Pages;

defined( 'ABSPATH' ) || exit;

final class ResolvedPage {
	public function __construct(
		public readonly string $pageKey,
		public readonly string $objectType,
		public readonly ?int $objectId,
		public readonly string $canonicalUrl,
		public readonly string $canonicalHash,
		public readonly string $title,
		public readonly bool $isTrackable,
		public readonly ?string $exclusionReason = null
	) {}

	public static function excluded( string $reason ): self {
		return new self( '', 'excluded', null, '', '', '', false, $reason );
	}
}
