<?php

namespace Jimmy\PVMonitor\Pages;

use Jimmy\PVMonitor\Settings\SettingsRepository;
use WP_Post;

defined( 'ABSPATH' ) || exit;

final class PageResolver {
	public function __construct(
		private readonly SettingsRepository $settings,
		private readonly UrlNormalizer $normalizer
	) {}

	public function resolveCurrent(): ResolvedPage {
		if ( is_admin() || wp_doing_ajax() || wp_doing_cron() || $this->isRestRequest() || is_feed() || is_preview() ) {
			return ResolvedPage::excluded( 'unsupported_request' );
		}

		if ( is_front_page() ) {
			return $this->resolveHome();
		}

		if ( is_singular() ) {
			return $this->resolvePostById( (int) get_queried_object_id() );
		}

		if ( is_search() ) {
			if ( ! (bool) $this->settings->get( 'distinguish_query_strings', false ) ) {
				$url = $this->normalizer->normalize( home_url( '/' ), false );

				return $this->resolved( 'special:search', 'search', null, $url, __( 'サイト内検索', 'jimmy-pv-monitor' ) );
			}

			return $this->resolveSpecialUrl( 'search', $this->currentUrl(), __( 'サイト内検索', 'jimmy-pv-monitor' ) );
		}

		if ( is_archive() || is_home() ) {
			return $this->resolveSpecialUrl( 'archive', $this->currentUrl(), wp_get_document_title() );
		}

		if ( is_404() ) {
			return $this->resolveSpecialUrl( '404', $this->currentUrl(), __( '404ページ', 'jimmy-pv-monitor' ) );
		}

		return ResolvedPage::excluded( 'unsupported_request' );
	}

	public function resolveHome(): ResolvedPage {
		$url = $this->normalizer->normalize( home_url( '/' ), false );

		return $this->resolved( 'special:home', 'home', null, $url, get_bloginfo( 'name' ) );
	}

	public function resolvePostById( int $postId ): ResolvedPage {
		$post = get_post( $postId );
		if ( ! $post instanceof WP_Post || 'publish' !== $post->post_status || '' !== (string) $post->post_password ) {
			return ResolvedPage::excluded( 'unpublished_post' );
		}

		$postType = get_post_type_object( $post->post_type );
		if ( null === $postType || ! $postType->public || ! $postType->publicly_queryable ) {
			return ResolvedPage::excluded( 'unsupported_post_type' );
		}

		$url = wp_get_canonical_url( $postId );
		$url = is_string( $url ) && '' !== $url ? $url : get_permalink( $postId );
		$url = is_string( $url ) ? $this->normalizer->normalize( $url, false ) : null;

		return $this->resolved(
			'post:' . $postId,
			'post',
			$postId,
			$url,
			get_the_title( $post )
		);
	}

	public function resolveSpecialUrl( string $type, string $url, string $title ): ResolvedPage {
		$includeQuery = (bool) $this->settings->get( 'distinguish_query_strings', false );
		$sensitive    = (array) $this->settings->get( 'sensitive_query_keys', array() );
		$normalized   = $this->normalizer->normalize( $url, $includeQuery, $sensitive );
		if ( null === $normalized || ! $this->normalizer->isInternal( $normalized ) ) {
			return ResolvedPage::excluded( 'invalid_url' );
		}

		return $this->resolved(
			$type . ':' . $this->normalizer->hash( $normalized ),
			$type,
			null,
			$normalized,
			$title
		);
	}

	private function resolved(
		string $pageKey,
		string $objectType,
		?int $objectId,
		?string $canonicalUrl,
		string $title
	): ResolvedPage {
		if ( null === $canonicalUrl || ! $this->normalizer->isInternal( $canonicalUrl ) ) {
			return ResolvedPage::excluded( 'invalid_url' );
		}

		return new ResolvedPage(
			$pageKey,
			$objectType,
			$objectId,
			$canonicalUrl,
			$this->normalizer->hash( $canonicalUrl ),
			wp_strip_all_tags( $title ),
			true
		);
	}

	private function currentUrl(): string {
		global $wp;

		$requestPath = isset( $wp->request ) ? '/' . ltrim( (string) $wp->request, '/' ) : '/';
		$url         = home_url( $requestPath );

		if ( (bool) $this->settings->get( 'distinguish_query_strings', false ) ) {
				$queryString = isset( $_SERVER['QUERY_STRING'] )
					? sanitize_text_field( wp_unslash( (string) $_SERVER['QUERY_STRING'] ) )
					: '';
			if ( '' !== $queryString ) {
				$url .= '?' . $queryString;
			}
		}

		return $url;
	}

	private function isRestRequest(): bool {
		return defined( 'REST_REQUEST' ) && REST_REQUEST;
	}
}
