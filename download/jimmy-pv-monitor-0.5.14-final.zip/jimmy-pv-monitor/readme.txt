=== Jimmy PV Monitor ===
Contributors: jimmy
Tags: analytics, page views, referrer, link tracking, privacy
Requires at least: 6.7
Tested up to: 7.0
Requires PHP: 8.1
Stable tag: 0.5.14
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Privacy-focused page-view analytics stored in your WordPress database, with referrer and in-content click reports.

== Description ==

Jimmy PV Monitor records and reports page views without sending analytics data to Jimmy or another third-party analytics service. All analytics data is stored in the site's own WordPress database.

= Main features =

* Site-wide, per-page, lifetime, and daily page-view counts.
* Today, today-inclusive 3-day, 7-day, 30-day, and custom-period reports.
* Horizontal report tabs in addition to the standard WordPress administration menu.
* Today-versus-yesterday and today-versus-selected-period-average comparisons, daily trends, and popular-page reports.
* Per-page reports that can include the homepage and omit pages with no views in the selected period.
* Full referrer URLs as supplied by the browser, plus search engine, social, external, internal, and direct classifications.
* UTM campaign and advertising-platform reports.
* In-content internal-link, external-link, and affiliate-link clicks, clicked page views, source-page views, and click-through rates.
* Aggregate clicks are available in Free; same-visit navigation order and route analysis remain Pro-only features.
* CSV exports for daily views, pages, referrers, campaigns, and link clicks.
* A `[jimmy_pv]` shortcode for showing a page's lifetime view count wherever the site administrator chooses.
* A default 365-day retention period for dated analytics and daily maintenance.

= Privacy-focused design =

The free plugin does not store visitor-identifying cookies, IP addresses, WordPress user IDs, or email addresses as analytics data. A temporary in-memory page-view identifier is used only to avoid duplicate link-click counts during the current page display.

Referrer URLs are stored only to the extent supplied by the browser. Credentials, fragments, passwords, tokens, email fields, advertising click identifiers, and configured sensitive query parameters are removed before storage.

Anonymous unique visitors, sessions, navigation paths, entry pages, and exit analysis are features of the separately distributed Jimmy PV Monitor Pro add-on. No free feature is disabled by a time or volume limit.

The WordPress administration screens are currently available in Japanese only.

== Installation ==

1. Upload the ZIP from Plugins > Add Plugin, or place the `jimmy-pv-monitor` directory in `/wp-content/plugins/`.
2. Activate Jimmy PV Monitor.
3. Open the Jimmy PV menu to review reports and settings.
4. Review the suggested privacy-policy text in Settings > Privacy and adapt it to your site's use and applicable law.

Minimum requirements are WordPress 6.7, PHP 8.1, and MySQL 5.7 or MariaDB 10.4. HTTPS is recommended. WordPress multisite is not supported.

== Frequently Asked Questions ==

= Does tracking begin immediately after activation? =

Yes. Public pages are recorded asynchronously with JavaScript. By default, administrators, previews, known bots, attachments, and 404 pages are excluded. Tracking scope can be changed in the Japanese administration screen.

= Does the plugin send analytics data to an external server? =

No. Free-plugin analytics, telemetry, and settings remain in this site's WordPress database.

= Does the free plugin identify individual visitors? =

No. It uses neither a visitor cookie nor persistent browser storage. It aggregates page views, referrers, and in-content internal/external-link activity without storing a cross-page visit route.

= Can I see the complete referrer URL? =

You can see the value supplied by the browser after safety normalization. Credentials, fragments, and sensitive query parameters are removed, so the stored value may not exactly match the original browser string.

= How do I publish a lifetime page-view count? =

Place `[jimmy_pv]` in the post content or a shortcode-capable widget. The plugin never inserts it automatically.

Example with a minimum display count of 100:

`[jimmy_pv min="100"]`

Example with a specific post ID and format:

`[jimmy_pv post_id="123" format="{title}: {count} PV"]`

Available placeholders are `{count}`, `{count_raw}`, and `{title}`.

= How long is data retained? =

Dated analytics are retained for 365 days by default and can be configured from 30 to 3650 days. A page's lifetime total remains until an administrator resets all data or chooses deletion during uninstall.

= Is data removed when the plugin is uninstalled? =

Not by default. Dedicated tables and settings are removed only when the administrator first enables the delete-on-uninstall setting.

= Does it support WordPress multisite? =

No. Activation is stopped when multisite is detected.

== Privacy ==

The plugin may store:

* View time, viewed page, page title, lifetime views, and daily views.
* A normalized referrer URL supplied by the browser and its source classification.
* UTM values and advertising platform. Advertising click identifier values are not stored.
* Aggregated impressions and clicks for internal and external links used in post content, including links generated when the page is displayed.

The free plugin does not store as analytics data:

* IP addresses.
* Visitor-identifying cookies or persistent browser storage.
* Names, email addresses, or WordPress user IDs.
* Analytics or telemetry sent to Jimmy or another third-party server.

Site administrators remain responsible for notices, consent mechanisms, and retention settings required by their use and applicable law. Suggested policy text is added to Settings > Privacy.

== Changelog ==

= 0.5.14 =

* Renamed the external-link report to Click Tracking and added internal-link clicks alongside external and affiliate links.
* Kept click-only aggregation in Free while leaving cross-page visit order and route analysis exclusively in Pro.
* Added link type and destination details to the administration report and CSV export.
* Re-indexed post-content links without discarding previously recorded external-link clicks.

= 0.5.13 =

* Stopped treating same-site page moves as referrer traffic.
* Excluded previously recorded same-site referrers from the dashboard, referrer report, and referrer CSV.

= 0.5.12 =

* Grouped external-link clicks by source page with expandable destination details and the most recent click time.
* Grouped referrers by source with expandable first-page details.
* Added plain-language guidance to every setting.

= 0.5.11 =

* Added click-time detection for dynamically generated external and affiliate links.
* Stabilized wrapped administration tabs, matched their order to the left menu, and made report screens use the available browser width.
* Changed the WordPress dashboard widget to today's top 10 posts and added the current-month page-view total.
* Put the first-viewed page first in the referrer table and separated source classification from source name.

= 0.5.10 =

* Replaced the yesterday period preset with a today-inclusive three-day preset across report screens.
* Matched page titles to the left menu, added plain-language descriptions, and split the long referrer report into tabs.
* Moved external-link anchor text before the destination in both the report table and CSV export.
* Reworded specialist administration labels and explanations for non-technical blog operators.

== Upgrade Notice ==

= 0.5.14 =

Existing analytics and external-link clicks are preserved. Internal-link click measurement starts after the automatic post-link re-index and cannot be backfilled. Cross-page route analysis remains Pro-only.

= 0.5.13 =

Existing page views and external referrer data are preserved. Same-site page moves are no longer recorded or shown as inflow traffic.

= 0.5.12 =

Existing analytics, settings, and click totals are preserved. Click times are available only for clicks recorded after this update.

= 0.5.11 =

Existing analytics, settings, and link-click data are preserved. New runtime-generated affiliate clicks are recorded after this update and cannot be backfilled.

= 0.5.10 =

This update changes report presentation and period choices only. Existing analytics, settings, and external-link click data are preserved.
